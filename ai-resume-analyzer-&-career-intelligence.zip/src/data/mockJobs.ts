import { JobRecommendation, ResumeAnalysisResult, JobDomain } from '../types';

export const BASE_JOBS: JobRecommendation[] = [
  // 1. FULL STACK & WEB
  {
    id: 'job-1',
    title: 'Senior Full Stack AI Systems Engineer',
    company: 'Anthropic Labs',
    location: 'Bengaluru, India / Remote',
    domain: 'Full Stack & Web',
    type: 'Hybrid',
    employmentType: 'Full-time',
    salaryRange: '₹38,00,000 - ₹58,00,000 / yr (38 - 58 LPA)',
    salaryINR: '₹38 - 58 LPA',
    platform: 'LinkedIn',
    experienceLevel: 'Senior',
    requiredYears: '5-8 years',
    matchPercentage: 96,
    isExactMatch: true,
    exactSkillMatchesCount: 7,
    matchBreakdown: {
      skillsMatch: 98,
      experienceMatch: 95,
      roleFit: 96,
      atsReadiness: 96
    },
    matchedSkills: ['React', 'Next.js', 'TypeScript', 'Node.js', 'Python', 'AWS', 'Docker', 'PostgreSQL', 'Kafka'],
    missingSkills: ['Anthropic Claude API', 'Rust'],
    highlights: [
      'Top 2% candidate alignment based on distributed backend & modern React architecture',
      'Direct match for 5+ years cloud architecture & LLM orchestration experience',
      'Includes ₹15L annual equity stock grant and health coverage'
    ],
    description: 'We are seeking an exceptional Senior Full Stack Engineer to build next-generation model steering interfaces, enterprise workspace tooling, and high-throughput real-time telemetry streaming platforms for AI workflows.',
    postedDate: '2 hours ago',
    companyLogoBg: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    companyInitials: 'AN',
    tags: ['AI / LLM', 'Next.js', 'Distributed Systems', 'Tier-1 Tech'],
    applyUrl: 'https://www.linkedin.com/jobs/search/?keywords=Anthropic+Full+Stack+Engineer'
  },
  {
    id: 'job-2',
    title: 'Full Stack Web Developer (React + Node.js)',
    company: 'Zomato Engineering',
    location: 'Gurugram / Remote (Hybrid)',
    domain: 'Full Stack & Web',
    type: 'Hybrid',
    employmentType: 'Full-time',
    salaryRange: '₹24,00,000 - ₹36,00,000 / yr (24 - 36 LPA)',
    salaryINR: '₹24 - 36 LPA',
    platform: 'Instahyre',
    experienceLevel: 'Mid',
    requiredYears: '2-5 years',
    matchPercentage: 94,
    isExactMatch: true,
    exactSkillMatchesCount: 6,
    matchBreakdown: {
      skillsMatch: 96,
      experienceMatch: 93,
      roleFit: 94,
      atsReadiness: 92
    },
    matchedSkills: ['React', 'Node.js', 'TypeScript', 'PostgreSQL', 'Redis', 'REST API', 'Tailwind CSS'],
    missingSkills: ['Next.js App Router', 'Elasticsearch'],
    highlights: [
      'Power high-traffic food ordering & dining out web applications with 10M+ daily transactions',
      'Directly matches full-stack JavaScript/TypeScript core competencies'
    ],
    description: 'Build robust consumer-facing web experiences, partner dashboards, and high-volume order routing engines with modern TypeScript and responsive web standards.',
    postedDate: '1 day ago',
    companyLogoBg: 'bg-red-600/20 text-red-300 border-red-500/30',
    companyInitials: 'ZM',
    tags: ['Full Stack', 'Node.js', 'React', 'Consumer Tech'],
    applyUrl: 'https://www.instahyre.com/job-search/?q=Zomato+Full+Stack+Developer'
  },
  {
    id: 'job-3',
    title: 'Full Stack Engineer - Core Platform',
    company: 'Postman India',
    location: 'Bengaluru, Karnataka (Remote Friendly)',
    domain: 'Full Stack & Web',
    type: 'Remote',
    employmentType: 'Full-time',
    salaryRange: '₹30,00,000 - ₹45,00,000 / yr (30 - 45 LPA)',
    salaryINR: '₹30 - 45 LPA',
    platform: 'Hirist',
    experienceLevel: 'Senior',
    requiredYears: '4-7 years',
    matchPercentage: 92,
    isExactMatch: true,
    exactSkillMatchesCount: 5,
    matchBreakdown: {
      skillsMatch: 94,
      experienceMatch: 90,
      roleFit: 92,
      atsReadiness: 93
    },
    matchedSkills: ['Node.js', 'React', 'TypeScript', 'GraphQL', 'Docker', 'AWS', 'WebSockets'],
    missingSkills: ['Electron', 'WebAssembly'],
    highlights: [
      'Build developer tooling used by 30+ million API developers globally',
      'Competitive ESOP grants, flexible work policy, and tech equipment budget'
    ],
    description: 'Work on the core collaborative API client, mock servers, and real-time collaboration engines powering enterprise engineering organizations.',
    postedDate: '3 days ago',
    companyLogoBg: 'bg-orange-500/20 text-orange-300 border-orange-500/30',
    companyInitials: 'PM',
    tags: ['Developer Tools', 'APIs', 'TypeScript', 'Remote'],
    applyUrl: 'https://www.hirist.tech/search?q=Postman+Full+Stack+Engineer'
  },

  // 2. BACKEND & DISTRIBUTED SYSTEMS
  {
    id: 'job-4',
    title: 'Staff Distributed Systems Architect',
    company: 'Stripe Global Payments',
    location: 'Bengaluru / Hyderabad (Remote Friendly)',
    domain: 'Backend & Systems',
    type: 'Remote',
    employmentType: 'Full-time',
    salaryRange: '₹48,00,000 - ₹72,00,000 / yr (48 - 72 LPA)',
    salaryINR: '₹48 - 72 LPA',
    platform: 'Naukri',
    experienceLevel: 'Lead',
    requiredYears: '7-12 years',
    matchPercentage: 92,
    isExactMatch: false,
    exactSkillMatchesCount: 6,
    matchBreakdown: {
      skillsMatch: 94,
      experienceMatch: 91,
      roleFit: 90,
      atsReadiness: 95
    },
    matchedSkills: ['PostgreSQL', 'Redis', 'Kafka', 'Go', 'Microservices', 'Kubernetes', 'AWS', 'SOC-2'],
    missingSkills: ['Ruby / Sorbet', 'Spanner'],
    highlights: [
      'Your verified payment volume & 99.99% uptime achievements directly mirror Stripe requirements',
      'High match on microservices migration & latency reduction track record'
    ],
    description: 'Join the Core Payments & Ledger engineering group to design ultra-resilient financial primitives executing millions of global transactions per second with mathematical fault tolerance.',
    postedDate: '1 day ago',
    companyLogoBg: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    companyInitials: 'ST',
    tags: ['Fintech', 'Go', 'High Concurrency', 'Remote'],
    applyUrl: 'https://www.naukri.com/jobs-in-india?keywords=Stripe+Distributed+Systems+Architect'
  },
  {
    id: 'job-5',
    title: 'Senior Backend Engineer - Financial Infrastructure',
    company: 'Razorpay Payments',
    location: 'Bengaluru, Karnataka (Hybrid)',
    domain: 'Backend & Systems',
    type: 'Hybrid',
    employmentType: 'Full-time',
    salaryRange: '₹28,00,000 - ₹42,00,000 / yr (28 - 42 LPA)',
    salaryINR: '₹28 - 42 LPA',
    platform: 'Instahyre',
    experienceLevel: 'Senior',
    requiredYears: '4-8 years',
    matchPercentage: 93,
    isExactMatch: true,
    exactSkillMatchesCount: 6,
    matchBreakdown: {
      skillsMatch: 95,
      experienceMatch: 92,
      roleFit: 93,
      atsReadiness: 94
    },
    matchedSkills: ['Go', 'Node.js', 'PostgreSQL', 'Redis', 'Kafka', 'Microservices', 'Docker', 'AWS'],
    missingSkills: ['Payment Gateway Protocol ISO 8583', 'Fintech Security compliance'],
    highlights: [
      'Power payments for over 10M Indian businesses with 99.99% target uptime',
      'Aggressive career growth, ESOP liquidity programs, and wellness allowances'
    ],
    description: 'Design and build high-throughput payment routing, automated settlement engines, and banking integration microservices handling millions of API calls every hour.',
    postedDate: '1 day ago',
    companyLogoBg: 'bg-blue-600/20 text-blue-300 border-blue-500/30',
    companyInitials: 'RZ',
    tags: ['Fintech', 'Go', 'Microservices', 'High Scale'],
    applyUrl: 'https://www.instahyre.com/job-search/?q=Razorpay+Backend+Engineer'
  },
  {
    id: 'job-6',
    title: 'Senior Backend Engineer - Platform Resilience',
    company: 'Netflix Engineering',
    location: 'Remote Friendly (India / APAC)',
    domain: 'Backend & Systems',
    type: 'Remote',
    employmentType: 'Full-time',
    salaryRange: '₹55,00,000 - ₹80,00,000 / yr (55 - 80 LPA)',
    salaryINR: '₹55 - 80 LPA',
    platform: 'Company Career',
    experienceLevel: 'Senior',
    requiredYears: '5-9 years',
    matchPercentage: 93,
    isExactMatch: false,
    exactSkillMatchesCount: 5,
    matchBreakdown: {
      skillsMatch: 94,
      experienceMatch: 92,
      roleFit: 93,
      atsReadiness: 92
    },
    matchedSkills: ['Java', 'Python', 'Go', 'AWS', 'Kafka', 'Redis', 'Microservices', 'Docker'],
    missingSkills: ['Chaos Engineering / Simian Army', 'gRPC Streaming'],
    highlights: [
      'Work on video streaming pipelines delivering content to 260M+ subscribers in 190+ countries',
      'Top-of-market compensation with customizable all-cash or equity split'
    ],
    description: 'Architect and scale fault-tolerant distributed microservices, content delivery gateways, and edge caching networks that never drop a frame.',
    postedDate: '3 days ago',
    companyLogoBg: 'bg-rose-600/20 text-rose-300 border-rose-500/30',
    companyInitials: 'NF',
    tags: ['Streaming', 'High Scale', 'Microservices', 'Distributed Systems'],
    applyUrl: 'https://jobs.netflix.com/search?q=Backend+Engineer'
  },

  // 3. FRONTEND & MOBILE DEVELOPMENT
  {
    id: 'job-7',
    title: 'Senior Frontend Platform Engineer',
    company: 'Vercel / Next.js Core',
    location: 'Remote (India / APAC)',
    domain: 'Frontend & Mobile',
    type: 'Remote',
    employmentType: 'Full-time',
    salaryRange: '₹32,00,000 - ₹48,00,000 / yr (32 - 48 LPA)',
    salaryINR: '₹32 - 48 LPA',
    platform: 'Indeed',
    experienceLevel: 'Senior',
    requiredYears: '4-7 years',
    matchPercentage: 95,
    isExactMatch: true,
    exactSkillMatchesCount: 7,
    matchBreakdown: {
      skillsMatch: 98,
      experienceMatch: 92,
      roleFit: 96,
      atsReadiness: 94
    },
    matchedSkills: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS', 'Vite', 'GraphQL', 'D3.js', 'Playwright'],
    missingSkills: ['Turbopack / Rust Core'],
    highlights: [
      '100% matched across modern frontend ecosystem (React 19, Next.js, TypeScript)',
      'Telemetry visualization & real-time WebSockets background is ideal fit'
    ],
    description: 'Work at the bleeding edge of the web. Build developer tools, instant preview environments, and performance monitoring suites utilized by over 3 million developers worldwide.',
    postedDate: '3 days ago',
    companyLogoBg: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    companyInitials: 'VC',
    tags: ['Developer Tools', 'Next.js', 'React', 'TypeScript'],
    applyUrl: 'https://in.indeed.com/jobs?q=Vercel+Frontend+Platform+Engineer'
  },
  {
    id: 'job-8',
    title: 'Senior Frontend Engineer - High Traffic Apps',
    company: 'Swiggy / Instamart',
    location: 'Bengaluru, India (Hybrid)',
    domain: 'Frontend & Mobile',
    type: 'Hybrid',
    employmentType: 'Full-time',
    salaryRange: '₹26,00,000 - ₹38,00,000 / yr (26 - 38 LPA)',
    salaryINR: '₹26 - 38 LPA',
    platform: 'Foundit',
    experienceLevel: 'Senior',
    requiredYears: '3-6 years',
    matchPercentage: 92,
    isExactMatch: true,
    exactSkillMatchesCount: 6,
    matchBreakdown: {
      skillsMatch: 95,
      experienceMatch: 90,
      roleFit: 92,
      atsReadiness: 91
    },
    matchedSkills: ['React', 'TypeScript', 'Tailwind CSS', 'Next.js', 'Redux', 'Web Performance', 'REST API'],
    missingSkills: ['React Native Mobile Bridging', 'Edge Caching PWA'],
    highlights: [
      'Direct match for modern React/TypeScript craft with high-concurrency user base',
      'Shape order tracking, hyper-local consumer flows, and partner dashboard portals'
    ],
    description: 'Scale web and mobile-web consumer interfaces serving 50M+ monthly active users with sub-second page loads and seamless payment checkouts.',
    postedDate: '2 days ago',
    companyLogoBg: 'bg-orange-500/20 text-orange-300 border-orange-500/30',
    companyInitials: 'SW',
    tags: ['Frontend', 'React', 'Consumer Tech', 'High Scale'],
    applyUrl: 'https://www.foundit.in/srp/results?query=Swiggy+Frontend+Developer'
  },
  {
    id: 'job-9',
    title: 'Mobile Application Engineer (React Native / Flutter)',
    company: 'CRED Experiences',
    location: 'Bengaluru, Karnataka (On-site)',
    domain: 'Frontend & Mobile',
    type: 'On-site',
    employmentType: 'Full-time',
    salaryRange: '₹28,00,000 - ₹44,00,000 / yr (28 - 44 LPA)',
    salaryINR: '₹28 - 44 LPA',
    platform: 'Wellfound',
    experienceLevel: 'Mid',
    requiredYears: '2-5 years',
    matchPercentage: 88,
    isExactMatch: false,
    exactSkillMatchesCount: 4,
    matchBreakdown: {
      skillsMatch: 89,
      experienceMatch: 87,
      roleFit: 88,
      atsReadiness: 89
    },
    matchedSkills: ['React Native', 'React', 'TypeScript', 'Redux', 'iOS', 'Android', 'REST API'],
    missingSkills: ['Native Swift / Kotlin Bridge', 'Custom Shader Animations'],
    highlights: [
      'Build award-winning, fluid 120fps UI animations and high-security payment flows',
      'Industry-leading compensation, top-tier Apple hardware, and wellness perks'
    ],
    description: 'Design and deliver ultra-polished fintech and lifestyle rewards interfaces for India’s top creditworthy community members.',
    postedDate: '4 days ago',
    companyLogoBg: 'bg-violet-600/20 text-violet-300 border-violet-500/30',
    companyInitials: 'CR',
    tags: ['Mobile', 'React Native', 'Fintech', 'UI Craft'],
    applyUrl: 'https://wellfound.com/jobs?q=CRED+React+Native+Engineer'
  },

  // 4. AI & DATA SCIENCE
  {
    id: 'job-10',
    title: 'Lead Generative AI Product Manager',
    company: 'OpenAI Enterprise',
    location: 'Bengaluru / Hybrid',
    domain: 'AI & Data Science',
    type: 'Hybrid',
    employmentType: 'Full-time',
    salaryRange: '₹45,00,000 - ₹68,00,000 / yr (45 - 68 LPA)',
    salaryINR: '₹45 - 68 LPA',
    platform: 'LinkedIn',
    experienceLevel: 'Lead',
    requiredYears: '6-10 years',
    matchPercentage: 91,
    isExactMatch: true,
    exactSkillMatchesCount: 6,
    matchBreakdown: {
      skillsMatch: 92,
      experienceMatch: 90,
      roleFit: 94,
      atsReadiness: 89
    },
    matchedSkills: ['Generative AI', 'Product Management', 'RAG', 'Prompt Engineering', 'A/B Testing', 'SQL', 'GTM', 'Enterprise SaaS'],
    missingSkills: ['Autonomous Agents Architecture', 'Evals SDK'],
    highlights: [
      'Exceptional match for candidates with technical AI copilot lifecycle leadership',
      'Strong alignment on prompt routing & cost optimization experience'
    ],
    description: 'Drive the next frontier of enterprise generative AI products. Shape the product roadmap for API platform solutions, fine-tuning infrastructure, and enterprise data security connectors.',
    postedDate: '2 days ago',
    companyLogoBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    companyInitials: 'OA',
    tags: ['Generative AI', 'Product Strategy', 'LLMs', 'High Growth'],
    applyUrl: 'https://www.linkedin.com/jobs/search/?keywords=OpenAI+Product+Manager'
  },
  {
    id: 'job-11',
    title: 'Machine Learning & Applied AI Scientist',
    company: 'Microsoft Research India',
    location: 'Bengaluru / Hyderabad',
    domain: 'AI & Data Science',
    type: 'Hybrid',
    employmentType: 'Full-time',
    salaryRange: '₹36,00,000 - ₹56,00,000 / yr (36 - 56 LPA)',
    salaryINR: '₹36 - 56 LPA',
    platform: 'Glassdoor',
    experienceLevel: 'Senior',
    requiredYears: '4-8 years',
    matchPercentage: 90,
    isExactMatch: false,
    exactSkillMatchesCount: 4,
    matchBreakdown: {
      skillsMatch: 92,
      experienceMatch: 89,
      roleFit: 90,
      atsReadiness: 91
    },
    matchedSkills: ['Python', 'PyTorch', 'TensorFlow', 'LLM', 'Machine Learning', 'Docker', 'Data Science'],
    missingSkills: ['CUDA C++', 'DeepSpeed Distributed Training'],
    highlights: [
      'Conduct frontier research and deploy state-of-the-art vision and language models at global scale',
      'Comprehensive patent filing bonuses and academic conference sponsorships'
    ],
    description: 'Collaborate with world-renowned scientists to develop efficient model fine-tuning, RAG frameworks, and multilingual AI models for developing markets.',
    postedDate: '3 days ago',
    companyLogoBg: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    companyInitials: 'MS',
    tags: ['AI Research', 'Python', 'PyTorch', 'Tier-1 Tech'],
    applyUrl: 'https://www.glassdoor.co.in/Job/india-applied-scientist-jobs-SRCH_IL.0,5_IN115_KO6,23.htm'
  },
  {
    id: 'job-12',
    title: 'Senior Data & Analytics Engineer',
    company: 'PhonePe Data Platform',
    location: 'Bengaluru, Karnataka (Hybrid)',
    domain: 'AI & Data Science',
    type: 'Hybrid',
    employmentType: 'Full-time',
    salaryRange: '₹25,00,000 - ₹38,00,000 / yr (25 - 38 LPA)',
    salaryINR: '₹25 - 38 LPA',
    platform: 'Naukri',
    experienceLevel: 'Senior',
    requiredYears: '3-6 years',
    matchPercentage: 89,
    isExactMatch: true,
    exactSkillMatchesCount: 5,
    matchBreakdown: {
      skillsMatch: 91,
      experienceMatch: 88,
      roleFit: 89,
      atsReadiness: 90
    },
    matchedSkills: ['Python', 'SQL', 'PostgreSQL', 'Kafka', 'Snowflake', 'Spark', 'Airflow'],
    missingSkills: ['Trino / Presto', 'dbt Data Modeling'],
    highlights: [
      'Ingest and process over 100 billion event rows monthly for financial fraud analytics',
      'Generous retention bonuses and health insurance for family'
    ],
    description: 'Build real-time ETL pipelines, data lakes, and business intelligence models powering growth and transaction telemetry across 450M registered users.',
    postedDate: '4 days ago',
    companyLogoBg: 'bg-purple-600/20 text-purple-300 border-purple-500/30',
    companyInitials: 'PP',
    tags: ['Data Platform', 'Python', 'SQL', 'Kafka'],
    applyUrl: 'https://www.naukri.com/jobs-in-india?keywords=PhonePe+Data+Engineer'
  },

  // 5. CLOUD & DEVOPS & SRE
  {
    id: 'job-13',
    title: 'Senior Software Engineer, Core Cloud & AI',
    company: 'Google India',
    location: 'Bengaluru / Hyderabad, India',
    domain: 'Cloud & DevOps',
    type: 'Hybrid',
    employmentType: 'Full-time',
    salaryRange: '₹42,00,000 - ₹65,00,000 / yr (42 - 65 LPA)',
    salaryINR: '₹42 - 65 LPA',
    platform: 'Company Career',
    experienceLevel: 'Senior',
    requiredYears: '5-9 years',
    matchPercentage: 94,
    isExactMatch: true,
    exactSkillMatchesCount: 7,
    matchBreakdown: {
      skillsMatch: 95,
      experienceMatch: 93,
      roleFit: 94,
      atsReadiness: 94
    },
    matchedSkills: ['TypeScript', 'Python', 'Go', 'Kubernetes', 'Distributed Systems', 'GCP', 'PostgreSQL', 'Docker'],
    missingSkills: ['Borg / internal tools', 'Spanner'],
    highlights: [
      'Top-tier engineering team working on global-scale AI infrastructure and developer platforms',
      'Comprehensive Google India health benefits, annual performance bonus, and RSU equity'
    ],
    description: 'Build and optimize cloud-scale AI serving systems, developer SDKs, and enterprise infrastructure used by billions of users and millions of developers worldwide.',
    postedDate: '1 day ago',
    companyLogoBg: 'bg-red-500/20 text-red-300 border-red-500/30',
    companyInitials: 'GO',
    tags: ['Cloud', 'AI Infrastructure', 'Tier-1 Tech', 'Distributed Systems'],
    applyUrl: 'https://careers.google.com/jobs/results/?q=Software+Engineer+India'
  },
  {
    id: 'job-14',
    title: 'Cloud Solutions & DevOps Architect',
    company: 'Datadog Observability',
    location: 'Remote (India / APAC)',
    domain: 'Cloud & DevOps',
    type: 'Remote',
    employmentType: 'Full-time',
    salaryRange: '₹34,00,000 - ₹50,00,000 / yr (34 - 50 LPA)',
    salaryINR: '₹34 - 50 LPA',
    platform: 'Indeed',
    experienceLevel: 'Senior',
    requiredYears: '4-8 years',
    matchPercentage: 88,
    isExactMatch: false,
    exactSkillMatchesCount: 4,
    matchBreakdown: {
      skillsMatch: 90,
      experienceMatch: 87,
      roleFit: 88,
      atsReadiness: 89
    },
    matchedSkills: ['AWS', 'Kubernetes', 'Terraform', 'CI/CD', 'Docker', 'Datadog', 'Python'],
    missingSkills: ['eBPF', 'OpenTelemetry Collector'],
    highlights: [
      'Strong fit with distributed monitoring, Kubernetes clusters, and Terraform provisioning',
      'Matches your telemetry & enterprise SOC-2 compliance background'
    ],
    description: 'Design global scale infrastructure that ingests tens of trillions of events daily. Partner with enterprise customers to architect zero-downtime multi-cloud observabilities.',
    postedDate: '4 days ago',
    companyLogoBg: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    companyInitials: 'DD',
    tags: ['DevOps', 'Observability', 'Terraform', 'Kubernetes'],
    applyUrl: 'https://in.indeed.com/jobs?q=Datadog+DevOps+Engineer'
  },
  {
    id: 'job-15',
    title: 'Lead Cloud Infrastructure & DevOps Specialist',
    company: 'Infosys Cobalt Cloud',
    location: 'Bengaluru / Pune / Hyderabad',
    domain: 'Cloud & DevOps',
    type: 'Hybrid',
    employmentType: 'Full-time',
    salaryRange: '₹22,00,000 - ₹34,00,000 / yr (22 - 34 LPA)',
    salaryINR: '₹22 - 34 LPA',
    platform: 'Foundit',
    experienceLevel: 'Lead',
    requiredYears: '6-10 years',
    matchPercentage: 89,
    isExactMatch: false,
    exactSkillMatchesCount: 4,
    matchBreakdown: {
      skillsMatch: 91,
      experienceMatch: 88,
      roleFit: 89,
      atsReadiness: 90
    },
    matchedSkills: ['AWS', 'Kubernetes', 'Docker', 'Terraform', 'CI/CD', 'Python', 'PostgreSQL'],
    missingSkills: ['FinOps Cloud Cost Automation', 'Azure Landing Zones'],
    highlights: [
      'Lead large-scale enterprise modernization for Global 500 financial clients',
      'Certification sponsorships (AWS Solutions Architect Pro, CKA Kubernetes)'
    ],
    description: 'Architect enterprise-grade hybrid cloud blueprints, zero-trust security postures, and automated CI/CD deployment pipelines on multi-cloud environments.',
    postedDate: '3 days ago',
    companyLogoBg: 'bg-teal-500/20 text-teal-300 border-teal-500/30',
    companyInitials: 'IN',
    tags: ['Cloud', 'DevOps', 'Enterprise', 'AWS'],
    applyUrl: 'https://www.foundit.in/srp/results?query=Infosys+DevOps+Architect'
  },

  // 6. QA & TEST AUTOMATION (SDET)
  {
    id: 'job-16',
    title: 'Senior SDET / QA Automation Engineer',
    company: 'BrowserStack Cloud',
    location: 'Mumbai / Bengaluru / Remote',
    domain: 'QA & Automation',
    type: 'Remote',
    employmentType: 'Full-time',
    salaryRange: '₹22,00,000 - ₹32,00,000 / yr (22 - 32 LPA)',
    salaryINR: '₹22 - 32 LPA',
    platform: 'Hirist',
    experienceLevel: 'Senior',
    requiredYears: '3-6 years',
    matchPercentage: 91,
    isExactMatch: true,
    exactSkillMatchesCount: 5,
    matchBreakdown: {
      skillsMatch: 93,
      experienceMatch: 90,
      roleFit: 92,
      atsReadiness: 91
    },
    matchedSkills: ['Playwright', 'Selenium', 'JavaScript', 'TypeScript', 'Python', 'CI/CD', 'REST API', 'Git'],
    missingSkills: ['Appium Mobile Testing', 'JMeter Load Testing'],
    highlights: [
      'Test next-generation real-device cloud browsers used by 50,000+ software teams',
      'Remote-first work setup with flexible hours and international collaboration'
    ],
    description: 'Build enterprise-grade test automation harnesses, end-to-end regression suites, and continuous quality gates across thousands of browser and OS combinations.',
    postedDate: '2 days ago',
    companyLogoBg: 'bg-cyan-600/20 text-cyan-300 border-cyan-500/30',
    companyInitials: 'BS',
    tags: ['QA', 'SDET', 'Playwright', 'Test Automation'],
    applyUrl: 'https://www.hirist.tech/search?q=BrowserStack+QA+Automation'
  },

  // 7. PRODUCT & DESIGN
  {
    id: 'job-17',
    title: 'Product Designer & Design Systems Lead',
    company: 'Figma Systems',
    location: 'Remote (India / Global)',
    domain: 'Product & Design',
    type: 'Remote',
    employmentType: 'Full-time',
    salaryRange: '₹30,00,000 - ₹44,00,000 / yr (30 - 44 LPA)',
    salaryINR: '₹30 - 44 LPA',
    platform: 'LinkedIn',
    experienceLevel: 'Senior',
    requiredYears: '4-7 years',
    matchPercentage: 90,
    isExactMatch: false,
    exactSkillMatchesCount: 4,
    matchBreakdown: {
      skillsMatch: 92,
      experienceMatch: 88,
      roleFit: 91,
      atsReadiness: 90
    },
    matchedSkills: ['Figma', 'React', 'TypeScript', 'Tailwind CSS', 'Design Systems', 'CSS', 'UI / UX'],
    missingSkills: ['WebGL', 'Wasm Canvas Rendering'],
    highlights: [
      'Shape the canvas tools and design systems empowering millions of creative teams globally',
      'Remote-first flexibility with generous home office and wellness stipends'
    ],
    description: 'Design and prototype intuitive, blazing-fast interfaces that bridge designers and developers in collaborative real-time canvases.',
    postedDate: '2 days ago',
    companyLogoBg: 'bg-pink-500/20 text-pink-300 border-pink-500/30',
    companyInitials: 'FG',
    tags: ['Design Systems', 'React', 'Figma', 'Remote'],
    applyUrl: 'https://www.linkedin.com/jobs/search/?keywords=Figma+Design+Systems+Engineer'
  },

  // 8. FRESHERS & INTERNSHIPS
  {
    id: 'job-18',
    title: 'Graduate Software Development Engineer (Fresher / 2024-2026 Batch)',
    company: 'TCS Digital / Innovations Lab',
    location: 'Chennai / Bengaluru / Hyderabad',
    domain: 'Freshers & Internships',
    type: 'On-site',
    employmentType: 'Full-time',
    salaryRange: '₹7,50,000 - ₹11,00,000 / yr (7.5 - 11 LPA)',
    salaryINR: '₹7.5 - 11 LPA',
    platform: 'Unstop',
    experienceLevel: 'Entry',
    requiredYears: '0-1 years',
    matchPercentage: 88,
    isExactMatch: true,
    exactSkillMatchesCount: 5,
    matchBreakdown: {
      skillsMatch: 90,
      experienceMatch: 85,
      roleFit: 88,
      atsReadiness: 90
    },
    matchedSkills: ['Java', 'Python', 'React', 'JavaScript', 'SQL', 'Data Structures', 'Git'],
    missingSkills: ['System Design at Scale', 'Spring Cloud'],
    highlights: [
      'Elite R&D division for high-aptitude campus graduates and entry-level developers',
      'Structured 6-month hands-on full-stack incubator and rapid appraisal cycles'
    ],
    description: 'Join the next generation of engineers building enterprise software, modern cloud services, and AI automation prototypes for international Fortune 500 clients.',
    postedDate: '1 day ago',
    companyLogoBg: 'bg-blue-700/20 text-blue-300 border-blue-600/30',
    companyInitials: 'TC',
    tags: ['Freshers', 'Campus Hire', 'Java', 'Full Stack'],
    applyUrl: 'https://unstop.com/jobs?searchTerm=TCS+Digital+Software+Engineer'
  },
  {
    id: 'job-19',
    title: 'Frontend Web Engineering Intern',
    company: 'Zepto Quick Commerce',
    location: 'Bengaluru, Karnataka (Hybrid / Stipend)',
    domain: 'Freshers & Internships',
    type: 'Hybrid',
    employmentType: 'Internship',
    salaryRange: '₹40,000 - ₹55,000 / month (Stipend + PPO Offer)',
    salaryINR: '₹40,000 - ₹55,000 / mo',
    platform: 'Internshala',
    experienceLevel: 'Intern',
    requiredYears: '0-1 years (College / Graduate)',
    matchPercentage: 92,
    isExactMatch: true,
    exactSkillMatchesCount: 5,
    matchBreakdown: {
      skillsMatch: 94,
      experienceMatch: 89,
      roleFit: 92,
      atsReadiness: 93
    },
    matchedSkills: ['React', 'TypeScript', 'Tailwind CSS', 'HTML5', 'CSS3', 'Git'],
    missingSkills: ['Next.js SSR', 'Webpack Chunk Optimization'],
    highlights: [
      'High pre-placement offer (PPO) conversion rate up to ₹18 LPA for top performing interns',
      'Fast-paced startup engineering mentorship with daily code shipping'
    ],
    description: 'Build fast, responsive web pages for marketing campaigns, delivery tracking widgets, and internal inventory management portals with React and TypeScript.',
    postedDate: 'Just now',
    companyLogoBg: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
    companyInitials: 'ZP',
    tags: ['Internship', 'React', 'Startup', 'PPO Opportunity'],
    applyUrl: 'https://internshala.com/internships/matching-react-web-development-internship'
  },
  {
    id: 'job-20',
    title: 'Associate / Junior Frontend Web Developer',
    company: 'Linear App Experiences',
    location: 'Remote (India / Global)',
    domain: 'Frontend & Mobile',
    type: 'Remote',
    employmentType: 'Full-time',
    salaryRange: '₹14,00,000 - ₹22,00,000 / yr (14 - 22 LPA)',
    salaryINR: '₹14 - 22 LPA',
    platform: 'Wellfound',
    experienceLevel: 'Entry',
    requiredYears: '1-3 years',
    matchPercentage: 87,
    isExactMatch: true,
    exactSkillMatchesCount: 5,
    matchBreakdown: {
      skillsMatch: 88,
      experienceMatch: 84,
      roleFit: 86,
      atsReadiness: 89
    },
    matchedSkills: ['React', 'JavaScript', 'Tailwind CSS', 'HTML', 'CSS', 'Git', 'Figma'],
    missingSkills: ['Web Workers', 'Sync Engines'],
    highlights: [
      'Ideal for proactive frontend developers with polished UI craft and high-velocity shipping mindset',
      'Extensive mentorship and modern stack development pairing'
    ],
    description: 'Craft high-performance, silky-smooth keyboard-first workflows for product teams. Help build our collaborative issue tracker and real-time design systems.',
    postedDate: '5 days ago',
    companyLogoBg: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    companyInitials: 'LN',
    tags: ['Frontend', 'React', 'UI / UX', 'Design Systems'],
    applyUrl: 'https://wellfound.com/jobs?q=Linear+Frontend+Developer'
  }
];

export function recalculateJobMatches(analysis: ResumeAnalysisResult): JobRecommendation[] {
  const candidateSkills = (analysis.allExtractedSkills || []).map(s => s.trim().toLowerCase());
  const isSenior = analysis.seniorityLevel === 'Senior' || analysis.seniorityLevel === 'Lead / Staff';
  const isEntry = analysis.seniorityLevel === 'Entry-Level';
  const candidateTitleLower = (analysis.candidateTitle || '').toLowerCase();
  const experienceYears = analysis.experienceYears || (isEntry ? 1 : isSenior ? 6 : 3);

  return BASE_JOBS.map(job => {
    let domainBoost = 1.0;

    // Check title/domain affinity
    if (candidateTitleLower.includes('product') || candidateTitleLower.includes('pm')) {
      if (job.domain === 'Product & Design') domainBoost = 1.15;
    } else if (candidateTitleLower.includes('frontend') || candidateTitleLower.includes('ui') || candidateTitleLower.includes('web')) {
      if (job.domain === 'Frontend & Mobile' || job.domain === 'Full Stack & Web') domainBoost = 1.12;
    } else if (candidateTitleLower.includes('data') || candidateTitleLower.includes('ai') || candidateTitleLower.includes('ml')) {
      if (job.domain === 'AI & Data Science') domainBoost = 1.14;
    } else if (candidateTitleLower.includes('devops') || candidateTitleLower.includes('cloud') || candidateTitleLower.includes('sre')) {
      if (job.domain === 'Cloud & DevOps') domainBoost = 1.14;
    } else if (candidateTitleLower.includes('qa') || candidateTitleLower.includes('test') || candidateTitleLower.includes('sdet')) {
      if (job.domain === 'QA & Automation') domainBoost = 1.16;
    }

    // Seniority & Experience Alignment
    let expScore = 85;
    if (job.experienceLevel === 'Entry' || job.experienceLevel === 'Intern') {
      expScore = isEntry ? 96 : 82;
    } else if (job.experienceLevel === 'Mid') {
      expScore = experienceYears >= 2 && experienceYears <= 5 ? 95 : 84;
    } else if (job.experienceLevel === 'Senior') {
      expScore = experienceYears >= 4 ? 96 : 76;
    } else if (job.experienceLevel === 'Lead') {
      expScore = experienceYears >= 7 ? 97 : isEntry ? 60 : 78;
    }

    // Dynamic EXACT Skill Overlap
    const exactMatched: string[] = [];
    const partialMatched: string[] = [];

    job.matchedSkills.forEach(jobSkill => {
      const jsLower = jobSkill.toLowerCase();
      const directMatch = candidateSkills.find(cs => cs === jsLower || cs.replace(/[-_.\s]/g, '') === jsLower.replace(/[-_.\s]/g, ''));
      if (directMatch) {
        exactMatched.push(jobSkill);
      } else {
        const partial = candidateSkills.find(cs => cs.includes(jsLower) || jsLower.includes(cs));
        if (partial) {
          partialMatched.push(jobSkill);
        }
      }
    });

    const allMatchedForJob = Array.from(new Set([...exactMatched, ...partialMatched]));
    const missingForJob = job.matchedSkills.filter(sk => !allMatchedForJob.includes(sk)).concat(job.missingSkills);

    const skillsOverlapRatio = allMatchedForJob.length / Math.max(job.matchedSkills.length, 1);
    const skillScore = Math.min(99, Math.max(62, Math.round(skillsOverlapRatio * 100)));

    const isExact = exactMatched.length >= 3 || (exactMatched.length >= 2 && skillsOverlapRatio >= 0.75);

    // Final weighted score
    let finalMatch = Math.round(
      (skillScore * 0.40 + expScore * 0.25 + (analysis.atsScore || 85) * 0.20 + (analysis.overallScore || 85) * 0.15) * domainBoost
    );
    finalMatch = Math.min(99, Math.max(55, finalMatch));

    return {
      ...job,
      matchPercentage: finalMatch,
      isExactMatch: isExact,
      exactSkillMatchesCount: exactMatched.length,
      matchedSkills: allMatchedForJob.length > 0 ? allMatchedForJob : job.matchedSkills.slice(0, 4),
      missingSkills: missingForJob.slice(0, 3),
      matchBreakdown: {
        skillsMatch: skillScore,
        experienceMatch: expScore,
        roleFit: Math.min(99, Math.round(finalMatch * 0.98)),
        atsReadiness: analysis.atsScore || 88
      }
    };
  }).sort((a, b) => {
    if (a.isExactMatch && !b.isExactMatch) return -1;
    if (!a.isExactMatch && b.isExactMatch) return 1;
    return b.matchPercentage - a.matchPercentage;
  });
}
