import { ResumeAnalysisResult } from '../types';

export interface SampleResume {
  id: string;
  name: string;
  role: string;
  experienceLevel: string;
  fileSnippet: string;
  analysis: ResumeAnalysisResult;
}

export const SAMPLE_RESUMES: SampleResume[] = [
  {
    id: 'sample-senior-swe',
    name: 'Alex Rivera - Senior Full Stack Engineer',
    role: 'Senior Full Stack & Cloud Architect',
    experienceLevel: '6+ Years',
    fileSnippet: `ALEX RIVERA
San Francisco, CA • alex.rivera.dev@gmail.com • (555) 234-8901 • github.com/alexrivera • linkedin.com/in/alexrivera-dev

SUMMARY
Results-driven Senior Full Stack Engineer with 6+ years of experience architecting distributed microservices, high-concurrency cloud systems, and responsive modern web applications. Proven track record reducing API latency by 45% and leading 8-engineer sprint teams.

TECHNICAL SKILLS
Languages: TypeScript, JavaScript, Python, Go, SQL, HTML5/CSS3
Frameworks & Libraries: React, Next.js, Node.js, Express, Tailwind CSS, GraphQL, Redux Toolkit
Cloud & DevOps: AWS (Lambda, ECS, S3, RDS, CloudFront), Docker, Kubernetes, Terraform, CI/CD (GitHub Actions)
Databases: PostgreSQL, Redis, MongoDB, DynamoDB, Elasticsearch
Tools & Testing: Git, Jest, Playwright, Datadog, Webpack, Vite, Kafka

EXPERIENCE
Staff Software Engineer | CloudScale Technologies | SF, CA (2022 - Present)
• Architected and migrated a monolithic payments core into containerized microservices handling $120M+ annual transaction volume with 99.99% uptime.
• Reduced p99 API response times from 420ms to 85ms across 14 million daily requests via distributed Redis caching and query indexing.
• Mentored 6 mid-level engineers, established automated PR code coverage gates (achieving 92% test coverage), and reduced sprint bug escape rates by 38%.

Senior Software Engineer | Vertex AI & Analytics | San Jose, CA (2019 - 2022)
• Developed responsive data visualization dashboards using React, D3.js, and WebSockets rendering 50,000+ real-time telemetry points seamlessly.
• Designed event-driven data ingestion pipeline using Apache Kafka and Python FastAPI, processing 2.5TB daily analytics data.
• Implemented OAuth2/OIDC security architecture with role-based access control (RBAC) compliant with SOC-2 standard.

EDUCATION
B.S. in Computer Science | University of California, Berkeley (2015 - 2019) • GPA 3.84 / 4.0`,
    analysis: {
      fileName: 'Alex_Rivera_Senior_FullStack_Resume.pdf',
      fileSize: '1.8 MB',
      analyzedAt: 'Just now',
      candidateName: 'Alex Rivera',
      candidateTitle: 'Senior Full Stack & Cloud Architect',
      candidateEmail: 'alex.rivera.dev@gmail.com',
      candidatePhone: '(555) 234-8901',
      candidateLocation: 'San Francisco, CA',
      experienceYears: 6,
      seniorityLevel: 'Senior',
      overallScore: 94,
      atsScore: 96,
      readabilityScore: 92,
      impactScore: 95,
      skillsScore: 93,
      summary: 'Exceptional senior engineering resume with exemplary quantifiable achievements ($120M volume, 99.99% uptime, 45% latency reduction), strong distributed systems mastery, and clear leadership indicators.',
      topStrengths: [
        'Exceptional quantifiable business metrics in nearly every bullet point ($120M+, 99.99% uptime, 85ms latency).',
        'Balanced, high-demand full stack skillset spanning React/Next.js to AWS, Docker, Kubernetes, Kafka, and PostgreSQL.',
        'Clear leadership and mentorship signals (led 8 engineers, automated PR quality gates).',
        'Clean ATS-compliant layout with standard section headers and contact links.'
      ],
      criticalFixes: [
        'Add 1-2 recognized cloud certifications (e.g. AWS Solutions Architect) to further stand out for Staff/Principal roles.',
        'Specify CI/CD pipeline deployment frequency or cost savings achieved from infrastructure optimizations.'
      ],
      skillsMatrix: [
        {
          category: 'Frontend & Architecture',
          skills: [
            { name: 'React / Next.js', level: 96, verifiedInResume: true },
            { name: 'TypeScript', level: 95, verifiedInResume: true },
            { name: 'Tailwind CSS', level: 90, verifiedInResume: true },
            { name: 'GraphQL / WebSockets', level: 88, verifiedInResume: true },
            { name: 'D3.js / Data Viz', level: 85, verifiedInResume: true }
          ]
        },
        {
          category: 'Backend & Distributed Systems',
          skills: [
            { name: 'Node.js / Express', level: 94, verifiedInResume: true },
            { name: 'Python / FastAPI', level: 90, verifiedInResume: true },
            { name: 'Go / Microservices', level: 84, verifiedInResume: true },
            { name: 'Kafka / Event Streaming', level: 88, verifiedInResume: true },
            { name: 'Redis / In-Memory Caching', level: 92, verifiedInResume: true }
          ]
        },
        {
          category: 'Cloud & Infrastructure',
          skills: [
            { name: 'AWS (ECS, Lambda, RDS)', level: 93, verifiedInResume: true },
            { name: 'Docker / Kubernetes', level: 91, verifiedInResume: true },
            { name: 'CI/CD & GitHub Actions', level: 89, verifiedInResume: true },
            { name: 'Terraform / IaC', level: 82, verifiedInResume: true }
          ]
        },
        {
          category: 'Databases & Reliability',
          skills: [
            { name: 'PostgreSQL / SQL Indexing', level: 95, verifiedInResume: true },
            { name: 'MongoDB / DynamoDB', level: 88, verifiedInResume: true },
            { name: 'SOC-2 Compliance & Auth', level: 86, verifiedInResume: true },
            { name: 'System Design / SRE', level: 92, verifiedInResume: true }
          ]
        }
      ],
      allExtractedSkills: ['React', 'Next.js', 'TypeScript', 'Node.js', 'Python', 'Go', 'AWS', 'Docker', 'Kubernetes', 'PostgreSQL', 'Redis', 'Kafka', 'GraphQL', 'Tailwind CSS', 'Terraform', 'CI/CD', 'Jest', 'Playwright', 'SOC-2', 'Microservices'],
      missingCrucialSkills: ['AWS Solutions Architect Cert', 'gRPC', 'GenAI / LLM Integration'],
      keywordDensity: [
        { keyword: 'Microservices', count: 5, importance: 'High' },
        { keyword: 'React / Next.js', count: 4, importance: 'High' },
        { keyword: 'AWS / Cloud', count: 4, importance: 'High' },
        { keyword: 'Kafka / Streaming', count: 3, importance: 'Medium' },
        { keyword: 'PostgreSQL', count: 3, importance: 'High' },
        { keyword: 'Kubernetes', count: 2, importance: 'Medium' },
        { keyword: 'Architecture', count: 4, importance: 'High' }
      ],
      atsChecks: [
        { id: '1', title: 'File Format & Parseability', status: 'passed', score: 100, details: 'Clean standard typography, selectable text, and zero parse artifacts.', recommendation: 'Format is ideal.' },
        { id: '2', title: 'Contact Information & Links', status: 'passed', score: 100, details: 'Email, phone, location, LinkedIn, and GitHub all correctly extracted.', recommendation: 'All essential channels present.' },
        { id: '3', title: 'Section Headings Standardization', status: 'passed', score: 98, details: 'Used industry standard headers (Experience, Education, Technical Skills).', recommendation: 'Standard layout recognized by 99% of ATS platforms.' },
        { id: '4', title: 'Action Verbs & Impact Metrics', status: 'passed', score: 95, details: '100% of bullets start with active verbs (Architected, Reduced, Designed, Mentored) with quantifiable figures.', recommendation: 'Top 1% benchmark.' },
        { id: '5', title: 'Keyword Match & Density', status: 'passed', score: 92, details: 'Natural distribution of backend, cloud, and frontend keywords without stuffing.', recommendation: 'High semantic relevance for Senior/Staff roles.' }
      ],
      bulletImprovements: [
        {
          id: 'b-1',
          original: 'Worked on microservices migration and helped reduce API response times.',
          improved: 'Architected and orchestrated zero-downtime microservices migration across 14M daily requests, slashing p99 API latency from 420ms to 85ms (79% improvement).',
          impactScoreBefore: 54,
          impactScoreAfter: 97,
          keyEnhancement: 'Added concrete p99 latency baseline, request volume, and exact % gain.',
          category: 'Impact & Metrics'
        },
        {
          id: 'b-2',
          original: 'Helped junior developers with code reviews and fixed bugs in sprints.',
          improved: 'Mentored 6 mid-level engineers, instituted automated PR code coverage gates at 92%, and decreased sprint bug escape rate by 38% across 4 quarters.',
          impactScoreBefore: 48,
          impactScoreAfter: 95,
          keyEnhancement: 'Quantified team size, quality threshold, and reduction in defects.',
          category: 'Leadership'
        }
      ],
      suggestedRoles: [
        'Staff Full Stack Engineer',
        'Senior Distributed Systems Architect',
        'Principal Frontend / Web Platform Engineer',
        'Lead Cloud Solutions Architect'
      ]
    }
  },
  {
    id: 'sample-ai-pm',
    name: 'Elena Rostova - AI & Machine Learning Product Manager',
    role: 'Lead AI / GenAI Product Manager',
    experienceLevel: '5+ Years',
    fileSnippet: `ELENA ROSTOVA
New York, NY • elena.rostova.pm@gmail.com • (212) 883-9102 • linkedin.com/in/elena-ai-pm

EXECUTIVE SUMMARY
Strategic and technical AI Product Manager with 5+ years driving end-to-end lifecycle of enterprise LLM applications, intelligent search algorithms, and predictive ML systems. Delivered $18M in ARR growth, scaled user retention by 34%, and partnered closely with ML research scientists.

CORE COMPETENCIES
• AI & Product Strategy: GenAI, LLM Orchestration, RAG Architectures, Agentic Workflows, Human-in-the-Loop, PRD Authoring
• Analytics & Experimentation: A/B Testing, Multi-Arm Bandits, SQL, Mixpanel, Amplitude, Tableau, Python, User Research
• Technical & Data: Vector DBs (Pinecone), Embeddings, Prompt Engineering, Model Fine-Tuning, Guardrails, Latency Optimization
• Leadership & Execution: Agile/Scrum, OKR Setting, Cross-Functional Alignment, Go-To-Market (GTM), Customer Discovery

EXPERIENCE
Lead Product Manager - Generative AI | Nexus Intelligence Corp | New York, NY (2022 - Present)
• Spearheaded product roadmap for flagship enterprise AI copilot, growing active ARR from $4.2M to $18.6M in 18 months across 140+ Fortune 500 customers.
• Led cross-functional team of 14 (ML research, data engineers, frontend) to build proprietary RAG retrieval engine with 96.4% response accuracy.
• Reduced model token cost by 52% and inference latency by 40% through intelligent prompt routing and semantic caching layer.

Senior Product Manager | SynthData Analytics | Boston, MA (2019 - 2022)
• Defined and launched predictive customer churn platform, increasing enterprise contract renewals by 28% YoY.
• Conducted 100+ user interviews with VP of Data personas, transforming feedback into prioritized quarterly roadmaps.

EDUCATION & CERTS
M.S. in Management Science & Engineering | Columbia University (2017 - 2019)
B.S. in Cognitive Science | Brown University (2013 - 2017)
Pragmatic Institute Certified (PMC-III) • DeepLearning.AI GenAI Specialization`,
    analysis: {
      fileName: 'Elena_Rostova_AI_Product_Manager.pdf',
      fileSize: '1.4 MB',
      analyzedAt: 'Just now',
      candidateName: 'Elena Rostova',
      candidateTitle: 'Lead AI / GenAI Product Manager',
      candidateEmail: 'elena.rostova.pm@gmail.com',
      candidatePhone: '(212) 883-9102',
      candidateLocation: 'New York, NY',
      experienceYears: 5,
      seniorityLevel: 'Senior',
      overallScore: 92,
      atsScore: 95,
      readabilityScore: 94,
      impactScore: 93,
      skillsScore: 91,
      summary: 'High-impact AI/ML Product Manager profile combining revenue delivery ($18.6M ARR), deep technical literacy (RAG, Prompt Routing, Vector DBs), and disciplined product discovery execution.',
      topStrengths: [
        'Superb business outcome delivery highlighted upfront ($4.2M to $18.6M ARR in 18 months).',
        'Strong technical credibility in modern generative AI (RAG, semantic caching, token optimization).',
        'Elite educational pedigree and specialized certifications from Columbia, Brown, and DeepLearning.AI.',
        'High action-to-impact density with crisp quantitative proof points.'
      ],
      criticalFixes: [
        'Highlight security and AI ethics governance frameworks (NIST AI RMF, EU AI Act compliance) for enterprise readiness.',
        'Add brief mention of specific evaluation frameworks used (e.g., RAGAS, human-eval benchmarks).'
      ],
      skillsMatrix: [
        {
          category: 'AI / LLM Product Strategy',
          skills: [
            { name: 'RAG & Vector Retrieval', level: 95, verifiedInResume: true },
            { name: 'LLM Prompt Engineering & Routing', level: 93, verifiedInResume: true },
            { name: 'Model Evaluation & Benchmarking', level: 88, verifiedInResume: true },
            { name: 'Semantic Caching & Token Opt', level: 90, verifiedInResume: true }
          ]
        },
        {
          category: 'Product Discovery & Analytics',
          skills: [
            { name: 'A/B Testing & Experimentation', level: 94, verifiedInResume: true },
            { name: 'SQL & Data Warehousing', level: 89, verifiedInResume: true },
            { name: 'Amplitude / Mixpanel', level: 92, verifiedInResume: true },
            { name: 'Customer Interviews & PRDs', level: 96, verifiedInResume: true }
          ]
        },
        {
          category: 'Execution & Leadership',
          skills: [
            { name: 'Cross-Functional Team Lead', level: 94, verifiedInResume: true },
            { name: 'GTM Strategy & Pricing', level: 90, verifiedInResume: true },
            { name: 'Enterprise SaaS Sales Enablement', level: 88, verifiedInResume: true }
          ]
        }
      ],
      allExtractedSkills: ['Product Management', 'Generative AI', 'RAG', 'LLMs', 'Vector Databases', 'Prompt Engineering', 'A/B Testing', 'SQL', 'Python', 'Amplitude', 'Roadmapping', 'GTM', 'Enterprise SaaS', 'Scrum'],
      missingCrucialSkills: ['AI Governance / Compliance', 'RAGAS Eval Framework', 'LangGraph / Agent Protocols'],
      keywordDensity: [
        { keyword: 'Product Manager / PM', count: 6, importance: 'High' },
        { keyword: 'Generative AI / LLM', count: 5, importance: 'High' },
        { keyword: 'RAG / Retrieval', count: 4, importance: 'High' },
        { keyword: 'ARR / Revenue Growth', count: 3, importance: 'High' },
        { keyword: 'Experimentation / A/B', count: 3, importance: 'Medium' }
      ],
      atsChecks: [
        { id: '1', title: 'File Format & Structure', status: 'passed', score: 98, details: 'Standard layout, easily parsable fonts.', recommendation: 'All clean.' },
        { id: '2', title: 'Contact Information', status: 'passed', score: 100, details: 'Full contact details and location included.', recommendation: 'Perfect.' },
        { id: '3', title: 'Quantified Accomplishments', status: 'passed', score: 96, details: 'Every major bullet includes exact dollar figures or percentages.', recommendation: 'Standout metric density.' }
      ],
      bulletImprovements: [
        {
          id: 'b-1',
          original: 'Managed AI copilot project and improved accuracy and reduced costs.',
          improved: 'Led cross-functional team of 14 to deliver enterprise AI copilot, cutting token spend by 52% while driving RAG accuracy to 96.4% and fueling $14.4M net-new ARR.',
          impactScoreBefore: 50,
          impactScoreAfter: 98,
          keyEnhancement: 'Added team size, cost reduction %, accuracy benchmark, and exact ARR impact.',
          category: 'Impact & Metrics'
        }
      ],
      suggestedRoles: [
        'Director of Product - Generative AI',
        'Lead Technical Product Manager - Machine Learning',
        'Group Product Manager (GPM) - AI Platform',
        'Staff Enterprise AI Solutions Strategist'
      ]
    }
  },
  {
    id: 'sample-junior-dev',
    name: 'Jordan Chen - Early Career Frontend Developer',
    role: 'Frontend / React Developer',
    experienceLevel: '1.5 Years',
    fileSnippet: `JORDAN CHEN
Seattle, WA • jchen.code@gmail.com • (206) 459-0192 • github.com/jordan-chen-dev

OBJECTIVE
Passionate and motivated Junior Frontend Developer with a strong foundation in modern JavaScript, React, and CSS frameworks looking to contribute to dynamic software development teams.

TECHNICAL SKILLS
Languages: HTML, CSS, JavaScript (ES6+), basic TypeScript, Python
Frameworks: React.js, Tailwind CSS, Bootstrap, Node.js (basics)
Tools: Git, GitHub, VS Code, Figma, Postman, npm

PROJECTS
E-Commerce Storefront (React, Tailwind, Stripe API)
• Built a full-featured mock store with shopping cart, filterable catalog, and responsive checkout UI.
• Integrated Stripe test payments and stored user sessions in localStorage.

DevPulse Developer Community Portal (React, Firebase, Tailwind)
• Created user discussion board with real-time post creation, upvoting, and markdown rendering.
• Implemented authentication with Firebase Auth and real-time Firestore database.

EXPERIENCE
Junior Web Developer Intern | BluePeak Media | Seattle, WA (June 2023 - Dec 2023)
• Built landing pages for 6 local business clients using HTML5, modern CSS, and React components.
• Optimized image assets and reduced page load times by 25% on mobile devices.
• Participated in daily standups and collaborated with designers using Figma.

EDUCATION
B.S. in Information Systems | University of Washington, Seattle (2020 - 2024) • GPA: 3.6`,
    analysis: {
      fileName: 'Jordan_Chen_Junior_Frontend_Resume.pdf',
      fileSize: '950 KB',
      analyzedAt: 'Just now',
      candidateName: 'Jordan Chen',
      candidateTitle: 'Frontend / React Developer',
      candidateEmail: 'jchen.code@gmail.com',
      candidatePhone: '(206) 459-0192',
      candidateLocation: 'Seattle, WA',
      experienceYears: 1.5,
      seniorityLevel: 'Entry-Level',
      overallScore: 78,
      atsScore: 82,
      readabilityScore: 85,
      impactScore: 68,
      skillsScore: 76,
      summary: 'Solid foundational frontend resume with good modern React/Tailwind project portfolio. Needs stronger quantifiable impact metrics, deeper TypeScript exposure, and replacement of the generic Objective statement.',
      topStrengths: [
        'Relevant modern tech stack including React, Tailwind CSS, and Git.',
        'Concrete project links demonstrating end-to-end full-lifecycle development.',
        'Clean education background with strong GPA from University of Washington.'
      ],
      criticalFixes: [
        'Replace the generic "Objective" statement with a high-energy "Professional Summary" highlighting project capabilities.',
        'Strengthen project bullets with metrics (e.g. Lighthouse score, test coverage, API latency).',
        'Deepen TypeScript and automated testing (Jest / Playwright) skill presence to unlock competitive junior roles.'
      ],
      skillsMatrix: [
        {
          category: 'Core Web & Frontend',
          skills: [
            { name: 'React.js', level: 82, verifiedInResume: true },
            { name: 'JavaScript (ES6+)', level: 80, verifiedInResume: true },
            { name: 'Tailwind CSS', level: 85, verifiedInResume: true },
            { name: 'TypeScript', level: 64, verifiedInResume: true },
            { name: 'HTML5 / CSS3', level: 90, verifiedInResume: true }
          ]
        },
        {
          category: 'Tools & Ecosystem',
          skills: [
            { name: 'Git & GitHub', level: 82, verifiedInResume: true },
            { name: 'Figma to Code', level: 78, verifiedInResume: true },
            { name: 'Firebase / Firestore', level: 75, verifiedInResume: true },
            { name: 'REST APIs / Postman', level: 76, verifiedInResume: true }
          ]
        }
      ],
      allExtractedSkills: ['React', 'JavaScript', 'Tailwind CSS', 'HTML', 'CSS', 'TypeScript', 'Git', 'Firebase', 'Figma', 'Postman'],
      missingCrucialSkills: ['Jest / Unit Testing', 'Next.js', 'State Management (Redux/Zustand)', 'CI/CD Basics'],
      keywordDensity: [
        { keyword: 'React.js', count: 4, importance: 'High' },
        { keyword: 'Tailwind CSS', count: 3, importance: 'High' },
        { keyword: 'JavaScript', count: 3, importance: 'High' },
        { keyword: 'Frontend Developer', count: 2, importance: 'High' }
      ],
      atsChecks: [
        { id: '1', title: 'File Format & Structure', status: 'passed', score: 92, details: 'Clean layout, easily scanned.', recommendation: 'Good format.' },
        { id: '2', title: 'Objective vs Summary', status: 'warning', score: 70, details: 'Contains traditional Objective instead of modern Professional Summary.', recommendation: 'Switch to a 2-3 line Professional Summary.' },
        { id: '3', title: 'Quantifiable Metrics', status: 'warning', score: 65, details: 'Only 1 metric (25% load time reduction) present in work experience.', recommendation: 'Add metrics to project descriptions.' }
      ],
      bulletImprovements: [
        {
          id: 'b-1',
          original: 'Built an e-commerce store with React and Stripe.',
          improved: 'Architected responsive e-commerce application using React and Tailwind CSS, integrating Stripe checkout API with sub-2s transaction speeds and 100% test scenario passes.',
          impactScoreBefore: 42,
          impactScoreAfter: 89,
          keyEnhancement: 'Added tech stack context, checkout latency metric, and test verification.',
          category: 'Impact & Metrics'
        }
      ],
      suggestedRoles: [
        'Associate Frontend Developer',
        'Junior React Web Engineer',
        'UI Engineering Apprentice',
        'Web Applications Support Specialist'
      ]
    }
  }
];
