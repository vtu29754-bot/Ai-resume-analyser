export interface SkillCategory {
  category: string;
  skills: { name: string; level: number; verifiedInResume: boolean }[];
}

export interface BulletImprovement {
  id: string;
  original: string;
  improved: string;
  impactScoreBefore: number;
  impactScoreAfter: number;
  keyEnhancement: string;
  category: 'Impact & Metrics' | 'Leadership' | 'Action Verbs' | 'Technical Depth';
}

export interface AtsCheckItem {
  id: string;
  title: string;
  status: 'passed' | 'warning' | 'failed';
  score: number;
  details: string;
  recommendation: string;
}

export interface ResumeAnalysisResult {
  fileName: string;
  fileSize?: string;
  analyzedAt: string;
  candidateName: string;
  candidateTitle: string;
  candidateEmail: string;
  candidatePhone?: string;
  candidateLocation?: string;
  experienceYears: number;
  seniorityLevel: 'Entry-Level' | 'Mid-Level' | 'Senior' | 'Lead / Staff' | 'Executive';
  
  overallScore: number;
  atsScore: number;
  readabilityScore: number;
  impactScore: number;
  skillsScore: number;
  
  summary: string;
  topStrengths: string[];
  criticalFixes: string[];
  
  skillsMatrix: SkillCategory[];
  allExtractedSkills: string[];
  missingCrucialSkills: string[];
  
  keywordDensity: {
    keyword: string;
    count: number;
    importance: 'High' | 'Medium' | 'Low';
  }[];
  
  atsChecks: AtsCheckItem[];
  bulletImprovements: BulletImprovement[];
  suggestedRoles: string[];
}

export type JobPlatform =
  | 'LinkedIn'
  | 'Indeed'
  | 'Naukri'
  | 'Foundit'
  | 'Instahyre'
  | 'Wellfound'
  | 'Glassdoor'
  | 'Hirist'
  | 'Internshala'
  | 'Unstop'
  | 'Company Career';

export type JobDomain =
  | 'All Domains'
  | 'Full Stack & Web'
  | 'Backend & Systems'
  | 'Frontend & Mobile'
  | 'AI & Data Science'
  | 'Cloud & DevOps'
  | 'QA & Automation'
  | 'Product & Design'
  | 'Freshers & Internships';

export interface JobRecommendation {
  id: string;
  title: string;
  company: string;
  location: string;
  domain: JobDomain;
  type: 'Remote' | 'Hybrid' | 'On-site';
  employmentType: 'Full-time' | 'Contract' | 'Part-time' | 'Internship';
  salaryRange: string; // e.g. "₹24,00,000 - ₹38,00,000 / yr (24 - 38 LPA)"
  salaryINR: string; // e.g. "₹24 - 38 LPA" or "₹35,000 / mo (Stipend)"
  platform: JobPlatform;
  experienceLevel: 'Entry' | 'Mid' | 'Senior' | 'Lead' | 'Intern';
  requiredYears: string; // e.g. "4-7 years" or "0-1 years"
  matchPercentage: number;
  isExactMatch?: boolean;
  exactSkillMatchesCount?: number;
  matchBreakdown: {
    skillsMatch: number;
    experienceMatch: number;
    roleFit: number;
    atsReadiness: number;
  };
  matchedSkills: string[];
  missingSkills: string[];
  highlights: string[];
  description: string;
  postedDate: string;
  companyLogoBg: string;
  companyInitials: string;
  tags: string[];
  applyUrl: string;
  isBookmarked?: boolean;
}

export interface UserProfile {
  name: string;
  email: string;
  avatar: string;
  title: string;
  isLoggedIn: boolean;
  plan: 'Free' | 'Pro' | 'Enterprise';
  scansRemaining: number;
  savedJobIds: string[];
}

export type ActiveTab = 'analyzer' | 'jobs';
