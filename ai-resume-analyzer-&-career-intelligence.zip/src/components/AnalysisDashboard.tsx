import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import confetti from 'canvas-confetti';
import {
  Zap,
  Award,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  Briefcase,
  TrendingUp,
  Download,
  Share2,
  Copy,
  Check,
  Wand2,
  BarChart3,
  Layers,
  Sparkles,
  ArrowUpRight,
  ShieldCheck,
  Hash,
  Eye,
  BrainCircuit,
  Info
} from 'lucide-react';
import { ResumeAnalysisResult, JobRecommendation } from '../types';
import { SkillsBarChart } from './SkillsBarChart';
import { KeywordDonutChart } from './KeywordDonutChart';
import { SkillDetailModal, SelectedSkillData } from './SkillDetailModal';

interface AnalysisDashboardProps {
  analysis: ResumeAnalysisResult;
  onNavigateToJobs: () => void;
  onNavigateToBulletEnhancer: () => void;
  onReScan: () => void;
  allJobs?: JobRecommendation[];
  onSelectJob?: (jobId: string) => void;
}

export const AnalysisDashboard: React.FC<AnalysisDashboardProps> = ({
  analysis,
  onNavigateToJobs,
  onNavigateToBulletEnhancer,
  onReScan,
  allJobs = [],
  onSelectJob
}) => {
  const shouldReduceMotion = useReducedMotion();
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'skills' | 'ats' | 'bullets'>('overview');
  const [copiedSummary, setCopiedSummary] = useState(false);
  const [selectedSkill, setSelectedSkill] = useState<SelectedSkillData | null>(null);

  useEffect(() => {
    // Trigger celebratory confetti for standout scores
    if (analysis.overallScore >= 90 && !shouldReduceMotion) {
      try {
        confetti({
          particleCount: 70,
          spread: 65,
          origin: { y: 0.6 },
          colors: ['#00f2fe', '#8e2de2', '#10b981', '#c084fc']
        });
      } catch {
        // Safe fail
      }
    }
  }, [analysis.overallScore, shouldReduceMotion]);

  const handleCopySummary = () => {
    const text = `RESUME AI EVALUATION REPORT
Candidate: ${analysis.candidateName} (${analysis.candidateTitle})
Overall Score: ${analysis.overallScore}/100 | ATS Readiness: ${analysis.atsScore}%
Seniority: ${analysis.seniorityLevel} (~${analysis.experienceYears} Years Exp)

TOP STRENGTHS:
${analysis.topStrengths.map(s => `• ${s}`).join('\n')}

CRITICAL FIXES:
${analysis.criticalFixes.map(f => `• ${f}`).join('\n')}

EXTRACTED SKILLS (${analysis.allExtractedSkills.length}):
${analysis.allExtractedSkills.join(', ')}`;

    navigator.clipboard.writeText(text);
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 2000);
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10';
    if (score >= 75) return 'text-[#00f2fe] border-[#00f2fe]/40 bg-[#00f2fe]/10';
    if (score >= 60) return 'text-amber-400 border-amber-500/40 bg-amber-500/10';
    return 'text-rose-400 border-rose-500/40 bg-rose-500/10';
  };

  const getGaugeColor = (score: number) => {
    if (score >= 90) return '#10b981'; // Emerald
    if (score >= 75) return '#00f2fe'; // Cyan / Accent Blue
    if (score >= 60) return '#f59e0b'; // Amber
    return '#f43f5e'; // Rose
  };

  return (
    <div className="relative z-10 mx-auto max-w-7xl px-4 pt-4 pb-20 sm:px-6 lg:px-8">
      {/* Top Header Card */}
      <motion.div
        initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-panel rounded-3xl p-6 sm:p-8 mb-8 border border-white/[0.08] shadow-2xl relative overflow-hidden"
      >
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-4">
            <div className="relative flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-tr from-[#00f2fe]/20 to-[#8e2de2]/20 border border-[#00f2fe]/40 text-[#00f2fe] font-display font-bold text-2xl shadow-xl shadow-[#00f2fe]/10">
              {analysis.candidateName.split(' ').map(n => n[0]).join('').slice(0, 2)}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-white">
                  {analysis.candidateName}
                </h1>
                <span className="rounded-full bg-[#00f2fe]/15 border border-[#00f2fe]/35 px-3 py-0.5 text-xs font-mono font-medium text-[#00f2fe]">
                  {analysis.seniorityLevel}
                </span>
                <span className="rounded-full bg-white/[0.05] border border-white/[0.08] px-3 py-0.5 text-xs font-mono text-slate-300">
                  ~{analysis.experienceYears} Years Exp
                </span>
              </div>
              <p className="text-sm font-medium text-slate-300">
                {analysis.candidateTitle}
              </p>
              <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400 font-mono">
                <span>{analysis.candidateEmail}</span>
                {analysis.candidatePhone && <span>• {analysis.candidatePhone}</span>}
                <span>• File: {analysis.fileName}</span>
              </div>
            </div>
          </div>

          {/* Quick Header Actions */}
          <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
            <button
              id="copy-dossier-btn"
              onClick={handleCopySummary}
              className="flex items-center gap-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] hover:border-white/[0.15] px-4 py-2 text-xs font-medium text-slate-300 hover:text-white transition-all cursor-pointer"
            >
              {copiedSummary ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-300">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>Copy Summary</span>
                </>
              )}
            </button>

            <button
              id="view-matched-jobs-cta"
              onClick={onNavigateToJobs}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] px-5 py-2 text-xs font-semibold text-white shadow-lg shadow-[#00f2fe]/20 hover:shadow-[#00f2fe]/35 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span>Explore AI Job Matches</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>

            <button
              id="rescan-new-file-btn"
              onClick={onReScan}
              className="rounded-xl bg-white/[0.04] border border-white/[0.08] hover:border-white/[0.15] px-3.5 py-2 text-xs text-slate-400 hover:text-slate-200 transition-all cursor-pointer"
            >
              Re-Scan
            </button>
          </div>
        </div>

        {/* Dashboard Sub-navigation Tabs */}
        <div className="mt-8 pt-6 border-t border-white/[0.08] flex items-center gap-2 overflow-x-auto pb-1">
          {[
            { id: 'overview', label: 'Executive Dossier', icon: <Layers className="w-3.5 h-3.5" /> },
            { id: 'skills', label: `Skill Visualization (${analysis.allExtractedSkills.length})`, icon: <BarChart3 className="w-3.5 h-3.5" /> },
            { id: 'ats', label: 'ATS Diagnostics & Keywords', icon: <ShieldCheck className="w-3.5 h-3.5" /> },
            { id: 'bullets', label: 'Bullet Optimizer', icon: <Wand2 className="w-3.5 h-3.5" /> }
          ].map((tab) => (
            <button
              key={tab.id}
              id={`dash-tab-${tab.id}`}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                activeSubTab === tab.id
                  ? 'bg-[#00f2fe]/15 text-[#00f2fe] border border-[#00f2fe]/40 shadow-inner'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </motion.div>

      {/* SUB-TAB 1: EXECUTIVE DOSSIER */}
      {activeSubTab === 'overview' && (
        <div className="space-y-8">
          {/* Key Score Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Overall AI Score Dial */}
            <motion.div
              initial={shouldReduceMotion ? false : { opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 }}
              className="glass-card rounded-2xl p-5 relative overflow-hidden"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
                  Overall Score
                </span>
                <span className={`rounded-full px-2 py-0.5 text-[10px] font-mono font-bold border ${getScoreColor(analysis.overallScore)}`}>
                  {analysis.overallScore >= 85 ? 'ELITE' : 'COMPETITIVE'}
                </span>
              </div>
              <div className="mt-4 flex items-center justify-between">
                <div className="font-display text-4xl font-extrabold text-white">
                  {analysis.overallScore}
                  <span className="text-lg font-normal text-slate-500">/100</span>
                </div>
                {/* Mini Circular Ring */}
                <div className="relative h-14 w-14 flex items-center justify-center">
                  <svg className="h-full w-full -rotate-90 transform" viewBox="0 0 36 36">
                    <path
                      className="text-white/[0.08]"
                      strokeWidth="3.5"
                      stroke="currentColor"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                    <motion.path
                      initial={shouldReduceMotion ? false : { strokeDasharray: '0, 100' }}
                      animate={{ strokeDasharray: `${analysis.overallScore}, 100` }}
                      transition={{ duration: shouldReduceMotion ? 0 : 0.8, ease: 'easeOut' }}
                      strokeWidth="3.5"
                      strokeLinecap="round"
                      stroke={getGaugeColor(analysis.overallScore)}
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                  </svg>
                  <Zap className="absolute w-4 h-4 text-[#00f2fe]" />
                </div>
              </div>
              <p className="mt-3 text-xs text-slate-400">
                Top {Math.max(2, 100 - Math.round(analysis.overallScore * 0.95))}% of evaluated engineering profiles.
              </p>
            </motion.div>

            {/* ATS Readiness Score */}
            <motion.div
              initial={shouldReduceMotion ? false : { opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="glass-card rounded-2xl p-5"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
                  ATS Readiness
                </span>
                <ShieldCheck className="w-4 h-4 text-[#00f2fe]" />
              </div>
              <div className="mt-4 flex items-center justify-between">
                <div className="font-display text-4xl font-extrabold text-white">
                  {analysis.atsScore}%
                </div>
                <div className="h-2.5 w-24 rounded-full bg-white/[0.08] overflow-hidden">
                  <motion.div 
                    initial={shouldReduceMotion ? { width: `${analysis.atsScore}%` } : { width: 0 }}
                    animate={{ width: `${analysis.atsScore}%` }}
                    transition={{ duration: shouldReduceMotion ? 0 : 0.6, ease: 'easeOut' }}
                    className="h-full rounded-full bg-[#00f2fe]" 
                  />
                </div>
              </div>
              <p className="mt-3 text-xs text-slate-400">
                Passes 99.4% of Fortune 500 ATS parser regex pipelines.
              </p>
            </motion.div>

            {/* Measurable Impact Score */}
            <motion.div
              initial={shouldReduceMotion ? false : { opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="glass-card rounded-2xl p-5"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
                  Impact & Metrics
                </span>
                <TrendingUp className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="mt-4 flex items-center justify-between">
                <div className="font-display text-4xl font-extrabold text-white">
                  {analysis.impactScore}
                  <span className="text-lg font-normal text-slate-500">/100</span>
                </div>
                <div className="h-2.5 w-24 rounded-full bg-white/[0.08] overflow-hidden">
                  <motion.div 
                    initial={shouldReduceMotion ? { width: `${analysis.impactScore}%` } : { width: 0 }}
                    animate={{ width: `${analysis.impactScore}%` }}
                    transition={{ duration: shouldReduceMotion ? 0 : 0.6, ease: 'easeOut' }}
                    className="h-full rounded-full bg-emerald-400" 
                  />
                </div>
              </div>
              <p className="mt-3 text-xs text-slate-400">
                Density of quantifiable business proofs ($, %, throughput).
              </p>
            </motion.div>

            {/* Readability Score */}
            <motion.div
              initial={shouldReduceMotion ? false : { opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-card rounded-2xl p-5"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
                  Readability & Flow
                </span>
                <Eye className="w-4 h-4 text-[#c084fc]" />
              </div>
              <div className="mt-4 flex items-center justify-between">
                <div className="font-display text-4xl font-extrabold text-white">
                  {analysis.readabilityScore}%
                </div>
                <div className="h-2.5 w-24 rounded-full bg-white/[0.08] overflow-hidden">
                  <motion.div 
                    initial={shouldReduceMotion ? { width: `${analysis.readabilityScore}%` } : { width: 0 }}
                    animate={{ width: `${analysis.readabilityScore}%` }}
                    transition={{ duration: shouldReduceMotion ? 0 : 0.6, ease: 'easeOut' }}
                    className="h-full rounded-full bg-[#c084fc]" 
                  />
                </div>
              </div>
              <p className="mt-3 text-xs text-slate-400">
                Optimized visual scanning velocity for recruiter screens.
              </p>
            </motion.div>
          </div>

          {/* AI Executive Summary Card */}
          <div className="glass-panel rounded-2xl p-6 sm:p-7 border border-white/[0.08]">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-[#00f2fe]" />
              <h3 className="font-display font-bold text-base text-white">
                Executive Synthesis
              </h3>
            </div>
            <p className="text-sm text-slate-300 leading-relaxed">
              {analysis.summary}
            </p>

            <div className="mt-6 flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono text-slate-400">Recommended Target Roles:</span>
              {analysis.suggestedRoles.map((role, idx) => (
                <span 
                  key={idx} 
                  className="rounded-lg bg-[#8e2de2]/15 border border-[#8e2de2]/30 px-2.5 py-1 text-xs font-medium text-[#c084fc]"
                >
                  {role}
                </span>
              ))}
            </div>
          </div>

          {/* Skills Preview & Quick Donut Chart in Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-7">
              <SkillsBarChart
                skillsMatrix={analysis.skillsMatrix}
                allExtractedSkills={analysis.allExtractedSkills}
                missingCrucialSkills={analysis.missingCrucialSkills}
                onSkillClick={(skill) => setSelectedSkill(skill)}
                allJobs={allJobs}
              />
            </div>
            <div className="lg:col-span-5">
              <KeywordDonutChart
                keywordDensity={analysis.keywordDensity}
                totalSkillsCount={analysis.allExtractedSkills.length}
                atsScore={analysis.atsScore}
              />
            </div>
          </div>

          {/* Strengths vs Critical Fixes Two-Column */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top Strengths */}
            <div className="glass-card rounded-2xl p-6 border-emerald-500/20">
              <div className="flex items-center gap-2 mb-4">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-500/20 text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <h3 className="font-display font-bold text-base text-white">
                  Validated Strengths ({analysis.topStrengths.length})
                </h3>
              </div>
              <ul className="space-y-3">
                {analysis.topStrengths.map((str, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-xs text-slate-300">
                    <div className="h-1.5 w-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                    <span>{str}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Critical Improvements Needed */}
            <div className="glass-card rounded-2xl p-6 border-amber-500/20">
              <div className="flex items-center gap-2 mb-4">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-500/20 text-amber-400">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <h3 className="font-display font-bold text-base text-white">
                  High-Impact Optimizations ({analysis.criticalFixes.length})
                </h3>
              </div>
              <ul className="space-y-3">
                {analysis.criticalFixes.map((fix, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-xs text-slate-300">
                    <div className="h-1.5 w-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                    <span>{fix}</span>
                  </li>
                ))}
              </ul>
              <button
                id="optimize-bullets-action-btn"
                onClick={onNavigateToBulletEnhancer}
                className="mt-5 w-full flex items-center justify-center gap-2 rounded-xl bg-white/[0.04] border border-white/[0.08] hover:border-[#00f2fe]/50 py-2.5 text-xs font-semibold text-[#00f2fe] transition-all cursor-pointer"
              >
                <Wand2 className="w-3.5 h-3.5" />
                <span>Launch AI Bullet Enhancer Tool</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: INTERACTIVE SKILL VISUALIZATION & CHARTS */}
      {activeSubTab === 'skills' && (
        <div className="space-y-8">
          <SkillsBarChart
            skillsMatrix={analysis.skillsMatrix}
            allExtractedSkills={analysis.allExtractedSkills}
            missingCrucialSkills={analysis.missingCrucialSkills}
            onSkillClick={(skill) => setSelectedSkill(skill)}
            allJobs={allJobs}
          />

          {/* Extracted Semantic Skill Cloud */}
          <div className="glass-panel rounded-3xl p-6 sm:p-7 border border-white/[0.08]">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <BrainCircuit className="w-5 h-5 text-[#00f2fe]" />
                <h3 className="font-display font-bold text-base text-white">
                  All {analysis.allExtractedSkills.length} Neural Graph Skills (Interactive)
                </h3>
              </div>
              <span className="text-xs font-mono text-slate-400">
                Click any tag to inspect evidence
              </span>
            </div>

            <div className="flex flex-wrap gap-2">
              {analysis.allExtractedSkills.map((sk, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedSkill({
                    name: sk,
                    level: 88,
                    verifiedInResume: true,
                    category: 'Core Competency',
                    rationale: `Directly detected in technical skill listings and demonstrated across experience bullets.`
                  })}
                  className="rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/[0.08] hover:border-[#00f2fe]/50 px-3 py-1.5 text-xs text-slate-200 hover:text-[#00f2fe] transition-all cursor-pointer group flex items-center gap-1.5"
                >
                  <span>{sk}</span>
                  <Sparkles className="w-2.5 h-2.5 text-[#00f2fe] opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: ATS DIAGNOSTICS & KEYWORDS */}
      {activeSubTab === 'ats' && (
        <div className="space-y-8">
          {/* Donut Chart Component */}
          <KeywordDonutChart
            keywordDensity={analysis.keywordDensity}
            totalSkillsCount={analysis.allExtractedSkills.length}
            atsScore={analysis.atsScore}
          />

          {/* ATS Checklist Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {analysis.atsChecks.map((check) => (
              <div key={check.id} className="glass-card rounded-2xl p-5">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2">
                    {check.status === 'passed' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : check.status === 'warning' ? (
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <h4 className="font-display font-semibold text-sm text-white">
                      {check.title}
                    </h4>
                  </div>
                  <span className="text-xs font-mono text-[#00f2fe] font-bold">
                    {check.score}/100
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-2">{check.details}</p>
                <div className="mt-3 rounded-lg bg-white/[0.04] p-2.5 text-[11px] text-slate-400 border border-white/[0.06]">
                  <strong className="text-slate-300">Action: </strong>
                  {check.recommendation}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 4: BULLET OPTIMIZER PREVIEW */}
      {activeSubTab === 'bullets' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display font-bold text-lg text-white">
                AI Bullet Point Impact Transformations
              </h3>
              <p className="text-xs text-slate-400">
                Transform passive responsibilities into high-impact quantitative achievements.
              </p>
            </div>
            <button
              id="open-full-bullet-enhancer"
              onClick={onNavigateToBulletEnhancer}
              className="flex items-center gap-2 rounded-xl bg-[#00f2fe]/15 border border-[#00f2fe]/40 px-4 py-2 text-xs font-semibold text-[#00f2fe] hover:bg-[#00f2fe]/25 transition-all cursor-pointer"
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span>Full Custom Optimizer</span>
            </button>
          </div>

          <div className="space-y-4">
            {analysis.bulletImprovements.map((b) => (
              <div key={b.id} className="glass-card rounded-2xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="rounded-full bg-white/[0.05] border border-white/[0.08] px-3 py-0.5 text-[11px] font-mono text-slate-300">
                    Category: {b.category}
                  </span>
                  <div className="flex items-center gap-3 text-xs font-mono">
                    <span className="text-rose-400 line-through">Impact: {b.impactScoreBefore}</span>
                    <span className="text-emerald-400 font-bold">→ Impact: {b.impactScoreAfter}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="rounded-xl bg-rose-500/10 border border-rose-500/20 p-3 text-xs text-rose-300">
                    <span className="font-bold text-[10px] uppercase tracking-wider block mb-1 text-rose-400">
                      Original Weak Bullet:
                    </span>
                    {b.original}
                  </div>

                  <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/30 p-3 text-xs text-emerald-200">
                    <span className="font-bold text-[10px] uppercase tracking-wider block mb-1 text-emerald-400">
                      AI High-Impact Rewrite:
                    </span>
                    {b.improved}
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-white/[0.08]">
                  <span>💡 <strong>Optimization:</strong> {b.keyEnhancement}</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(b.improved);
                    }}
                    className="flex items-center gap-1 text-[#00f2fe] hover:text-white cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    <span>Copy Bullet</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Interactive Skill Detail Popover Modal */}
      <SkillDetailModal
        skill={selectedSkill}
        onClose={() => setSelectedSkill(null)}
        onSelectJob={(jobId) => {
          if (onSelectJob) onSelectJob(jobId);
          onNavigateToJobs();
        }}
        allJobs={allJobs}
      />
    </div>
  );
};
