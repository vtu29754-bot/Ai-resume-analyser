import React, { useState, useRef } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { 
  FileUp, 
  Sparkles, 
  ShieldCheck, 
  Zap, 
  FileText, 
  CheckCircle2, 
  ArrowRight, 
  Cpu, 
  BrainCircuit, 
  UploadCloud,
  FileCheck,
  AlertCircle,
  RefreshCw,
  X,
  FileCode
} from 'lucide-react';
import { ResumeAnalysisResult } from '../types';
import { SAMPLE_RESUMES, SampleResume } from '../data/sampleResumes';
import { analyzeResumeContent } from '../utils/aiAnalyzer';

interface ResumeUploaderProps {
  onAnalysisComplete: (analysis: ResumeAnalysisResult) => void;
  isScanning: boolean;
  setIsScanning: (scanning: boolean) => void;
}

export const ResumeUploader: React.FC<ResumeUploaderProps> = ({
  onAnalysisComplete,
  isScanning,
  setIsScanning
}) => {
  const shouldReduceMotion = useReducedMotion();
  const [activeTab, setActiveTab] = useState<'upload' | 'paste' | 'samples'>('upload');
  const [dragActive, setDragActive] = useState(false);
  const [pastedText, setPastedText] = useState('');
  const [scanStep, setScanStep] = useState(0);
  const [scanProgress, setScanProgress] = useState(0);
  const [selectedFileName, setSelectedFileName] = useState<string>('');
  const [selectedFileSize, setSelectedFileSize] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [hasError, setHasError] = useState(false);
  const [successResult, setSuccessResult] = useState<ResumeAnalysisResult | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const scanningSteps = [
    { title: 'Extracting typography & visual hierarchy', desc: 'Parsing headers, dates, and contact coordinates' },
    { title: 'Neural semantic skill extraction', desc: 'Cross-referencing 2,500+ technical & management competencies' },
    { title: 'ATS syntax & keyword density validation', desc: 'Evaluating against Tier-1 enterprise recruiting systems' },
    { title: 'Calibrating match fit & bullet metrics', desc: 'Ranking market fit, salary parity, and high-impact rewrites' }
  ];

  const handleFileUpload = async (file: File) => {
    if (!file) return;

    // Reset states
    setErrorMessage(null);
    setHasError(false);
    setSuccessResult(null);

    // Validate size (max 15MB)
    if (file.size > 15 * 1024 * 1024) {
      setErrorMessage('File exceeds maximum size limit of 15MB. Please upload a smaller document.');
      setHasError(true);
      return;
    }

    const fileSizeFormatted = `${(file.size / (1024 * 1024)).toFixed(1)} MB`;
    setSelectedFileName(file.name);
    setSelectedFileSize(fileSizeFormatted);
    setIsScanning(true);
    setScanStep(0);
    setScanProgress(15);

    try {
      let extractedText = '';
      if (file.type.includes('text') || file.name.endsWith('.txt')) {
        extractedText = await file.text();
      } else {
        const matchedSample = SAMPLE_RESUMES.find(s => s.analysis.fileName.toLowerCase() === file.name.toLowerCase());
        if (matchedSample) {
          extractedText = matchedSample.fileSnippet;
        } else {
          // Robust candidate template for demo
          extractedText = `CANDIDATE PROFILE: ${file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ')}
Software Engineer • candidate.ai.profile@gmail.com • (555) 492-0193 • San Francisco, CA

PROFESSIONAL SUMMARY
Experienced Software Engineer specialized in React, Next.js, TypeScript, Node.js, Python, and AWS cloud infrastructure. Passionate about building resilient distributed systems and responsive user experiences.

EXPERIENCE
Senior Software Engineer | TechScale Solutions (2021 - Present)
• Architected scalable cloud microservices handling over 5,000,000 daily API requests with 99.95% uptime.
• Reduced p99 latency by 35% through Redis caching and query indexing on PostgreSQL.
• Mentored 4 engineers and improved team sprint velocity by 28%.

Software Engineer | WebCore Inc (2018 - 2021)
• Built interactive client-facing dashboards using React, Redux, and Tailwind CSS.
• Integrated RESTful and GraphQL endpoints, improving end-to-end load times by 40%.

SKILLS
React, Next.js, TypeScript, JavaScript, Node.js, Express, Python, AWS, Docker, Kubernetes, PostgreSQL, Redis, GraphQL, Git, CI/CD.

EDUCATION
B.S. in Computer Science • University of California`;
        }
      }

      // Step 1
      await new Promise(r => setTimeout(r, 600));
      setScanStep(1);
      setScanProgress(45);

      // Step 2
      await new Promise(r => setTimeout(r, 650));
      setScanStep(2);
      setScanProgress(75);

      // Step 3
      await new Promise(r => setTimeout(r, 600));
      setScanStep(3);
      setScanProgress(95);

      const result = await analyzeResumeContent(extractedText, file.name, fileSizeFormatted);
      
      // Step 4 Complete
      setScanProgress(100);
      setSuccessResult(result);
      await new Promise(r => setTimeout(r, 700));

      setIsScanning(false);
      onAnalysisComplete(result);
    } catch (err: any) {
      setIsScanning(false);
      setHasError(true);
      setErrorMessage('Failed to parse document. Please upload a standard PDF, Word doc (.docx), or paste text directly.');
    }
  };

  const handlePasteSubmit = async () => {
    if (!pastedText.trim() || pastedText.length < 50) {
      setHasError(true);
      setErrorMessage('Please paste at least 50 characters of resume content to run analysis.');
      return;
    }
    setErrorMessage(null);
    setHasError(false);
    setSuccessResult(null);
    setIsScanning(true);
    setScanStep(0);
    setScanProgress(20);
    setSelectedFileName('Pasted_Resume_Text.txt');
    setSelectedFileSize('12 KB');

    try {
      await new Promise(r => setTimeout(r, 550));
      setScanStep(1);
      setScanProgress(50);

      await new Promise(r => setTimeout(r, 600));
      setScanStep(2);
      setScanProgress(80);

      await new Promise(r => setTimeout(r, 550));
      setScanStep(3);
      setScanProgress(95);

      const result = await analyzeResumeContent(pastedText, 'Pasted_Resume_Text.txt', '12 KB');
      setScanProgress(100);
      setSuccessResult(result);
      await new Promise(r => setTimeout(r, 600));

      setIsScanning(false);
      onAnalysisComplete(result);
    } catch (err: any) {
      setIsScanning(false);
      setHasError(true);
      setErrorMessage('An unexpected error occurred while parsing the text. Please try again.');
    }
  };

  const handleSelectSample = async (sample: SampleResume) => {
    setErrorMessage(null);
    setHasError(false);
    setSuccessResult(null);
    setIsScanning(true);
    setScanStep(0);
    setScanProgress(25);
    setSelectedFileName(sample.analysis.fileName);
    setSelectedFileSize(sample.analysis.fileSize || '1.8 MB');

    for (let i = 1; i <= 3; i++) {
      await new Promise(r => setTimeout(r, 450));
      setScanStep(i);
      setScanProgress(25 + i * 25);
    }

    setScanProgress(100);
    setSuccessResult(sample.analysis);
    await new Promise(r => setTimeout(r, 500));

    setIsScanning(false);
    onAnalysisComplete(sample.analysis);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="relative z-10 mx-auto max-w-6xl px-4 pt-8 pb-20 sm:px-6 lg:px-8">
      {/* Hero Section */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <motion.div
          initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="inline-flex items-center gap-2 rounded-full glass-panel px-4 py-1.5 border border-[#00f2fe]/30 text-xs font-mono text-[#00f2fe] mb-5 shadow-lg shadow-[#00f2fe]/10"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#00f2fe]" />
          <span>AI Resume Scanner & Job Match Engine</span>
        </motion.div>

        <motion.h1 
          initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.1 }}
          className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.12]"
        >
          Every resume tells a story. <br className="hidden sm:block" />
          <span className="text-gradient-cyan">Discover & apply to your best match.</span>
        </motion.h1>

        <motion.p
          initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.2 }}
          className="mt-5 text-base sm:text-lg text-slate-300 leading-relaxed"
        >
          Instant ATS scoring, skill extraction, and tailored job recommendations with direct 1-click links to apply on official company career portals.
        </motion.p>
      </div>

      {/* Main Upload / Input Card */}
      <motion.div
        initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, scale: 0.98 }}
        animate={
          hasError && !shouldReduceMotion
            ? { x: [-8, 8, -6, 6, -3, 3, 0], opacity: 1, scale: 1 }
            : { opacity: 1, scale: 1 }
        }
        transition={{ duration: 0.4 }}
        className={`glass-panel-glow rounded-3xl p-6 sm:p-8 lg:p-10 relative overflow-hidden shadow-2xl transition-all duration-300 ${
          hasError ? 'border-rose-500/50 shadow-rose-500/10' : 'border-white/[0.08]'
        }`}
      >
        {/* Background Ambience */}
        <div className="pointer-events-none absolute -top-40 -left-40 h-80 w-80 rounded-full bg-[#00f2fe]/15 blur-[100px]" />
        <div className="pointer-events-none absolute -bottom-40 -right-40 h-80 w-80 rounded-full bg-[#8e2de2]/15 blur-[100px]" />

        {/* Input Mode Tabs */}
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="flex rounded-xl bg-white/[0.03] p-1.5 border border-white/[0.08] backdrop-blur-md">
            <button
              id="tab-upload-file"
              onClick={() => {
                setActiveTab('upload');
                setErrorMessage(null);
                setHasError(false);
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'upload'
                  ? 'bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <UploadCloud className="w-4 h-4" />
              <span>Upload Document</span>
            </button>

            <button
              id="tab-paste-text"
              onClick={() => {
                setActiveTab('paste');
                setErrorMessage(null);
                setHasError(false);
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'paste'
                  ? 'bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Paste Text</span>
            </button>

            <button
              id="tab-sample-resumes"
              onClick={() => {
                setActiveTab('samples');
                setErrorMessage(null);
                setHasError(false);
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'samples'
                  ? 'bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-4 h-4 text-[#00f2fe]" />
              <span>Sample Profiles (1-Click)</span>
            </button>
          </div>
        </div>

        {/* Distinct Visual Error Alert State */}
        {hasError && errorMessage && (
          <motion.div
            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 rounded-2xl bg-rose-500/15 border border-rose-500/40 p-4 text-xs text-rose-200 shadow-lg shadow-rose-500/10"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 shrink-0">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <p className="font-semibold text-white">Upload Error Detected</p>
                <p className="text-rose-300 mt-0.5">{errorMessage}</p>
              </div>
            </div>

            <button
              onClick={() => {
                setHasError(false);
                setErrorMessage(null);
                fileInputRef.current?.click();
              }}
              className="inline-flex items-center gap-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors cursor-pointer shrink-0"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Try Again</span>
            </button>
          </motion.div>
        )}

        {/* Tab 1: Drag & Drop Upload Zone */}
        {activeTab === 'upload' && (
          <div>
            <div
              id="resume-dropzone"
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  fileInputRef.current?.click();
                }
              }}
              className={`relative cursor-pointer rounded-2xl border-2 border-dashed p-10 sm:p-14 text-center transition-all duration-300 overflow-hidden ${
                dragActive
                  ? 'border-[#00f2fe] bg-[#00f2fe]/10 scale-[1.01] shadow-2xl shadow-[#00f2fe]/20'
                  : 'border-white/[0.12] hover:border-[#00f2fe]/50 bg-white/[0.02] hover:bg-white/[0.05]'
              }`}
            >
              {/* Subtle Scanning Line on Hover */}
              <div className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-transparent via-[#00f2fe] to-transparent opacity-40 animate-scan-line" />

              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept=".pdf,.docx,.doc,.txt,.rtf,.png,.jpg,.jpeg"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileUpload(e.target.files[0]);
                  }
                }}
              />

              <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-[#00f2fe]/20 via-[#6366f1]/20 to-[#8e2de2]/20 border border-[#00f2fe]/40 text-[#00f2fe] shadow-xl shadow-[#00f2fe]/15 group-hover:scale-105 transition-transform duration-300">
                <FileUp className="w-10 h-10 text-[#00f2fe]" />
              </div>

              <h3 className="mt-6 text-xl sm:text-2xl font-bold font-display text-white">
                Drag & drop your resume file here
              </h3>
              <p className="mt-2 text-sm text-slate-400 max-w-md mx-auto">
                Supports PDF, Word (<code className="text-[#00f2fe]">.docx</code>), Plain Text, or Scanned Docs (max 15MB)
              </p>

              <div className="mt-6 inline-flex items-center gap-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.09] border border-white/[0.1] px-5 py-2.5 text-xs font-semibold text-[#00f2fe] transition-colors">
                <FileCheck className="w-4 h-4" />
                <span>Browse Local File</span>
              </div>
            </div>

            {/* Quick Sample Profiles Bar */}
            <div className="mt-8 pt-6 border-t border-white/[0.08]">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <span className="text-xs font-mono text-slate-400 flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-[#00f2fe]" />
                  Or test with verified career profiles:
                </span>
                <div className="flex flex-wrap items-center gap-2">
                  {SAMPLE_RESUMES.map((sample) => (
                    <button
                      key={sample.id}
                      id={`sample-quick-${sample.id}`}
                      onClick={() => handleSelectSample(sample)}
                      className="rounded-lg bg-white/[0.04] border border-white/[0.08] hover:border-[#00f2fe]/40 px-3 py-1.5 text-xs text-slate-300 hover:text-[#00f2fe] transition-all cursor-pointer"
                    >
                      {sample.name.split('-')[0]}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Direct Text Paste */}
        {activeTab === 'paste' && (
          <div className="space-y-4">
            <label className="block text-xs font-mono text-slate-400">
              Paste raw resume text (experience, summary, technical skills, education):
            </label>
            <textarea
              id="resume-paste-input"
              rows={10}
              value={pastedText}
              onChange={(e) => setPastedText(e.target.value)}
              placeholder="Paste full resume text here (e.g. John Doe, Senior Full Stack Developer, experience bullets...)"
              className="w-full rounded-2xl glass-input p-4 font-mono text-xs text-slate-200 placeholder:text-slate-500 focus:ring-1 focus:ring-[#00f2fe]"
            />
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-slate-500">
                {pastedText.length} characters entered
              </span>
              <button
                id="analyze-pasted-btn"
                onClick={handlePasteSubmit}
                disabled={pastedText.length < 50}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] px-6 py-2.5 text-xs font-semibold text-white shadow-lg disabled:opacity-40 disabled:cursor-not-allowed hover:shadow-[#00f2fe]/30 transition-all cursor-pointer"
              >
                <Zap className="w-4 h-4 fill-white" />
                <span>Run Instant AI Audit</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 3: Curated Sample Profiles */}
        {activeTab === 'samples' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {SAMPLE_RESUMES.map((sample) => (
              <div
                key={sample.id}
                id={`sample-card-${sample.id}`}
                onClick={() => handleSelectSample(sample)}
                role="button"
                tabIndex={0}
                className="glass-card rounded-2xl p-5 cursor-pointer flex flex-col justify-between group hover:border-[#00f2fe]/40"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="rounded-full bg-[#00f2fe]/15 border border-[#00f2fe]/35 px-2.5 py-0.5 text-[10px] font-mono text-[#00f2fe] font-semibold">
                      {sample.experienceLevel}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">
                      Score: <strong className="text-emerald-400">{sample.analysis.overallScore}</strong>
                    </span>
                  </div>
                  <h4 className="font-display font-bold text-sm text-white group-hover:text-[#00f2fe] transition-colors">
                    {sample.name}
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">{sample.role}</p>
                  <div className="mt-3 flex flex-wrap gap-1">
                    {sample.analysis.allExtractedSkills.slice(0, 4).map((sk, idx) => (
                      <span key={idx} className="rounded bg-white/[0.05] border border-white/[0.06] px-1.5 py-0.5 text-[10px] text-slate-300">
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-white/[0.08] flex items-center justify-between text-xs font-semibold text-[#00f2fe] group-hover:translate-x-1 transition-transform">
                  <span>Load Profile & Audit</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Feature Guarantees Strip */}
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4 pt-8 border-t border-white/[0.08]">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold text-white">100% Privacy Preserved</p>
              <p className="text-[11px] text-slate-400">Documents parsed on-device or encrypted</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#00f2fe]/10 border border-[#00f2fe]/30 text-[#00f2fe]">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold text-white">Sub-Second Processing</p>
              <p className="text-[11px] text-slate-400">Parallel neural AST tokenizers</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#8e2de2]/10 border border-[#8e2de2]/30 text-[#c084fc]">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold text-white">Dynamic AI Job Matching</p>
              <p className="text-[11px] text-slate-400">Semantic salary and market recalculation</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Scanning Modal with Animated Progress & Distinct Success State */}
      <AnimatePresence>
        {isScanning && (
          <motion.div
            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-[#05070a]/85 backdrop-blur-xl p-4"
          >
            <motion.div
              initial={shouldReduceMotion ? { opacity: 1 } : { scale: 0.92, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.92, opacity: 0, y: 10 }}
              className="w-full max-w-lg rounded-3xl glass-panel-glow p-6 sm:p-8 shadow-2xl border border-[#00f2fe]/40 text-center relative overflow-hidden"
            >
              {/* Radar Grid Ambience */}
              <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#00f2fe_1px,transparent_1px)] [background-size:16px_16px]" />

              {/* Top Animated Icon */}
              <div className="relative mx-auto flex h-20 w-20 items-center justify-center rounded-2xl bg-[#00f2fe]/20 border border-[#00f2fe]/50 shadow-xl shadow-[#00f2fe]/30 mb-6">
                {scanProgress === 100 ? (
                  <motion.div
                    initial={shouldReduceMotion ? false : { scale: 0.5, rotate: -20 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ type: 'spring', damping: 12 }}
                  >
                    <CheckCircle2 className="w-10 h-10 text-emerald-400" />
                  </motion.div>
                ) : (
                  <>
                    <BrainCircuit className={`w-10 h-10 text-[#00f2fe] ${shouldReduceMotion ? '' : 'animate-pulse'}`} />
                    {!shouldReduceMotion && (
                      <span className="absolute -top-1 -right-1 flex h-4 w-4">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00f2fe] opacity-75" />
                        <span className="relative inline-flex rounded-full h-4 w-4 bg-[#00f2fe]" />
                      </span>
                    )}
                  </>
                )}
              </div>

              <h3 className="font-display font-bold text-xl sm:text-2xl text-white">
                {scanProgress === 100 ? 'Audit Complete!' : 'Deep Scanning Resume'}
              </h3>
              
              <div className="flex items-center justify-center gap-2 text-xs font-mono text-slate-300 mt-1">
                <span className="text-[#00f2fe] truncate max-w-[220px]">{selectedFileName || 'Candidate_Dossier.pdf'}</span>
                {selectedFileSize && <span>• {selectedFileSize}</span>}
              </div>

              {/* Step Checklist */}
              <div className="mt-8 space-y-3 text-left">
                {scanningSteps.map((step, idx) => {
                  const isDone = scanStep > idx || scanProgress === 100;
                  const isCurrent = scanStep === idx && scanProgress < 100;

                  return (
                    <div
                      key={idx}
                      className={`flex items-start gap-3 rounded-xl p-3 transition-all ${
                        isCurrent
                          ? 'bg-[#00f2fe]/15 border border-[#00f2fe]/40'
                          : isDone
                          ? 'bg-white/[0.04] border border-white/[0.08] text-slate-300'
                          : 'opacity-40'
                      }`}
                    >
                      <div className="mt-0.5">
                        {isDone ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        ) : isCurrent ? (
                          <div className={`h-4 w-4 rounded-full border-2 border-[#00f2fe] border-t-transparent ${shouldReduceMotion ? '' : 'animate-spin'}`} />
                        ) : (
                          <div className="h-4 w-4 rounded-full border border-slate-700" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className={`text-xs font-semibold ${isCurrent ? 'text-[#00f2fe]' : 'text-slate-200'}`}>
                          {step.title}
                        </p>
                        <p className="text-[11px] text-slate-400">{step.desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Animated Progress Bar & Percentage */}
              <div className="mt-6 space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400">Analysis Velocity:</span>
                  <span className="text-[#00f2fe] font-bold">{scanProgress}%</span>
                </div>
                <div 
                  className="w-full rounded-full bg-slate-800 h-2.5 overflow-hidden p-0.5 border border-white/[0.08]"
                  role="progressbar"
                  aria-valuenow={scanProgress}
                  aria-valuemin={0}
                  aria-valuemax={100}
                >
                  <motion.div
                    className="h-full rounded-full bg-gradient-to-r from-[#00f2fe] via-[#6366f1] to-[#8e2de2]"
                    initial={{ width: '10%' }}
                    animate={{ width: `${scanProgress}%` }}
                    transition={{ duration: shouldReduceMotion ? 0 : 0.4, ease: 'easeOut' }}
                  />
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
