import React, { useState, useEffect } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { Zap, Sparkles, HelpCircle } from 'lucide-react';

interface AiMatchDialProps {
  percentage: number;
  breakdown?: {
    skillsMatch: number;
    experienceMatch: number;
    roleFit: number;
    atsReadiness: number;
  };
  size?: 'sm' | 'md' | 'lg';
  showDetailsOnHover?: boolean;
}

export const AiMatchDial: React.FC<AiMatchDialProps> = ({
  percentage,
  breakdown,
  size = 'md',
  showDetailsOnHover = true
}) => {
  const shouldReduceMotion = useReducedMotion();
  const [displayedValue, setDisplayedValue] = useState(shouldReduceMotion ? percentage : 0);
  const [isHovered, setIsHovered] = useState(false);

  // Dynamic color selection matching dark glassmorphism theme
  const getDialColor = (score: number) => {
    if (score >= 90) return { stroke: '#10b981', fill: '#34d399', text: 'text-emerald-400', bgGlow: 'shadow-emerald-500/20' };
    if (score >= 80) return { stroke: '#00f2fe', fill: '#38bdf8', text: 'text-[#00f2fe]', bgGlow: 'shadow-[#00f2fe]/20' };
    return { stroke: '#c084fc', fill: '#8e2de2', text: 'text-[#c084fc]', bgGlow: 'shadow-[#8e2de2]/20' };
  };

  const colors = getDialColor(percentage);

  // Smooth count-up effect
  useEffect(() => {
    if (shouldReduceMotion) {
      setDisplayedValue(percentage);
      return;
    }

    let start = 0;
    const duration = 900; // ms
    const startTime = performance.now();

    const animateValue = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Ease out cubic
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      const currentVal = Math.round(easeProgress * percentage);
      setDisplayedValue(currentVal);

      if (progress < 1) {
        requestAnimationFrame(animateValue);
      }
    };

    const animFrame = requestAnimationFrame(animateValue);
    return () => cancelAnimationFrame(animFrame);
  }, [percentage, shouldReduceMotion]);

  const sizeClasses = {
    sm: { box: 'h-8 w-8', text: 'text-xs', stroke: 3.5 },
    md: { box: 'h-10 w-10', text: 'text-sm', stroke: 4 },
    lg: { box: 'h-16 w-16', text: 'text-xl', stroke: 4.5 }
  }[size];

  return (
    <div 
      className="relative inline-flex items-center"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className={`relative flex items-center gap-2.5 rounded-2xl bg-white/[0.04] border border-white/[0.08] px-3.5 py-1.5 shadow-lg transition-all duration-300 ${isHovered ? 'border-[#00f2fe]/50 bg-white/[0.08] shadow-[#00f2fe]/20' : ''}`}>
        <div className={`relative ${sizeClasses.box} flex items-center justify-center`}>
          <svg className="h-full w-full -rotate-90 transform" viewBox="0 0 36 36">
            {/* Background Track */}
            <path
              className="text-white/[0.08]"
              strokeWidth={sizeClasses.stroke}
              stroke="currentColor"
              fill="none"
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            />
            {/* Animated Gauge Ring */}
            <motion.path
              initial={shouldReduceMotion ? false : { strokeDasharray: '0, 100' }}
              animate={{ strokeDasharray: `${percentage}, 100` }}
              transition={{ duration: shouldReduceMotion ? 0 : 0.9, ease: 'easeOut' }}
              strokeWidth={sizeClasses.stroke}
              strokeLinecap="round"
              stroke={colors.stroke}
              fill="none"
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            />
          </svg>
          <Zap className={`absolute w-3.5 h-3.5 ${colors.text} drop-shadow-[0_0_8px_${colors.stroke}]`} />
        </div>

        <div className="text-right">
          <div className={`font-display font-extrabold ${sizeClasses.text} text-white leading-none flex items-center justify-end`}>
            <span>{displayedValue}%</span>
          </div>
          <span className={`text-[9px] font-mono uppercase tracking-wider ${colors.text} font-semibold flex items-center justify-end gap-1 mt-0.5`}>
            <span>AI Match</span>
            {breakdown && <HelpCircle className="w-2.5 h-2.5 opacity-60" />}
          </span>
        </div>
      </div>

      {/* Breakdown Tooltip on Hover */}
      {showDetailsOnHover && breakdown && isHovered && (
        <motion.div
          initial={{ opacity: 0, y: 6, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 6, scale: 0.95 }}
          transition={{ duration: 0.15 }}
          className="absolute top-full right-0 mt-2 z-40 w-56 rounded-2xl glass-panel-glow p-3.5 shadow-2xl border border-white/[0.15] space-y-2 pointer-events-none"
        >
          <div className="flex items-center justify-between pb-1.5 border-b border-white/[0.08]">
            <span className="text-[11px] font-mono font-bold text-white flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#00f2fe]" /> Fit Breakdown
            </span>
            <span className={`text-[11px] font-mono font-bold ${colors.text}`}>
              {percentage}%
            </span>
          </div>

          <div className="space-y-1.5 text-[10px]">
            <div className="flex justify-between items-center text-slate-300">
              <span>Skills Matrix Match</span>
              <span className="font-mono text-emerald-400 font-bold">{breakdown.skillsMatch}%</span>
            </div>
            <div className="h-1 w-full bg-white/[0.08] rounded-full overflow-hidden">
              <div className="h-full bg-emerald-400 rounded-full" style={{ width: `${breakdown.skillsMatch}%` }} />
            </div>

            <div className="flex justify-between items-center text-slate-300 pt-1">
              <span>Experience & Seniority</span>
              <span className="font-mono text-[#00f2fe] font-bold">{breakdown.experienceMatch}%</span>
            </div>
            <div className="h-1 w-full bg-white/[0.08] rounded-full overflow-hidden">
              <div className="h-full bg-[#00f2fe] rounded-full" style={{ width: `${breakdown.experienceMatch}%` }} />
            </div>

            <div className="flex justify-between items-center text-slate-300 pt-1">
              <span>Domain & Role Fit</span>
              <span className="font-mono text-[#c084fc] font-bold">{breakdown.roleFit}%</span>
            </div>
            <div className="h-1 w-full bg-white/[0.08] rounded-full overflow-hidden">
              <div className="h-full bg-[#c084fc] rounded-full" style={{ width: `${breakdown.roleFit}%` }} />
            </div>

            <div className="flex justify-between items-center text-slate-300 pt-1">
              <span>ATS Keyword Compatibility</span>
              <span className="font-mono text-amber-400 font-bold">{breakdown.atsReadiness}%</span>
            </div>
            <div className="h-1 w-full bg-white/[0.08] rounded-full overflow-hidden">
              <div className="h-full bg-amber-400 rounded-full" style={{ width: `${breakdown.atsReadiness}%` }} />
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};
