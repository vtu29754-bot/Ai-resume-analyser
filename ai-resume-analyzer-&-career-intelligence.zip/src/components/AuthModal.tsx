import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Sparkles, User, Mail, Lock, CheckCircle2, Github, ArrowRight } from 'lucide-react';
import { UserProfile } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserProfile) => void;
  currentUser: UserProfile;
  onLogout: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  currentUser,
  onLogout
}) => {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newUser: UserProfile = {
      name: isRegister ? (name || 'Alex Rivera') : (currentUser.isLoggedIn ? currentUser.name : 'Alex Rivera'),
      email: email || 'alex.rivera.dev@gmail.com',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      title: 'Senior Software Engineer',
      isLoggedIn: true,
      plan: 'Pro',
      scansRemaining: 99,
      savedJobIds: currentUser.savedJobIds || ['job-1', 'job-3']
    };
    onLoginSuccess(newUser);
    onClose();
  };

  const handleQuickDemoLogin = (demoName: string, demoRole: string) => {
    const newUser: UserProfile = {
      name: demoName,
      email: `${demoName.toLowerCase().replace(/\s+/g, '.')}@gmail.com`,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      title: demoRole,
      isLoggedIn: true,
      plan: 'Pro',
      scansRemaining: 99,
      savedJobIds: ['job-1', 'job-3']
    };
    onLoginSuccess(newUser);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#05070a]/80 backdrop-blur-md p-4">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="w-full max-w-md rounded-3xl glass-panel-glow p-6 sm:p-8 shadow-2xl border border-white/[0.08] relative overflow-hidden"
      >
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#00f2fe]/15 text-[#00f2fe] border border-[#00f2fe]/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-white">
                {currentUser.isLoggedIn ? 'Candidate Account' : (isRegister ? 'Create Candidate Account' : 'Sign In to ResumeGlow')}
              </h3>
              <p className="text-[11px] font-mono text-slate-400">
                {currentUser.isLoggedIn ? 'Manage career dossier & scans' : 'Access saved scans & job applications'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl p-1.5 text-slate-400 hover:text-white hover:bg-white/[0.08] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {currentUser.isLoggedIn ? (
          <div className="space-y-5">
            <div className="rounded-2xl bg-white/[0.03] border border-white/[0.08] p-4 space-y-3">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-2xl bg-[#00f2fe]/15 border border-[#00f2fe]/30 flex items-center justify-center text-[#00f2fe] font-bold text-lg">
                  {currentUser.name[0]}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-white">{currentUser.name}</h4>
                  <p className="text-xs text-slate-400 font-mono">{currentUser.email}</p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-white/[0.08] text-xs">
                <span className="text-slate-400">Plan Tier:</span>
                <span className="rounded bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 font-mono font-bold text-[10px]">
                  {currentUser.plan} Active
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Saved Jobs:</span>
                <span className="font-mono text-[#00f2fe]">{currentUser.savedJobIds.length} bookmarked</span>
              </div>
            </div>

            <button
              onClick={() => {
                onLogout();
                onClose();
              }}
              className="w-full py-2.5 rounded-xl bg-white/[0.04] border border-rose-500/30 text-xs font-semibold text-rose-300 hover:bg-rose-500/15 transition-colors cursor-pointer"
            >
              Sign Out
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {/* 1-Click Demo Logins */}
            <div className="space-y-2">
              <span className="text-[11px] font-mono text-slate-400 block">1-Click Instant Guest Logins:</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleQuickDemoLogin('Alex Rivera', 'Senior Full Stack Engineer')}
                  className="rounded-xl bg-white/[0.03] border border-white/[0.08] hover:border-[#00f2fe]/40 p-2.5 text-left transition-colors cursor-pointer"
                >
                  <p className="text-xs font-semibold text-white">Alex Rivera</p>
                  <p className="text-[10px] text-slate-400 truncate">Senior Full Stack</p>
                </button>
                <button
                  onClick={() => handleQuickDemoLogin('Elena Rostova', 'AI Product Manager')}
                  className="rounded-xl bg-white/[0.03] border border-white/[0.08] hover:border-[#00f2fe]/40 p-2.5 text-left transition-colors cursor-pointer"
                >
                  <p className="text-xs font-semibold text-white">Elena Rostova</p>
                  <p className="text-[10px] text-slate-400 truncate">AI / ML Lead PM</p>
                </button>
              </div>
            </div>

            <div className="relative flex py-2 items-center">
              <div className="flex-grow border-t border-white/[0.08]"></div>
              <span className="flex-shrink mx-3 text-[10px] font-mono text-slate-500 uppercase">or credentials</span>
              <div className="flex-grow border-t border-white/[0.08]"></div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              {isRegister && (
                <div className="space-y-1">
                  <label className="text-xs font-mono text-slate-300">Your Full Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Alex Rivera"
                    className="w-full rounded-xl glass-input px-3.5 py-2 text-xs text-slate-200"
                  />
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-mono text-slate-300">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="candidate@gmail.com"
                  className="w-full rounded-xl glass-input px-3.5 py-2 text-xs text-slate-200"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono text-slate-300">Password</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-xl glass-input px-3.5 py-2 text-xs text-slate-200"
                />
              </div>

              <button
                type="submit"
                className="w-full mt-2 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] py-2.5 text-xs font-semibold text-white shadow-lg shadow-[#00f2fe]/25 hover:shadow-[#00f2fe]/40 transition-all cursor-pointer"
              >
                <span>{isRegister ? 'Create Account & Continue' : 'Sign In'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>

            <div className="text-center pt-2">
              <button
                onClick={() => setIsRegister(!isRegister)}
                className="text-xs text-slate-400 hover:text-[#00f2fe] transition-colors cursor-pointer"
              >
                {isRegister ? 'Already have an account? Sign In' : "Don't have an account? Register free"}
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};
