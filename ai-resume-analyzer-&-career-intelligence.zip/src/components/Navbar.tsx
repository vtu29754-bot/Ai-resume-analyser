import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  FileText, 
  Briefcase, 
  Menu, 
  X, 
  Zap
} from 'lucide-react';
import { ActiveTab } from '../types';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenUpload: () => void;
  savedJobsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenUpload,
  savedJobsCount
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'analyzer', label: 'Resume Scanner', icon: <FileText className="w-4 h-4" /> },
    { id: 'jobs', label: 'AI Job Match', icon: <Briefcase className="w-4 h-4" />, badge: savedJobsCount > 0 ? `${savedJobsCount}` : undefined }
  ];

  return (
    <header className="sticky top-0 z-50 w-full px-4 pt-3 pb-2 sm:px-6 lg:px-8">
      <nav 
        id="main-navigation"
        className="mx-auto max-w-7xl rounded-2xl glass-panel px-4 py-3 sm:px-6 flex items-center justify-between shadow-2xl transition-all duration-300 border border-white/[0.08]"
      >
        {/* Brand Logo */}
        <div 
          id="brand-logo-btn"
          role="button"
          tabIndex={0}
          onClick={() => setActiveTab('analyzer')}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-[#05f1cd] via-[#6366f1] to-[#8b5cf6] p-0.5 shadow-lg shadow-[#05f1cd]/20 group-hover:shadow-[#05f1cd]/40 transition-all duration-300">
            <div className="flex h-full w-full items-center justify-center rounded-[10px] bg-[#060913]/90 backdrop-blur-sm">
              <Sparkles className="w-5 h-5 text-[#05f1cd] group-hover:rotate-12 transition-transform duration-300" />
            </div>
            <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-base sm:text-lg tracking-tight text-white group-hover:text-[#05f1cd] transition-colors">
                Resume<span className="text-gradient-cyan">Glow</span>
              </span>
              <span className="rounded-full bg-[#05f1cd]/10 border border-[#05f1cd]/30 px-2 py-0.5 text-[10px] font-mono font-medium text-[#05f1cd] hidden sm:inline-block">
                AI Match
              </span>
            </div>
            <p className="text-[11px] font-mono text-slate-400 hidden sm:block">
              Resume Intelligence & Direct Job Applications
            </p>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <div className="hidden sm:flex items-center gap-1 rounded-xl bg-white/[0.03] p-1 border border-white/[0.08] backdrop-blur-md">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-tab-${item.id}`}
                onClick={() => setActiveTab(item.id)}
                className={`relative flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  isActive 
                    ? 'text-[#05f1cd]' 
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeTabIndicator"
                    className="absolute inset-0 rounded-xl bg-gradient-to-r from-[#05f1cd]/20 via-[#6366f1]/20 to-[#8b5cf6]/20 border border-[#05f1cd]/40 shadow-inner"
                    transition={{ type: 'spring', bounce: 0.2, duration: 0.4 }}
                  />
                )}
                <span className="relative z-10">{item.icon}</span>
                <span className="relative z-10">{item.label}</span>
                {item.badge && (
                  <span className="relative z-10 ml-1 rounded-full bg-[#05f1cd]/20 text-[#05f1cd] text-[10px] font-mono px-2 py-0.5 border border-[#05f1cd]/40">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Right CTA Actions */}
        <div className="hidden sm:flex items-center gap-3">
          <button
            id="quick-scan-cta"
            onClick={onOpenUpload}
            className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#05f1cd] via-[#6366f1] to-[#8b5cf6] px-4 py-2 text-xs font-bold text-white shadow-lg shadow-[#05f1cd]/20 hover:shadow-[#05f1cd]/40 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 fill-white text-white" />
            <span>Scan Resume</span>
          </button>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex items-center gap-2 sm:hidden">
          <button
            id="mobile-upload-btn"
            onClick={onOpenUpload}
            className="flex items-center gap-1 rounded-lg bg-[#05f1cd]/20 border border-[#05f1cd]/40 px-2.5 py-1.5 text-xs font-medium text-[#05f1cd]"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Scan</span>
          </button>
          <button
            id="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="rounded-xl p-2 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="sm:hidden mt-2 mx-auto max-w-7xl rounded-2xl glass-panel p-4 shadow-2xl border border-white/[0.08]"
          >
            <div className="flex flex-col gap-1">
              {navItems.map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    id={`mobile-nav-${item.id}`}
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex items-center justify-between px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                      isActive 
                        ? 'bg-[#05f1cd]/20 text-[#05f1cd] border border-[#05f1cd]/40' 
                        : 'text-slate-300 hover:bg-white/[0.05]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {item.icon}
                      <span>{item.label}</span>
                    </div>
                    {item.badge && (
                      <span className="rounded-full bg-[#05f1cd]/30 text-[#05f1cd] text-xs px-2 py-0.5">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}

              <div className="pt-3 mt-2 border-t border-white/[0.08] flex flex-col gap-2">
                <button
                  id="mobile-scan-action-btn"
                  onClick={() => {
                    onOpenUpload();
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#05f1cd] via-[#6366f1] to-[#8b5cf6] py-2.5 text-sm font-semibold text-white shadow-lg"
                >
                  <Zap className="w-4 h-4 fill-white" />
                  <span>Scan Resume with AI</span>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
