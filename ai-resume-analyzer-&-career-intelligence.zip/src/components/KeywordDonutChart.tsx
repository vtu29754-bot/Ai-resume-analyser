import React, { useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { Sparkles, Hash, Layers, ShieldCheck, Info } from 'lucide-react';

interface KeywordCategoryData {
  id: string;
  name: string;
  count: number;
  percentage: number;
  color: string;
  glowColor: string;
  sampleKeywords: string[];
  atsWeight: string;
}

interface KeywordDonutChartProps {
  keywordDensity: { keyword: string; count: number; importance: 'High' | 'Medium' | 'Low' }[];
  totalSkillsCount: number;
  atsScore: number;
}

export const KeywordDonutChart: React.FC<KeywordDonutChartProps> = ({
  keywordDensity,
  totalSkillsCount,
  atsScore
}) => {
  const shouldReduceMotion = useReducedMotion();
  const [activeSegmentIndex, setActiveSegmentIndex] = useState<number | null>(null);

  // Categorize keywords into dynamic thematic segments
  const totalMentions = keywordDensity.reduce((acc, curr) => acc + curr.count, 0) || 45;

  const categories: KeywordCategoryData[] = [
    {
      id: 'core-tech',
      name: 'Core Languages & Runtimes',
      count: Math.round(totalMentions * 0.35),
      percentage: 35,
      color: '#00f2fe',
      glowColor: 'rgba(0, 242, 254, 0.4)',
      sampleKeywords: ['TypeScript', 'JavaScript', 'Python', 'Node.js', 'Go', 'SQL'],
      atsWeight: 'Critical (35%)'
    },
    {
      id: 'frameworks',
      name: 'Frameworks & Frontend UI',
      count: Math.round(totalMentions * 0.25),
      percentage: 25,
      color: '#8e2de2',
      glowColor: 'rgba(142, 45, 226, 0.4)',
      sampleKeywords: ['React', 'Next.js', 'Tailwind CSS', 'Redux', 'GraphQL', 'Vite'],
      atsWeight: 'High (25%)'
    },
    {
      id: 'cloud-infra',
      name: 'Cloud, DevOps & Storage',
      count: Math.round(totalMentions * 0.20),
      percentage: 20,
      color: '#10b981',
      glowColor: 'rgba(16, 185, 129, 0.4)',
      sampleKeywords: ['AWS', 'Docker', 'PostgreSQL', 'Redis', 'Kubernetes', 'CI/CD'],
      atsWeight: 'High (20%)'
    },
    {
      id: 'architecture',
      name: 'Systems Architecture & APIs',
      count: Math.round(totalMentions * 0.12),
      percentage: 12,
      color: '#f59e0b',
      glowColor: 'rgba(245, 158, 11, 0.4)',
      sampleKeywords: ['Microservices', 'REST APIs', 'System Design', 'Caching', 'Scalability'],
      atsWeight: 'Medium (12%)'
    },
    {
      id: 'leadership',
      name: 'Leadership & Impact Verbs',
      count: Math.round(totalMentions * 0.08),
      percentage: 8,
      color: '#ec4899',
      glowColor: 'rgba(236, 72, 153, 0.4)',
      sampleKeywords: ['Mentored', 'Architected', 'Reduced Latency', 'Velocity', 'Cross-functional'],
      atsWeight: 'Supporting (8%)'
    }
  ];

  // SVG Donut calculation constants
  const size = 260;
  const strokeWidth = 32;
  const radius = (size - strokeWidth) / 2;
  const center = size / 2;
  const circumference = 2 * Math.PI * radius;

  let accumulatedPercentage = 0;

  const activeCategory = activeSegmentIndex !== null ? categories[activeSegmentIndex] : null;

  return (
    <div className="glass-panel rounded-3xl p-6 sm:p-7 border border-white/[0.08] relative overflow-hidden">
      {/* Ambience glow */}
      <div className="pointer-events-none absolute top-0 right-0 h-64 w-64 rounded-full bg-[#8e2de2]/10 blur-[90px]" />

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <Hash className="w-4 h-4 text-[#00f2fe]" />
            <h3 className="font-display font-bold text-lg text-white">
              Keyword Density & ATS Composition
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Breakdown of {totalMentions} extracted ATS-verified keyword tokens and semantic weight.
          </p>
        </div>

        <span className="rounded-full bg-[#00f2fe]/15 border border-[#00f2fe]/30 px-3 py-1 text-xs font-mono text-[#00f2fe]">
          ATS Match Score: {atsScore}%
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Animated Donut SVG Chart */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center relative">
          <div className="relative h-[260px] w-[260px] flex items-center justify-center">
            <svg 
              width={size} 
              height={size} 
              className="-rotate-90 transform"
              viewBox={`0 0 ${size} ${size}`}
            >
              {/* Background Ring */}
              <circle
                cx={center}
                cy={center}
                r={radius}
                fill="none"
                stroke="rgba(255, 255, 255, 0.05)"
                strokeWidth={strokeWidth}
              />

              {/* Segments */}
              {categories.map((cat, idx) => {
                const strokeDasharray = `${(cat.percentage / 100) * circumference} ${circumference}`;
                const strokeDashoffset = -((accumulatedPercentage / 100) * circumference);
                accumulatedPercentage += cat.percentage;

                const isHovered = activeSegmentIndex === idx;

                return (
                  <motion.circle
                    key={cat.id}
                    cx={center}
                    cy={center}
                    r={radius}
                    fill="none"
                    stroke={cat.color}
                    strokeWidth={isHovered ? strokeWidth + 6 : strokeWidth}
                    strokeDasharray={strokeDasharray}
                    strokeDashoffset={strokeDashoffset}
                    initial={shouldReduceMotion ? false : { opacity: 0 }}
                    animate={{ 
                      opacity: activeSegmentIndex === null || isHovered ? 1 : 0.45,
                      strokeWidth: isHovered ? strokeWidth + 6 : strokeWidth
                    }}
                    transition={{ duration: shouldReduceMotion ? 0 : 0.4 }}
                    className="cursor-pointer transition-all duration-200"
                    onMouseEnter={() => setActiveSegmentIndex(idx)}
                    onMouseLeave={() => setActiveSegmentIndex(null)}
                    style={{
                      filter: isHovered ? `drop-shadow(0 0 10px ${cat.glowColor})` : 'none'
                    }}
                  />
                );
              })}
            </svg>

            {/* Donut Center Display */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none p-4">
              {activeCategory ? (
                <motion.div
                  key={activeCategory.id}
                  initial={{ scale: 0.85, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="space-y-0.5"
                >
                  <span className="font-mono text-2xl font-extrabold text-white" style={{ color: activeCategory.color }}>
                    {activeCategory.percentage}%
                  </span>
                  <p className="text-[11px] font-semibold text-slate-200 max-w-[120px] leading-tight">
                    {activeCategory.name}
                  </p>
                  <p className="text-[10px] font-mono text-slate-400">
                    ~{activeCategory.count} mentions
                  </p>
                </motion.div>
              ) : (
                <div className="space-y-0.5">
                  <span className="font-display text-3xl font-extrabold text-white">
                    {totalSkillsCount}
                  </span>
                  <p className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
                    Skills Indexed
                  </p>
                  <p className="text-[10px] font-mono text-[#00f2fe]">
                    100% Parsed
                  </p>
                </div>
              )}
            </div>
          </div>

          <p className="text-[11px] text-slate-400 mt-3 flex items-center gap-1">
            <Info className="w-3 h-3 text-[#00f2fe]" />
            Hover over segments to inspect ATS keyword distribution
          </p>
        </div>

        {/* Categories Legend & Keyword Tag Clouds */}
        <div className="lg:col-span-7 space-y-3">
          {categories.map((cat, idx) => {
            const isHovered = activeSegmentIndex === idx;

            return (
              <div
                key={cat.id}
                onMouseEnter={() => setActiveSegmentIndex(idx)}
                onMouseLeave={() => setActiveSegmentIndex(null)}
                className={`rounded-2xl p-3.5 transition-all duration-200 cursor-pointer border ${
                  isHovered
                    ? 'bg-white/[0.08] border-white/[0.2] shadow-lg'
                    : 'bg-white/[0.02] border-white/[0.06] hover:bg-white/[0.04]'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2.5">
                    <span 
                      className="h-3 w-3 rounded-full shrink-0 shadow-sm"
                      style={{ backgroundColor: cat.color }} 
                    />
                    <span className="text-xs font-semibold text-white">
                      {cat.name}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-[11px] font-mono text-slate-400">
                      {cat.atsWeight}
                    </span>
                    <span className="font-mono text-xs font-bold" style={{ color: cat.color }}>
                      {cat.percentage}%
                    </span>
                  </div>
                </div>

                {/* Sample Keywords in this category */}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {cat.sampleKeywords.map((kw, kIdx) => (
                    <span
                      key={kIdx}
                      className="rounded-md bg-white/[0.04] border border-white/[0.06] px-2 py-0.5 text-[10px] text-slate-300 font-mono"
                    >
                      {kw}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
