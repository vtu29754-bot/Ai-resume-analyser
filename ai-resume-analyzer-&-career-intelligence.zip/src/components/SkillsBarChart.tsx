import React, { useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { 
  BarChart3, 
  CheckCircle2, 
  ArrowUpDown, 
  Search, 
  BrainCircuit, 
  ExternalLink,
  Layers,
  Sparkles
} from 'lucide-react';
import { SkillCategory, JobRecommendation } from '../types';
import { SelectedSkillData } from './SkillDetailModal';

interface SkillsBarChartProps {
  skillsMatrix: SkillCategory[];
  allExtractedSkills: string[];
  missingCrucialSkills: string[];
  onSkillClick: (skill: SelectedSkillData) => void;
  allJobs?: JobRecommendation[];
}

export const SkillsBarChart: React.FC<SkillsBarChartProps> = ({
  skillsMatrix,
  allExtractedSkills,
  missingCrucialSkills,
  onSkillClick,
  allJobs = []
}) => {
  const shouldReduceMotion = useReducedMotion();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'level' | 'name' | 'verified'>('level');
  const [searchFilter, setSearchFilter] = useState('');
  const [hoveredSkillName, setHoveredSkillName] = useState<string | null>(null);

  const allCategories = ['All', ...skillsMatrix.map(c => c.category)];

  // Flatten all skills with category meta
  const flattenedSkills: (SelectedSkillData)[] = skillsMatrix.flatMap(cat => 
    cat.skills.map(s => ({
      name: s.name,
      level: s.level,
      verifiedInResume: s.verifiedInResume,
      category: cat.category
    }))
  );

  // Filter skills
  const filteredSkills = flattenedSkills.filter(skill => {
    if (selectedCategory !== 'All' && skill.category !== selectedCategory) return false;
    if (searchFilter.trim() && !skill.name.toLowerCase().includes(searchFilter.toLowerCase())) return false;
    return true;
  });

  // Sort skills
  const sortedSkills = [...filteredSkills].sort((a, b) => {
    if (sortBy === 'level') return b.level - a.level;
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    if (sortBy === 'verified') {
      if (a.verifiedInResume && !b.verifiedInResume) return -1;
      if (!a.verifiedInResume && b.verifiedInResume) return 1;
      return b.level - a.level;
    }
    return 0;
  });

  const getBarGradient = (level: number) => {
    if (level >= 90) return 'from-[#00f2fe] via-[#38bdf8] to-[#10b981]';
    if (level >= 75) return 'from-[#00f2fe] via-[#6366f1] to-[#8e2de2]';
    if (level >= 60) return 'from-[#8e2de2] to-[#ec4899]';
    return 'from-slate-500 to-slate-400';
  };

  return (
    <div className="glass-panel rounded-3xl p-6 sm:p-7 border border-white/[0.08] relative overflow-hidden space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-[#00f2fe]" />
            <h3 className="font-display font-bold text-lg text-white">
              Neural Skill Proficiency Graph
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Interactive proficiency breakdown. Click any skill bar for granular breakdown, evidence, and job matches.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Search skill */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              placeholder="Filter skills..."
              className="rounded-xl glass-input pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 w-36 sm:w-44 focus:ring-1 focus:ring-[#00f2fe]"
            />
          </div>

          {/* Sort selector */}
          <div className="flex items-center gap-1.5 rounded-xl bg-white/[0.04] p-1 border border-white/[0.08] text-xs">
            <button
              onClick={() => setSortBy('level')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                sortBy === 'level' ? 'bg-[#00f2fe]/20 text-[#00f2fe] font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Highest
            </button>
            <button
              onClick={() => setSortBy('verified')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                sortBy === 'verified' ? 'bg-[#00f2fe]/20 text-[#00f2fe] font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Verified
            </button>
            <button
              onClick={() => setSortBy('name')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                sortBy === 'name' ? 'bg-[#00f2fe]/20 text-[#00f2fe] font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              A-Z
            </button>
          </div>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {allCategories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === cat
                ? 'bg-gradient-to-r from-[#00f2fe]/25 to-[#8e2de2]/25 text-white border border-[#00f2fe]/40 shadow-sm'
                : 'bg-white/[0.03] text-slate-400 hover:text-slate-200 border border-white/[0.06]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Interactive Bar Chart List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sortedSkills.map((skill, idx) => {
          const isHovered = hoveredSkillName === skill.name;
          const matchingCount = allJobs.filter(j => 
            j.matchedSkills.some(s => s.toLowerCase() === skill.name.toLowerCase())
          ).length;

          return (
            <motion.div
              key={skill.name}
              initial={shouldReduceMotion ? false : { opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: shouldReduceMotion ? 0 : 0.25, delay: idx * 0.02 }}
              onClick={() => onSkillClick(skill)}
              onMouseEnter={() => setHoveredSkillName(skill.name)}
              onMouseLeave={() => setHoveredSkillName(null)}
              className={`group relative rounded-2xl p-3.5 transition-all duration-200 cursor-pointer border ${
                isHovered
                  ? 'bg-white/[0.08] border-[#00f2fe]/50 shadow-lg shadow-[#00f2fe]/10 scale-[1.01]'
                  : 'bg-white/[0.02] border-white/[0.06] hover:bg-white/[0.05]'
              }`}
            >
              <div className="flex items-center justify-between text-xs mb-2">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-white group-hover:text-[#00f2fe] transition-colors flex items-center gap-1.5">
                    {skill.name}
                    {skill.verifiedInResume && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    )}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">
                    ({skill.category})
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {matchingCount > 0 && (
                    <span className="hidden sm:inline-flex items-center text-[10px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded">
                      {matchingCount} Jobs
                    </span>
                  )}
                  <span className="font-mono font-bold text-[#00f2fe]">
                    {skill.level}%
                  </span>
                  <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-[#00f2fe] transition-colors" />
                </div>
              </div>

              {/* Animated Progress Bar */}
              <div className="h-2 w-full rounded-full bg-white/[0.08] overflow-hidden">
                <motion.div
                  initial={shouldReduceMotion ? { width: `${skill.level}%` } : { width: 0 }}
                  animate={{ width: `${skill.level}%` }}
                  transition={{ duration: shouldReduceMotion ? 0 : 0.6, ease: 'easeOut', delay: idx * 0.02 }}
                  className={`h-full rounded-full bg-gradient-to-r ${getBarGradient(skill.level)}`}
                />
              </div>
            </motion.div>
          );
        })}
      </div>

      {sortedSkills.length === 0 && (
        <div className="text-center py-10 text-slate-400 text-xs">
          No skills found matching "{searchFilter}".
        </div>
      )}

      {/* Missing Crucial Skills Recommendation Banner */}
      <div className="rounded-2xl bg-amber-500/10 border border-amber-500/30 p-4">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <h4 className="font-display font-bold text-xs text-white">
            High-Value Keyword Recommendations to Boost ATS Score
          </h4>
        </div>
        <p className="text-[11px] text-slate-300 mb-3">
          Adding verified examples of these in-demand competencies will maximize match rates for Staff and Senior openings:
        </p>
        <div className="flex flex-wrap gap-2">
          {missingCrucialSkills.map((sk, idx) => (
            <button
              key={idx}
              onClick={() => onSkillClick({
                name: sk,
                level: 70,
                verifiedInResume: false,
                category: 'Target Skill Recommendation',
                rationale: `Frequently demanded across 85%+ of matching job openings. Recommended to add into your experience or project sections.`
              })}
              className="rounded-lg bg-amber-500/15 border border-amber-500/40 hover:bg-amber-500/25 px-2.5 py-1 text-xs font-mono text-amber-300 transition-colors cursor-pointer"
            >
              + {sk} (Inspect)
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
