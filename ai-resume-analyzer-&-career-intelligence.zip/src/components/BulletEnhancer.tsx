import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Wand2,
  Sparkles,
  ArrowRight,
  Copy,
  Check,
  TrendingUp,
  BarChart3,
  Flame,
  ShieldCheck,
  Cpu,
  Zap,
  RotateCcw
} from 'lucide-react';
import { enhanceBulletPoint } from '../utils/aiAnalyzer';

export const BulletEnhancer: React.FC = () => {
  const [inputBullet, setInputBullet] = useState(
    'Responsible for working on backend APIs and fixing bugs in production with the team.'
  );
  const [selectedTone, setSelectedTone] = useState<'metrics' | 'leadership' | 'tech' | 'executive'>('metrics');
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState(() => enhanceBulletPoint('Responsible for working on backend APIs and fixing bugs in production with the team.', 'metrics'));
  const [copied, setCopied] = useState(false);

  const handleEnhance = async (tone = selectedTone) => {
    if (!inputBullet.trim()) return;
    setIsGenerating(true);
    await new Promise(r => setTimeout(r, 450));
    const output = enhanceBulletPoint(inputBullet, tone);
    setResult(output);
    setIsGenerating(false);
  };

  const tones: { id: 'metrics' | 'leadership' | 'tech' | 'executive'; label: string; desc: string; icon: React.ReactNode }[] = [
    {
      id: 'metrics',
      label: 'Quantified Impact ($, %, Scale)',
      desc: 'Injects concrete data points, throughput multipliers, and efficiency gains.',
      icon: <TrendingUp className="w-4 h-4 text-emerald-400" />
    },
    {
      id: 'leadership',
      label: 'Leadership & Team Ownership',
      desc: 'Highlights mentoring, stakeholder management, and architectural direction.',
      icon: <Flame className="w-4 h-4 text-amber-400" />
    },
    {
      id: 'tech',
      label: 'Technical Depth & Stack',
      desc: 'Emphasizes low-latency concurrency, modern frameworks, and cloud IaC.',
      icon: <Cpu className="w-4 h-4 text-cyan-400" />
    },
    {
      id: 'executive',
      label: 'Executive & Strategic ROI',
      desc: 'Elevates tone for Staff, Principal, and Director-level impact.',
      icon: <Sparkles className="w-4 h-4 text-purple-400" />
    }
  ];

  const handleCopy = () => {
    navigator.clipboard.writeText(result.improved);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const sampleWeakBullets = [
    'Helped build the frontend for the company dashboard using React.',
    'Worked on database performance and query tuning.',
    'Managed sprint planning and participated in daily standups.'
  ];

  return (
    <div className="relative z-10 mx-auto max-w-5xl px-4 pt-6 pb-24 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 rounded-full glass-panel px-4 py-1.5 border border-[#00f2fe]/30 text-xs font-mono text-[#00f2fe] mb-4 shadow-lg shadow-[#00f2fe]/10">
          <Wand2 className="w-3.5 h-3.5 text-[#00f2fe]" />
          <span>XYZ Formula Resume Bullet Optimizer</span>
        </div>
        <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white">
          Turn passive bullets into <span className="text-gradient-cyan">Tier-1 accomplishments</span>
        </h1>
        <p className="mt-3 text-sm sm:text-base text-slate-300">
          Leverages Google's proven formula: <em>"Accomplished [X] as measured by [Y], by doing [Z]"</em>.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Input and Tones */}
        <div className="lg:col-span-6 space-y-6">
          <div className="glass-panel rounded-3xl p-6 border border-white/[0.08] shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-xs font-mono font-semibold text-slate-300">
                Paste Any Weak Resume Bullet:
              </label>
              <button
                onClick={() => setInputBullet('')}
                className="text-[11px] font-mono text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                Clear
              </button>
            </div>

            <textarea
              id="bullet-input-textarea"
              rows={4}
              value={inputBullet}
              onChange={(e) => setInputBullet(e.target.value)}
              placeholder="e.g. Worked on database migration and reduced latency..."
              className="w-full rounded-2xl glass-input p-4 font-mono text-xs text-slate-200 placeholder:text-slate-500 focus:ring-1 focus:ring-[#00f2fe]"
            />

            {/* Quick Sample Prompts */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-mono text-slate-400">Or try a weak draft:</span>
              <div className="flex flex-col gap-1.5">
                {sampleWeakBullets.map((sample, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setInputBullet(sample);
                      handleEnhance(selectedTone);
                    }}
                    className="text-left rounded-lg bg-white/[0.03] hover:bg-white/[0.07] px-3 py-1.5 text-[11px] text-slate-300 hover:text-[#00f2fe] truncate border border-white/[0.06] transition-colors cursor-pointer"
                  >
                    "{sample}"
                  </button>
                ))}
              </div>
            </div>

            {/* Tone Selector */}
            <div className="space-y-2 pt-2 border-t border-white/[0.08]">
              <label className="text-xs font-mono font-semibold text-slate-300 block">
                Target Executive Tone:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {tones.map((t) => (
                  <button
                    key={t.id}
                    id={`tone-btn-${t.id}`}
                    onClick={() => {
                      setSelectedTone(t.id);
                      handleEnhance(t.id);
                    }}
                    className={`flex items-start gap-2.5 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedTone === t.id
                        ? 'bg-[#00f2fe]/15 border-[#00f2fe]/40 text-[#00f2fe] shadow-md'
                        : 'bg-white/[0.03] border-white/[0.08] text-slate-400 hover:text-slate-200 hover:bg-white/[0.06]'
                    }`}
                  >
                    <div className="mt-0.5">{t.icon}</div>
                    <div>
                      <p className="text-xs font-semibold text-white">{t.label}</p>
                      <p className="text-[10px] text-slate-400 line-clamp-1">{t.desc}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <button
              id="run-bullet-optimizer-btn"
              onClick={() => handleEnhance(selectedTone)}
              disabled={isGenerating || !inputBullet.trim()}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] py-3 text-xs font-semibold text-white shadow-lg shadow-[#00f2fe]/25 hover:shadow-[#00f2fe]/40 disabled:opacity-50 transition-all cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <div className="h-3.5 w-3.5 rounded-full border-2 border-white border-t-transparent animate-spin" />
                  <span>Synthesizing High-Impact Verbs...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  <span>Optimize Bullet with AI</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: High-Impact Result Card */}
        <div className="lg:col-span-6 space-y-6">
          <div className="glass-panel-glow rounded-3xl p-6 sm:p-7 border border-[#00f2fe]/30 shadow-2xl space-y-6 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#00f2fe]" />
                <h3 className="font-display font-bold text-base text-white">
                  AI Output Comparison
                </h3>
              </div>

              <div className="flex items-center gap-2 font-mono text-xs">
                <span className="text-rose-400">Score: {result.scoreBefore}</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                <span className="rounded-full bg-emerald-500/20 border border-emerald-500/40 px-2.5 py-0.5 text-emerald-300 font-bold">
                  Score: {result.scoreAfter}
                </span>
              </div>
            </div>

            {/* Before vs After Cards */}
            <div className="space-y-3">
              <div className="rounded-2xl bg-white/[0.03] border border-white/[0.08] p-4 space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold">
                  Original Text
                </span>
                <p className="text-xs font-mono text-slate-300">
                  {inputBullet || 'No input provided'}
                </p>
              </div>

              <div className="rounded-2xl bg-gradient-to-br from-[#00f2fe]/10 via-[#6366f1]/10 to-[#8e2de2]/10 border border-[#00f2fe]/40 p-5 space-y-3">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#00f2fe] font-bold flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5" />
                  Optimized High-Impact Bullet
                </span>
                <p className="text-sm font-sans font-medium text-white leading-relaxed">
                  {result.improved}
                </p>

                <div className="pt-3 border-t border-white/[0.08] flex flex-wrap gap-1.5">
                  {result.highlights.map((h, idx) => (
                    <span
                      key={idx}
                      className="rounded-md bg-[#00f2fe]/15 border border-[#00f2fe]/30 px-2 py-0.5 text-[10px] font-mono text-[#00f2fe]"
                    >
                      ✓ {h}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex items-center justify-between pt-2">
              <span className="text-xs font-mono text-slate-400">
                Ready to paste into resume
              </span>

              <button
                id="copy-improved-bullet-btn"
                onClick={handleCopy}
                className="flex items-center gap-2 rounded-xl bg-white/[0.08] hover:bg-white/[0.15] border border-white/[0.12] px-5 py-2 text-xs font-semibold text-white shadow-md transition-all cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-300">Copied to Clipboard!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Enhanced Bullet</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
