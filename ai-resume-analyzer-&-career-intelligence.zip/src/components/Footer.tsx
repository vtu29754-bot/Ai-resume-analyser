import React from 'react';
import { Sparkles, ShieldCheck, Heart, Github, Twitter, Linkedin, Zap } from 'lucide-react';
import { ActiveTab } from '../types';

export const Footer: React.FC<{ onNavigate: (tab: ActiveTab) => void }> = ({ onNavigate }) => {
  return (
    <footer className="relative z-10 border-t border-white/[0.08] bg-[#05070a]/80 backdrop-blur-md pt-16 pb-12 px-4 sm:px-6 lg:px-8 text-xs text-slate-400">
      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-12 border-b border-white/[0.08]">
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-tr from-[#05f1cd] via-[#6366f1] to-[#8b5cf6] p-0.5 shadow-md">
                <div className="flex h-full w-full items-center justify-center rounded-[6px] bg-[#060913]">
                  <Sparkles className="w-4 h-4 text-[#05f1cd]" />
                </div>
              </div>
              <span className="font-display font-bold text-base text-white">
                Resume<span className="text-gradient-cyan">Glow</span> AI
              </span>
            </div>
            <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
              Enterprise-grade AI resume scoring, ATS compliance diagnostics, XYZ impact bullet generation, and semantic job matching built for modern engineering & tech talent.
            </p>
            <div className="flex items-center gap-3 text-slate-400">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-0.5 text-[11px] font-mono text-emerald-300">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Systems Operational • v3.5
              </span>
            </div>
          </div>

          {/* Product Links */}
          <div className="space-y-3">
            <h4 className="font-display font-semibold text-xs uppercase tracking-wider text-slate-300">
              Quick Navigation
            </h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onNavigate('analyzer')} className="hover:text-[#05f1cd] transition-colors cursor-pointer">
                  Resume Scanner
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('jobs')} className="hover:text-[#05f1cd] transition-colors cursor-pointer">
                  AI Job Recommendations & Direct Apply
                </button>
              </li>
            </ul>
          </div>

          {/* Privacy & Legal */}
          <div className="space-y-3">
            <h4 className="font-display font-semibold text-xs uppercase tracking-wider text-slate-300">
              Direct Apply & Privacy
            </h4>
            <ul className="space-y-2">
              <li className="text-slate-400">
                Direct Redirect to Official Company Portals
              </li>
              <li className="text-slate-400">
                Zero Cloud Data Retention (Privacy-First)
              </li>
              <li className="text-slate-400">
                Real-Time ATS Keyword Calibration
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <p>© 2026 ResumeGlow AI Systems Inc. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span className="hover:text-slate-400 cursor-pointer">Privacy Policy</span>
            <span className="hover:text-slate-400 cursor-pointer">Terms of Service</span>
            <span className="hover:text-slate-400 cursor-pointer">Security Whitepaper</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
