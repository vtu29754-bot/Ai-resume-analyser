import React from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { 
  X, 
  Sparkles, 
  CheckCircle2, 
  Briefcase, 
  ArrowRight, 
  Award, 
  Layers, 
  BrainCircuit,
  TrendingUp,
  Tag
} from 'lucide-react';
import { JobRecommendation } from '../types';

export interface SelectedSkillData {
  name: string;
  level: number;
  verifiedInResume: boolean;
  category: string;
  rationale?: string;
  relatedSkills?: string[];
  jobMatches?: { id: string; title: string; company: string; matchPercentage: number }[];
}

interface SkillDetailModalProps {
  skill: SelectedSkillData | null;
  onClose: () => void;
  onSelectJob?: (jobId: string) => void;
  allJobs?: JobRecommendation[];
}

export const SkillDetailModal: React.FC<SkillDetailModalProps> = ({
  skill,
  onClose,
  onSelectJob,
  allJobs = []
}) => {
  const shouldReduceMotion = useReducedMotion();

  if (!skill) return null;

  // Generate dynamic contextual rationale if not provided
  const rationale = skill.rationale || (
    skill.level >= 90
      ? `Extracted across primary project architectures, enterprise experience bullets, and verified as a core production competency with high quantified impact.`
      : skill.level >= 75
      ? `Validated in modern tech stack responsibilities, integration workflows, and production deployments.`
      : `Identified as a secondary/supporting framework with foundational coverage in your experience portfolio.`
  );

  // Dynamic related skills based on skill name
  const related = skill.relatedSkills || (
    skill.name.toLowerCase().includes('react')
      ? ['Next.js', 'TypeScript', 'Redux Toolkit', 'Tailwind CSS', 'Vite', 'State Management']
      : skill.name.toLowerCase().includes('type') || skill.name.toLowerCase().includes('java')
      ? ['JavaScript (ES6+)', 'Node.js', 'Strict Typing', 'Generics', 'Async/Await']
      : skill.name.toLowerCase().includes('node')
      ? ['Express.js', 'REST APIs', 'PostgreSQL', 'Microservices', 'JWT Auth']
      : skill.name.toLowerCase().includes('cloud') || skill.name.toLowerCase().includes('aws')
      ? ['Docker', 'Kubernetes', 'Terraform', 'CI/CD Pipelines', 'Serverless']
      : skill.name.toLowerCase().includes('python')
      ? ['FastAPI', 'PyTorch', 'Data Pipelines', 'Pandas', 'REST APIs']
      : ['System Design', 'Git Version Control', 'Agile/Scrum', 'CI/CD', 'Code Quality']
  );

  // Find real job matches from active jobs list that demand this skill
  const matchingJobs = allJobs.filter(job => 
    job.matchedSkills.some(s => s.toLowerCase() === skill.name.toLowerCase()) ||
    job.tags.some(t => t.toLowerCase() === skill.name.toLowerCase()) ||
    job.title.toLowerCase().includes(skill.name.toLowerCase())
  ).slice(0, 3);

  const getProficiencyLabel = (level: number) => {
    if (level >= 90) return { label: 'Principal / Expert', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' };
    if (level >= 75) return { label: 'Advanced Competency', color: 'text-[#00f2fe] bg-[#00f2fe]/10 border-[#00f2fe]/30' };
    if (level >= 60) return { label: 'Intermediate Working Knowledge', color: 'text-amber-300 bg-amber-500/10 border-amber-500/30' };
    return { label: 'Foundational / Secondary', color: 'text-slate-300 bg-white/[0.05] border-white/[0.1]' };
  };

  const prof = getProficiencyLabel(skill.level);

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center bg-[#05070a]/80 backdrop-blur-md p-4"
        onClick={onClose}
      >
        <motion.div
          initial={shouldReduceMotion ? { opacity: 0 } : { scale: 0.94, opacity: 0, y: 15 }}
          animate={shouldReduceMotion ? { opacity: 1 } : { scale: 1, opacity: 1, y: 0 }}
          exit={shouldReduceMotion ? { opacity: 0 } : { scale: 0.94, opacity: 0, y: 15 }}
          transition={{ duration: 0.22, ease: 'easeOut' }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-lg rounded-3xl glass-panel-glow p-6 sm:p-7 shadow-2xl border border-white/[0.12] relative overflow-hidden"
        >
          {/* Accent Glow backdrop */}
          <div className="pointer-events-none absolute -top-24 -right-24 h-48 w-48 rounded-full bg-[#00f2fe]/20 blur-[80px]" />

          {/* Modal Header */}
          <div className="flex items-start justify-between pb-5 border-b border-white/[0.08]">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr from-[#00f2fe]/20 to-[#8e2de2]/20 border border-[#00f2fe]/40 text-[#00f2fe] shadow-lg shadow-[#00f2fe]/10">
                <BrainCircuit className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-display font-bold text-xl text-white">
                    {skill.name}
                  </h3>
                  {skill.verifiedInResume && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-mono text-emerald-400">
                      <CheckCircle2 className="w-2.5 h-2.5" /> Verified
                    </span>
                  )}
                </div>
                <p className="text-xs font-mono text-slate-400 mt-0.5">
                  Category: <span className="text-[#00f2fe]">{skill.category}</span>
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="rounded-xl p-2 text-slate-400 hover:text-white hover:bg-white/[0.08] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="mt-5 space-y-5">
            {/* Proficiency Score Card */}
            <div className="rounded-2xl bg-white/[0.03] border border-white/[0.08] p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
                  Neural Proficiency Score
                </span>
                <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-mono font-semibold border ${prof.color}`}>
                  {prof.label}
                </span>
              </div>

              <div className="flex items-center justify-between gap-4 mt-3">
                <div className="font-display text-3xl font-extrabold text-white">
                  {skill.level}%
                </div>
                <div className="h-3 flex-1 rounded-full bg-white/[0.08] overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${skill.level}%` }}
                    transition={{ duration: shouldReduceMotion ? 0 : 0.6, ease: 'easeOut' }}
                    className="h-full rounded-full bg-gradient-to-r from-[#00f2fe] via-[#6366f1] to-[#8e2de2]"
                  />
                </div>
              </div>
            </div>

            {/* AI Evaluation Rationale */}
            <div className="space-y-1.5">
              <div className="flex items-center gap-1.5 text-xs font-mono text-slate-300">
                <Sparkles className="w-3.5 h-3.5 text-[#00f2fe]" />
                <span>AI Scoring Rationale & Evidence:</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed rounded-xl bg-white/[0.02] border border-white/[0.06] p-3">
                {rationale}
              </p>
            </div>

            {/* Co-occurring & Related Technologies */}
            <div>
              <div className="flex items-center gap-1.5 text-xs font-mono text-slate-300 mb-2">
                <Tag className="w-3.5 h-3.5 text-[#c084fc]" />
                <span>Related Tech Stack & Semantic Nodes:</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {related.map((rel, idx) => (
                  <span
                    key={idx}
                    className="rounded-lg bg-white/[0.04] border border-white/[0.08] hover:border-[#00f2fe]/40 px-2.5 py-1 text-xs text-slate-300 transition-colors"
                  >
                    {rel}
                  </span>
                ))}
              </div>
            </div>

            {/* Target Job Opportunities for this Skill */}
            {matchingJobs.length > 0 && (
              <div className="pt-2 border-t border-white/[0.08]">
                <div className="flex items-center justify-between mb-2.5">
                  <span className="text-xs font-mono text-slate-300 flex items-center gap-1.5">
                    <Briefcase className="w-3.5 h-3.5 text-emerald-400" />
                    Matched Vacancies Requiring {skill.name}:
                  </span>
                  <span className="text-[11px] font-mono text-emerald-400">
                    {matchingJobs.length} Positions
                  </span>
                </div>

                <div className="space-y-2">
                  {matchingJobs.map((job) => (
                    <div
                      key={job.id}
                      onClick={() => {
                        onClose();
                        if (onSelectJob) onSelectJob(job.id);
                      }}
                      className="flex items-center justify-between rounded-xl bg-white/[0.03] hover:bg-white/[0.07] border border-white/[0.06] hover:border-[#00f2fe]/40 p-2.5 transition-all cursor-pointer group"
                    >
                      <div>
                        <p className="text-xs font-semibold text-white group-hover:text-[#00f2fe] transition-colors">
                          {job.title}
                        </p>
                        <p className="text-[11px] text-slate-400">{job.company} • {job.location}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-emerald-400 font-bold">
                          {job.matchPercentage}% Fit
                        </span>
                        <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-[#00f2fe] group-hover:translate-x-0.5 transition-all" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-white/[0.08] flex justify-end">
            <button
              onClick={onClose}
              className="rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/[0.1] px-5 py-2 text-xs font-semibold text-slate-200 transition-colors cursor-pointer"
            >
              Done
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
