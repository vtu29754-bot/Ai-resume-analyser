import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Briefcase,
  Search,
  Bookmark,
  BookmarkCheck,
  CheckCircle2,
  ExternalLink,
  Sparkles,
  SlidersHorizontal,
  X,
  Building2,
  Globe,
  Copy,
  Check,
  TrendingUp,
  Layers,
  Flame,
  Award,
  Clock,
  Filter
} from 'lucide-react';
import { JobRecommendation, ResumeAnalysisResult, JobPlatform, JobDomain } from '../types';
import { AiMatchDial } from './AiMatchDial';

interface JobRecommendationsProps {
  jobs: JobRecommendation[];
  analysis: ResumeAnalysisResult;
  savedJobIds: string[];
  onToggleBookmark: (jobId: string) => void;
  onOpenUpload: () => void;
}

export const JobRecommendations: React.FC<JobRecommendationsProps> = ({
  jobs,
  analysis,
  savedJobIds,
  onToggleBookmark,
  onOpenUpload
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [platformFilter, setPlatformFilter] = useState<'all' | JobPlatform>('all');
  const [domainFilter, setDomainFilter] = useState<JobDomain>('All Domains');
  const [exactMatchOnly, setExactMatchOnly] = useState(false);
  const [matchFilter, setMatchFilter] = useState<'all' | '90' | '85'>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'Remote' | 'Hybrid' | 'On-site'>('all');
  const [levelFilter, setLevelFilter] = useState<'all' | 'Senior' | 'Lead' | 'Mid' | 'Entry' | 'Intern'>('all');
  const [minLpaFilter, setMinLpaFilter] = useState<'all' | '7' | '15' | '25' | '40'>('all');
  
  const [selectedJob, setSelectedJob] = useState<JobRecommendation | null>(null);
  const [applyModalJob, setApplyModalJob] = useState<JobRecommendation | null>(null);
  const [appliedJobs, setAppliedJobs] = useState<string[]>([]);
  const [viewSavedOnly, setViewSavedOnly] = useState(false);
  const [copiedPitchId, setCopiedPitchId] = useState<string | null>(null);
  const [directApplyToast, setDirectApplyToast] = useState<{ company: string; platform: string } | null>(null);

  // Platform search launcher state
  const [customPlatformSearch, setCustomPlatformSearch] = useState(analysis.candidateTitle || 'Software Engineer');

  const filteredJobs = jobs.filter((job) => {
    if (viewSavedOnly && !savedJobIds.includes(job.id)) return false;
    if (exactMatchOnly && !job.isExactMatch) return false;
    if (platformFilter !== 'all' && job.platform !== platformFilter) return false;
    if (domainFilter !== 'All Domains' && job.domain !== domainFilter) return false;
    if (matchFilter === '90' && job.matchPercentage < 90) return false;
    if (matchFilter === '85' && job.matchPercentage < 85) return false;
    if (typeFilter !== 'all' && job.type !== typeFilter) return false;
    if (levelFilter !== 'all' && job.experienceLevel !== levelFilter) return false;
    
    if (minLpaFilter !== 'all') {
      const minRequired = parseFloat(minLpaFilter);
      // Extract numbers from salaryINR (e.g. "₹38 - 58 LPA" -> 38, or "₹7.5 - 11 LPA" -> 7.5)
      const match = job.salaryINR.match(/([\d.]+)/);
      if (match) {
        const parsedLpa = parseFloat(match[1]);
        if (parsedLpa < minRequired) return false;
      }
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        job.title.toLowerCase().includes(q) ||
        job.company.toLowerCase().includes(q) ||
        job.domain.toLowerCase().includes(q) ||
        job.platform.toLowerCase().includes(q) ||
        job.tags.some(t => t.toLowerCase().includes(q)) ||
        job.matchedSkills.some(s => s.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const exactMatchesCount = jobs.filter(j => j.isExactMatch).length;

  // Direct Apply handler that immediately opens the application page
  const handleDirectApply = (job: JobRecommendation, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();

    // Mark as applied
    setAppliedJobs(prev => prev.includes(job.id) ? prev : [...prev, job.id]);

    // Show instant toast notification
    setDirectApplyToast({ company: job.company, platform: job.platform });
    setTimeout(() => setDirectApplyToast(null), 4000);

    // Form direct destination URL
    let url = job.applyUrl;
    if (!url) {
      const query = encodeURIComponent(`${job.company} ${job.title}`);
      switch (job.platform) {
        case 'LinkedIn':
          url = `https://www.linkedin.com/jobs/search/?keywords=${query}`;
          break;
        case 'Indeed':
          url = `https://in.indeed.com/jobs?q=${query}`;
          break;
        case 'Naukri':
          url = `https://www.naukri.com/jobs-in-india?keywords=${query}`;
          break;
        case 'Foundit':
          url = `https://www.foundit.in/srp/results?query=${query}`;
          break;
        case 'Instahyre':
          url = `https://www.instahyre.com/job-search/?q=${query}`;
          break;
        case 'Wellfound':
          url = `https://wellfound.com/jobs?q=${query}`;
          break;
        case 'Glassdoor':
          url = `https://www.glassdoor.co.in/Job/india-jobs-SRCH_IL.0,5_IN115.htm?sc.keyword=${query}`;
          break;
        case 'Hirist':
          url = `https://www.hirist.tech/search?q=${query}`;
          break;
        case 'Internshala':
          url = `https://internshala.com/internships/matching-${encodeURIComponent(job.title.toLowerCase())}`;
          break;
        case 'Unstop':
          url = `https://unstop.com/jobs?searchTerm=${query}`;
          break;
        default:
          url = `https://www.google.com/search?q=${encodeURIComponent(job.company + ' careers ' + job.title + ' apply')}`;
      }
    }

    // Immediately open in new window
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // Launch search on external portals
  const handleLaunchExternalPlatform = (
    platformKey: 'linkedin' | 'indeed' | 'naukri' | 'foundit' | 'instahyre' | 'wellfound' | 'glassdoor' | 'hirist' | 'internshala' | 'unstop'
  ) => {
    const q = encodeURIComponent(customPlatformSearch.trim() || analysis.candidateTitle || 'Software Engineer');
    let url = '';
    switch (platformKey) {
      case 'linkedin':
        url = `https://www.linkedin.com/jobs/search/?keywords=${q}&location=India`;
        break;
      case 'indeed':
        url = `https://in.indeed.com/jobs?q=${q}&l=India`;
        break;
      case 'naukri':
        url = `https://www.naukri.com/jobs-in-india?keywords=${q}`;
        break;
      case 'foundit':
        url = `https://www.foundit.in/srp/results?query=${q}&locations=India`;
        break;
      case 'instahyre':
        url = `https://www.instahyre.com/job-search/?q=${q}`;
        break;
      case 'wellfound':
        url = `https://wellfound.com/jobs?q=${q}`;
        break;
      case 'glassdoor':
        url = `https://www.glassdoor.co.in/Job/india-jobs-SRCH_IL.0,5_IN115.htm?sc.keyword=${q}`;
        break;
      case 'hirist':
        url = `https://www.hirist.tech/search?q=${q}`;
        break;
      case 'internshala':
        url = `https://internshala.com/internships/keywords-${q}`;
        break;
      case 'unstop':
        url = `https://unstop.com/jobs?searchTerm=${q}`;
        break;
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const getPlatformBadgeStyle = (platform: JobPlatform) => {
    switch (platform) {
      case 'LinkedIn':
        return 'bg-[#0a66c2]/15 text-[#70b5f9] border-[#0a66c2]/40';
      case 'Indeed':
        return 'bg-[#2164f3]/15 text-[#60a5fa] border-[#2164f3]/40';
      case 'Naukri':
        return 'bg-[#00baf2]/15 text-[#38bdf8] border-[#00baf2]/40';
      case 'Foundit':
        return 'bg-[#8e2de2]/15 text-[#c084fc] border-[#8e2de2]/40';
      case 'Instahyre':
        return 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40';
      case 'Wellfound':
        return 'bg-rose-500/15 text-rose-300 border-rose-500/40';
      case 'Glassdoor':
        return 'bg-green-600/15 text-green-300 border-green-500/40';
      case 'Hirist':
        return 'bg-amber-500/15 text-amber-300 border-amber-500/40';
      case 'Internshala':
        return 'bg-cyan-500/15 text-cyan-300 border-cyan-500/40';
      case 'Unstop':
        return 'bg-indigo-500/15 text-indigo-300 border-indigo-500/40';
      case 'Company Career':
      default:
        return 'bg-[#00f2fe]/15 text-[#00f2fe] border-[#00f2fe]/40';
    }
  };

  const domainsList: JobDomain[] = [
    'All Domains',
    'Full Stack & Web',
    'Backend & Systems',
    'Frontend & Mobile',
    'AI & Data Science',
    'Cloud & DevOps',
    'QA & Automation',
    'Product & Design',
    'Freshers & Internships'
  ];

  const platformsList: (JobPlatform | 'all')[] = [
    'all',
    'LinkedIn',
    'Indeed',
    'Naukri',
    'Foundit',
    'Instahyre',
    'Wellfound',
    'Glassdoor',
    'Hirist',
    'Internshala',
    'Unstop',
    'Company Career'
  ];

  return (
    <div className="relative z-10 mx-auto max-w-7xl px-4 pt-6 pb-24 sm:px-6 lg:px-8">
      {/* Instant Notification Toast for direct redirection */}
      <AnimatePresence>
        {directApplyToast && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 right-6 z-50 rounded-2xl bg-slate-900/95 border border-[#00f2fe]/50 p-4 shadow-2xl backdrop-blur-lg flex items-center gap-3 text-xs text-white max-w-md"
          >
            <div className="h-9 w-9 rounded-xl bg-[#00f2fe]/20 text-[#00f2fe] flex items-center justify-center font-bold text-sm">
              ↗
            </div>
            <div>
              <p className="font-semibold text-[#00f2fe]">Directing to Job Application Page</p>
              <p className="text-slate-300 mt-0.5">
                Opening official application portal on <strong className="text-white">{directApplyToast.platform}</strong> for <strong className="text-white">{directApplyToast.company}</strong>...
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full glass-panel px-3 py-1 text-xs font-mono text-[#00f2fe] mb-2 border border-[#00f2fe]/30">
            <Sparkles className="w-3.5 h-3.5 text-[#00f2fe]" />
            <span>AI Multi-Platform Job Sourcing & Exact Skill Match Engine</span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-white">
            Matched Career Opportunities
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Exact matching for <strong className="text-white">{analysis.candidateTitle}</strong> ({analysis.experienceYears} yrs exp) • Salaries in <strong className="text-emerald-300 font-mono">Indian Rupees (₹ INR / LPA)</strong> across 10+ job platforms.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            id="toggle-saved-jobs"
            onClick={() => setViewSavedOnly(!viewSavedOnly)}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all cursor-pointer ${
              viewSavedOnly
                ? 'bg-[#00f2fe]/15 text-[#00f2fe] border border-[#00f2fe]/40'
                : 'bg-white/[0.04] border border-white/[0.08] text-slate-300 hover:text-white hover:bg-white/[0.08]'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>Saved ({savedJobIds.length})</span>
          </button>

          <button
            id="re-scan-jobs-btn"
            onClick={onOpenUpload}
            className="flex items-center gap-2 rounded-xl bg-white/[0.04] border border-white/[0.08] hover:border-white/[0.15] px-4 py-2 text-xs text-slate-300 hover:text-white transition-all cursor-pointer"
          >
            Update Resume
          </button>
        </div>
      </div>

      {/* MULTI-PLATFORM LIVE JOB SEARCH HUB */}
      <div className="rounded-3xl glass-panel-glow p-5 sm:p-6 mb-8 border border-white/[0.1] shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-[#00f2fe]" />
              <h2 className="font-display font-bold text-base sm:text-lg text-white">
                Live Search Across 10+ Job Platforms
              </h2>
            </div>
            <p className="text-xs text-slate-300 max-w-xl">
              1-Click query launch for active job openings in India & Globally across LinkedIn, Indeed, Naukri, Foundit, Instahyre, Wellfound, Glassdoor, Hirist, Internshala & Unstop.
            </p>
          </div>

          {/* Search Input Bar */}
          <div className="relative w-full lg:w-72">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={customPlatformSearch}
              onChange={(e) => setCustomPlatformSearch(e.target.value)}
              placeholder="Target role, e.g. Full Stack..."
              className="w-full rounded-xl glass-input pl-10 pr-3 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:ring-1 focus:ring-[#00f2fe]"
            />
          </div>
        </div>

        {/* 10+ Platform Launch Action Grid */}
        <div className="mt-4 pt-3 border-t border-white/[0.08] flex flex-wrap items-center gap-2">
          <span className="text-slate-400 font-mono text-[11px] mr-1">Search Portals:</span>
          
          <button
            onClick={() => handleLaunchExternalPlatform('linkedin')}
            className="flex items-center gap-1.5 rounded-xl bg-[#0a66c2]/20 hover:bg-[#0a66c2]/35 border border-[#0a66c2]/50 px-3 py-1.5 text-xs font-semibold text-[#70b5f9] transition-all cursor-pointer shadow-sm hover:scale-[1.02]"
          >
            <span>LinkedIn</span>
            <ExternalLink className="w-3 h-3" />
          </button>

          <button
            onClick={() => handleLaunchExternalPlatform('naukri')}
            className="flex items-center gap-1.5 rounded-xl bg-[#00baf2]/20 hover:bg-[#00baf2]/35 border border-[#00baf2]/50 px-3 py-1.5 text-xs font-semibold text-[#38bdf8] transition-all cursor-pointer shadow-sm hover:scale-[1.02]"
          >
            <span>Naukri</span>
            <ExternalLink className="w-3 h-3" />
          </button>

          <button
            onClick={() => handleLaunchExternalPlatform('indeed')}
            className="flex items-center gap-1.5 rounded-xl bg-[#2164f3]/20 hover:bg-[#2164f3]/35 border border-[#2164f3]/50 px-3 py-1.5 text-xs font-semibold text-[#60a5fa] transition-all cursor-pointer shadow-sm hover:scale-[1.02]"
          >
            <span>Indeed</span>
            <ExternalLink className="w-3 h-3" />
          </button>

          <button
            onClick={() => handleLaunchExternalPlatform('instahyre')}
            className="flex items-center gap-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/35 border border-emerald-500/50 px-3 py-1.5 text-xs font-semibold text-emerald-300 transition-all cursor-pointer shadow-sm hover:scale-[1.02]"
          >
            <span>Instahyre</span>
            <ExternalLink className="w-3 h-3" />
          </button>

          <button
            onClick={() => handleLaunchExternalPlatform('foundit')}
            className="flex items-center gap-1.5 rounded-xl bg-[#8e2de2]/20 hover:bg-[#8e2de2]/35 border border-[#8e2de2]/50 px-3 py-1.5 text-xs font-semibold text-[#c084fc] transition-all cursor-pointer shadow-sm hover:scale-[1.02]"
          >
            <span>Foundit</span>
            <ExternalLink className="w-3 h-3" />
          </button>

          <button
            onClick={() => handleLaunchExternalPlatform('wellfound')}
            className="flex items-center gap-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/35 border border-rose-500/50 px-3 py-1.5 text-xs font-semibold text-rose-300 transition-all cursor-pointer shadow-sm hover:scale-[1.02]"
          >
            <span>Wellfound</span>
            <ExternalLink className="w-3 h-3" />
          </button>

          <button
            onClick={() => handleLaunchExternalPlatform('hirist')}
            className="flex items-center gap-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/35 border border-amber-500/50 px-3 py-1.5 text-xs font-semibold text-amber-300 transition-all cursor-pointer shadow-sm hover:scale-[1.02]"
          >
            <span>Hirist</span>
            <ExternalLink className="w-3 h-3" />
          </button>

          <button
            onClick={() => handleLaunchExternalPlatform('glassdoor')}
            className="flex items-center gap-1.5 rounded-xl bg-green-600/20 hover:bg-green-600/35 border border-green-500/50 px-3 py-1.5 text-xs font-semibold text-green-300 transition-all cursor-pointer shadow-sm hover:scale-[1.02]"
          >
            <span>Glassdoor</span>
            <ExternalLink className="w-3 h-3" />
          </button>

          <button
            onClick={() => handleLaunchExternalPlatform('internshala')}
            className="flex items-center gap-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/35 border border-cyan-500/50 px-3 py-1.5 text-xs font-semibold text-cyan-300 transition-all cursor-pointer shadow-sm hover:scale-[1.02]"
          >
            <span>Internshala</span>
            <ExternalLink className="w-3 h-3" />
          </button>

          <button
            onClick={() => handleLaunchExternalPlatform('unstop')}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/35 border border-indigo-500/50 px-3 py-1.5 text-xs font-semibold text-indigo-300 transition-all cursor-pointer shadow-sm hover:scale-[1.02]"
          >
            <span>Unstop</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>

        {/* Suggested Queries based on resume */}
        <div className="mt-3 pt-2.5 border-t border-white/[0.06] flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-400 font-mono flex items-center gap-1 text-[11px]">
            <TrendingUp className="w-3 h-3 text-[#00f2fe]" /> Suggested Targets:
          </span>
          {[analysis.candidateTitle, ...(analysis.suggestedRoles || []).slice(0, 4)].filter(Boolean).map((role, idx) => (
            <button
              key={idx}
              onClick={() => {
                setCustomPlatformSearch(role);
                setSearchQuery(role);
              }}
              className="rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/[0.08] px-2.5 py-0.5 text-[11px] text-slate-300 transition-colors cursor-pointer"
            >
              {role}
            </button>
          ))}
        </div>
      </div>

      {/* FILTER & DOMAIN NAVIGATION BAR */}
      <div className="glass-panel rounded-2xl p-4 sm:p-5 mb-8 border border-white/[0.08] shadow-xl space-y-4">
        {/* Domain Navigation Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-white/[0.06] scrollbar-none">
          <span className="text-slate-400 font-mono text-xs whitespace-nowrap flex items-center gap-1 mr-1">
            <Filter className="w-3.5 h-3.5 text-[#00f2fe]" /> Job Domain:
          </span>
          {domainsList.map((domain) => (
            <button
              key={domain}
              onClick={() => setDomainFilter(domain)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                domainFilter === domain
                  ? 'bg-gradient-to-r from-[#00f2fe]/25 to-[#8e2de2]/25 text-white border border-[#00f2fe]/50 shadow-md'
                  : 'bg-white/[0.03] text-slate-400 hover:text-slate-200 border border-white/[0.06]'
              }`}
            >
              {domain}
            </button>
          ))}
        </div>

        {/* Search Input, Exact Match Toggle & Match Tiers */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative w-full sm:flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="job-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by role, company, skill (e.g. React, Python, Playwright, Cloud)..."
              className="w-full rounded-xl glass-input pl-10 pr-4 py-2.5 text-xs text-slate-200 placeholder:text-slate-500 focus:ring-1 focus:ring-[#00f2fe]"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* EXACT MATCH TOGGLE BUTTON */}
          <button
            id="toggle-exact-match"
            onClick={() => setExactMatchOnly(!exactMatchOnly)}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              exactMatchOnly
                ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/60 shadow-lg shadow-emerald-500/20'
                : 'bg-white/[0.04] text-slate-300 hover:text-white border border-white/[0.08]'
            }`}
          >
            <Award className={`w-4 h-4 ${exactMatchOnly ? 'text-emerald-400' : 'text-slate-400'}`} />
            <span>🎯 Exact Matches Only</span>
            <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-mono text-emerald-300">
              {exactMatchesCount}
            </span>
          </button>

          {/* Quick Match Tier Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            <button
              onClick={() => setMatchFilter('all')}
              className={`px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                matchFilter === 'all'
                  ? 'bg-[#00f2fe]/15 text-[#00f2fe] border border-[#00f2fe]/40'
                  : 'bg-white/[0.04] text-slate-400 hover:text-slate-200'
              }`}
            >
              All Matches
            </button>
            <button
              onClick={() => setMatchFilter('90')}
              className={`px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1 ${
                matchFilter === '90'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-white/[0.04] text-slate-400 hover:text-slate-200'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>90%+ Match</span>
            </button>
          </div>
        </div>

        {/* Platform Sourcing Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 pt-1 border-t border-white/[0.06] scrollbar-none">
          <span className="text-slate-400 font-mono text-xs whitespace-nowrap flex items-center gap-1 mr-1">
            <Layers className="w-3.5 h-3.5 text-[#00f2fe]" /> Sourcing Portal:
          </span>
          {platformsList.map((p) => {
            const isSelected = platformFilter === p;
            return (
              <button
                key={p}
                onClick={() => setPlatformFilter(p)}
                className={`px-3 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#00f2fe]/20 text-[#00f2fe] border border-[#00f2fe]/40 shadow-sm'
                    : 'bg-white/[0.03] text-slate-400 hover:text-slate-200 border border-white/[0.06]'
                }`}
              >
                {p === 'all' ? 'All Portals' : p}
              </button>
            );
          })}
        </div>

        {/* Secondary filters: Location, Level & Salary in Indian Rupees (INR / LPA) */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/[0.08] text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-slate-400 font-mono flex items-center gap-1">
              <SlidersHorizontal className="w-3 h-3 text-[#00f2fe]" /> Filters:
            </span>

            {/* Type selector */}
            {(['all', 'Remote', 'Hybrid', 'On-site'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTypeFilter(t)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all cursor-pointer ${
                  typeFilter === t
                    ? 'bg-white/[0.1] text-[#00f2fe] border border-white/[0.15]'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {t === 'all' ? 'All Locations' : t}
              </button>
            ))}

            <span className="text-slate-700">|</span>

            {/* Level selector */}
            {(['all', 'Lead', 'Senior', 'Mid', 'Entry', 'Intern'] as const).map((l) => (
              <button
                key={l}
                onClick={() => setLevelFilter(l)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all cursor-pointer ${
                  levelFilter === l
                    ? 'bg-white/[0.1] text-[#c084fc] border border-white/[0.15]'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {l === 'all' ? 'All Seniorities' : l}
              </button>
            ))}

            <span className="text-slate-700">|</span>

            {/* Min INR Salary (LPA) selector */}
            {(['all', '7', '15', '25', '40'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setMinLpaFilter(s)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all cursor-pointer ${
                  minLpaFilter === s
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {s === 'all' ? 'All CTC Packages (₹ INR)' : `₹${s}+ LPA`}
              </button>
            ))}
          </div>

          <span className="text-xs font-mono text-slate-400">
            Showing <strong>{filteredJobs.length}</strong> matching vacancies
          </span>
        </div>
      </div>

      {/* Empty State */}
      {filteredJobs.length === 0 && (
        <div className="text-center py-16 glass-card rounded-3xl p-8 border border-white/[0.08]">
          <Briefcase className="mx-auto w-12 h-12 text-slate-600 mb-4" />
          <h3 className="font-display font-bold text-lg text-white">No matching job vacancies found</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Try resetting your domain or platform filters, or launch an instant multi-platform search above.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setPlatformFilter('all');
              setDomainFilter('All Domains');
              setExactMatchOnly(false);
              setMatchFilter('all');
              setTypeFilter('all');
              setLevelFilter('all');
              setMinLpaFilter('all');
              setViewSavedOnly(false);
            }}
            className="mt-4 rounded-xl bg-white/[0.08] hover:bg-white/[0.15] px-4 py-2 text-xs font-semibold text-[#00f2fe] transition-colors cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      )}

      {/* Job Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredJobs.map((job) => {
          const isSaved = savedJobIds.includes(job.id);
          const hasApplied = appliedJobs.includes(job.id);

          return (
            <motion.div
              key={job.id}
              id={`job-card-${job.id}`}
              layout
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className={`glass-card rounded-3xl p-6 sm:p-7 flex flex-col justify-between relative overflow-hidden group hover:border-[#00f2fe]/40 shadow-xl transition-all ${
                job.isExactMatch ? 'border-emerald-500/30' : 'border-white/[0.08]'
              }`}
            >
              {/* Subtle top glow line */}
              <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-[#00f2fe]/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

              <div>
                {/* Platform Badge, Domain & Exact Match Tag */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-mono font-semibold ${getPlatformBadgeStyle(job.platform)}`}>
                      <Globe className="w-3 h-3" />
                      <span>{job.platform}</span>
                    </span>

                    <span className="rounded-full bg-white/[0.04] border border-white/[0.08] px-2.5 py-0.5 text-[11px] font-mono text-slate-300">
                      {job.domain}
                    </span>

                    {job.isExactMatch && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 px-2.5 py-0.5 text-[11px] font-mono font-bold text-emerald-300 animate-pulse">
                        <Award className="w-3 h-3 text-emerald-400" />
                        <span>Exact Fit</span>
                      </span>
                    )}
                  </div>

                  <span className="text-[11px] text-slate-500 font-mono flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{job.postedDate}</span>
                  </span>
                </div>

                {/* Header with Company Initials & AI Match Score Dial */}
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div className="flex items-center gap-3.5">
                    <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl font-display font-bold text-base border shadow-md ${job.companyLogoBg}`}>
                      {job.companyInitials}
                    </div>
                    <div>
                      <h3 className="font-display font-bold text-lg text-white group-hover:text-[#00f2fe] transition-colors leading-snug">
                        {job.title}
                      </h3>
                      <p className="text-xs font-medium text-slate-300 flex items-center gap-1.5 mt-0.5">
                        <Building2 className="w-3.5 h-3.5 text-slate-400" />
                        <span className="font-semibold text-slate-200">{job.company}</span>
                        <span className="text-slate-600">•</span>
                        <span className="text-slate-400">{job.location}</span>
                      </p>
                    </div>
                  </div>

                  {/* ANIMATED AI MATCH % INDICATOR BADGE WITH HOVER BREAKDOWN */}
                  <div className="flex flex-col items-end shrink-0">
                    <AiMatchDial 
                      matchPercentage={job.matchPercentage} 
                      breakdown={job.matchBreakdown}
                      size="md"
                    />
                  </div>
                </div>

                {/* Salary & Meta Badges (Indian Rupees / INR / LPA + Exp Match) */}
                <div className="flex flex-wrap items-center gap-2 my-3">
                  {/* Indian Rupee Salary Highlight */}
                  <span className="rounded-xl bg-emerald-500/15 border border-emerald-500/40 px-3 py-1 text-xs font-mono font-bold text-emerald-300 flex items-center gap-1 shadow-sm">
                    <span>₹</span>
                    <span>{job.salaryRange}</span>
                  </span>
                  <span className="rounded-lg bg-white/[0.05] border border-white/[0.08] px-2.5 py-1 text-xs font-medium text-slate-300">
                    {job.type}
                  </span>
                  <span className="rounded-lg bg-white/[0.05] border border-white/[0.08] px-2.5 py-1 text-xs font-medium text-slate-300">
                    Exp: {job.requiredYears}
                  </span>
                </div>

                {/* Description Snippet */}
                <p className="text-xs text-slate-300 leading-relaxed line-clamp-2 mt-2">
                  {job.description}
                </p>

                {/* EXACT MATCHED SKILLS CHIPS */}
                <div className="mt-4 space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                    <span>
                      {job.isExactMatch ? '✓ Direct Resume Skill Alignment:' : 'Matched Competencies:'}
                    </span>
                    <button
                      onClick={() => setSelectedJob(job)}
                      className="text-[#00f2fe] hover:text-white underline underline-offset-2 cursor-pointer"
                    >
                      Skill Matrix
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {job.matchedSkills.slice(0, 6).map((sk, idx) => (
                      <span
                        key={idx}
                        className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-mono ${
                          job.isExactMatch
                            ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-300'
                            : 'bg-[#00f2fe]/10 border border-[#00f2fe]/25 text-[#00f2fe]'
                        }`}
                      >
                        <CheckCircle2 className="w-2.5 h-2.5" />
                        {sk}
                      </span>
                    ))}
                    {job.missingSkills.length > 0 && (
                      <span className="inline-flex items-center gap-1 rounded-md bg-white/[0.05] px-2 py-0.5 text-[11px] font-mono text-slate-400">
                        +{job.missingSkills.length} learnable
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Direct Application Destination Preview */}
              <div className="mt-4 flex items-center justify-between gap-2 text-[11px] font-mono text-slate-400">
                <span className="text-slate-400">Apply Via:</span>
                <span 
                  className="text-[#00f2fe]/90 truncate max-w-[240px] hover:underline cursor-pointer flex items-center gap-1" 
                  onClick={(e) => handleDirectApply(job, e)}
                  title={`Apply directly on ${job.platform}`}
                >
                  <span>{job.platform} Direct Page</span>
                  <ExternalLink className="w-3 h-3 text-[#00f2fe]" />
                </span>
              </div>

              {/* Bottom Actions */}
              <div className="mt-5 pt-4 border-t border-white/[0.08] flex items-center justify-between gap-3">
                <button
                  id={`bookmark-btn-${job.id}`}
                  onClick={() => onToggleBookmark(job.id)}
                  className={`p-2 rounded-xl border transition-all cursor-pointer ${
                    isSaved
                      ? 'bg-[#00f2fe]/20 border-[#00f2fe]/40 text-[#00f2fe]'
                      : 'bg-white/[0.04] border-white/[0.08] text-slate-400 hover:text-slate-200'
                  }`}
                  title={isSaved ? 'Saved to bookmarks' : 'Save job'}
                >
                  {isSaved ? <BookmarkCheck className="w-4 h-4 fill-[#00f2fe]" /> : <Bookmark className="w-4 h-4" />}
                </button>

                <div className="flex items-center gap-2">
                  <button
                    id={`details-btn-${job.id}`}
                    onClick={() => setSelectedJob(job)}
                    className="rounded-xl bg-white/[0.04] border border-white/[0.08] hover:border-white/[0.15] px-3.5 py-2 text-xs font-semibold text-slate-300 hover:text-white transition-colors cursor-pointer"
                  >
                    Fit Analysis
                  </button>

                  {/* DIRECT APPLY BUTTON - IMMEDIATELY OPENS OFFICIAL APPLY PAGE */}
                  <button
                    id={`apply-btn-${job.id}`}
                    onClick={(e) => handleDirectApply(job, e)}
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] px-4 py-2 text-xs font-semibold text-white shadow-md hover:shadow-[#00f2fe]/30 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
                    title={`Directly open application page on ${job.platform}`}
                  >
                    {hasApplied ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                        <span>Applied on {job.platform} ↗</span>
                      </>
                    ) : (
                      <>
                        <span>Apply on {job.platform}</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* MODAL 1: FIT ANALYSIS & SKILL OVERLAP BREAKDOWN */}
      <AnimatePresence>
        {selectedJob && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-[#05070a]/85 backdrop-blur-md p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-2xl rounded-3xl glass-panel-glow p-6 sm:p-8 shadow-2xl border border-white/[0.08] max-h-[90vh] overflow-y-auto space-y-6"
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="rounded-full bg-[#00f2fe]/15 border border-[#00f2fe]/35 px-3 py-0.5 text-xs font-mono font-bold text-[#00f2fe]">
                      {selectedJob.matchPercentage}% Compatibility
                    </span>
                    <span className={`rounded-full border px-2.5 py-0.5 text-xs font-mono font-semibold ${getPlatformBadgeStyle(selectedJob.platform)}`}>
                      {selectedJob.platform}
                    </span>
                    {selectedJob.isExactMatch && (
                      <span className="rounded-full bg-emerald-500/20 border border-emerald-500/40 px-2.5 py-0.5 text-xs font-mono font-bold text-emerald-300">
                        ✓ Exact Skill Alignment
                      </span>
                    )}
                  </div>
                  <h3 className="font-display font-bold text-2xl text-white mt-1">
                    {selectedJob.title}
                  </h3>
                  <p className="text-xs text-slate-300 mt-1">
                    <strong className="text-white">{selectedJob.company}</strong> • {selectedJob.location} • <strong className="text-emerald-300 font-mono">₹ {selectedJob.salaryRange}</strong>
                  </p>
                </div>
                <button
                  onClick={() => setSelectedJob(null)}
                  className="rounded-xl p-2 text-slate-400 hover:text-white hover:bg-white/[0.08] cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Dimensional Fit Progress Bars */}
              <div className="space-y-3 rounded-2xl bg-white/[0.03] border border-white/[0.08] p-5">
                <h4 className="font-display font-semibold text-sm text-white mb-2">
                  Dimensional Alignment Matrix
                </h4>
                
                {[
                  { label: 'Technical Skills Overlap', value: selectedJob.matchBreakdown.skillsMatch },
                  { label: 'Seniority & Experience Parity', value: selectedJob.matchBreakdown.experienceMatch },
                  { label: 'Domain & Role Responsibilities', value: selectedJob.matchBreakdown.roleFit },
                  { label: 'ATS Parser Indexing Score', value: selectedJob.matchBreakdown.atsReadiness }
                ].map((item, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-300">{item.label}</span>
                      <span className="font-mono text-[#00f2fe] font-bold">{item.value}%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-white/[0.08] overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] rounded-full"
                        style={{ width: `${item.value}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              {/* Key Match Highlights */}
              <div className="space-y-2">
                <h4 className="font-display font-semibold text-sm text-white">
                  Why Your Profile Stands Out
                </h4>
                <ul className="space-y-2">
                  {selectedJob.highlights.map((h, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{h}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Matched vs Missing Skills Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/20 p-4">
                  <h5 className="text-xs font-bold text-emerald-300 font-mono uppercase mb-2">
                    ✓ Verified Matched Skills ({selectedJob.matchedSkills.length})
                  </h5>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedJob.matchedSkills.map((sk, idx) => (
                      <span key={idx} className="rounded bg-emerald-500/20 px-2 py-0.5 text-[11px] font-mono text-emerald-200">
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="rounded-xl bg-amber-500/10 border border-amber-500/20 p-4">
                  <h5 className="text-xs font-bold text-amber-300 font-mono uppercase mb-2">
                    ⚠ Missing / Recommended Skills
                  </h5>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedJob.missingSkills.map((sk, idx) => (
                      <span key={idx} className="rounded bg-amber-500/20 px-2 py-0.5 text-[11px] font-mono text-amber-200">
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between gap-3 pt-4 border-t border-white/[0.08]">
                <button
                  onClick={() => setSelectedJob(null)}
                  className="rounded-xl bg-white/[0.04] border border-white/[0.08] px-4 py-2 text-xs text-slate-300 cursor-pointer hover:bg-white/[0.08]"
                >
                  Close
                </button>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      const j = selectedJob;
                      setSelectedJob(null);
                      setApplyModalJob(j);
                    }}
                    className="rounded-xl bg-white/[0.06] border border-white/[0.12] hover:bg-white/[0.1] px-4 py-2 text-xs font-semibold text-slate-200 cursor-pointer"
                  >
                    View Tailored Pitch
                  </button>
                  <button
                    onClick={() => {
                      handleDirectApply(selectedJob);
                    }}
                    className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] px-5 py-2 text-xs font-semibold text-white shadow-lg hover:shadow-[#00f2fe]/30 hover:scale-[1.02] cursor-pointer"
                  >
                    <span>Direct Apply on {selectedJob.platform}</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MODAL 2: TAILORED APPLICATION PITCH HELPER */}
      <AnimatePresence>
        {applyModalJob && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-[#05070a]/85 backdrop-blur-md p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-xl rounded-3xl glass-panel-glow p-6 sm:p-8 shadow-2xl border border-[#00f2fe]/30 space-y-6"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="inline-flex items-center gap-1.5 rounded-full bg-[#00f2fe]/15 border border-[#00f2fe]/35 px-3 py-0.5 text-xs font-mono text-[#00f2fe]">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Direct Job Application Helper</span>
                  </div>
                  <h3 className="font-display font-bold text-xl text-white mt-2">
                    Apply to {applyModalJob.company}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Platform: <strong className="text-slate-200">{applyModalJob.platform}</strong> • Salary: <strong className="text-emerald-300">₹ {applyModalJob.salaryINR}</strong>
                  </p>
                </div>
                <button
                  onClick={() => setApplyModalJob(null)}
                  className="rounded-xl p-2 text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Auto-generated cover letter pitch */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-mono text-slate-400">
                    Tailored Pitch (Ready to paste on {applyModalJob.platform}):
                  </label>
                  {copiedPitchId === applyModalJob.id && (
                    <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                      <Check className="w-3 h-3" /> Copied!
                    </span>
                  )}
                </div>
                <div className="rounded-2xl bg-white/[0.03] border border-white/[0.08] p-4 font-mono text-xs text-slate-300 leading-relaxed max-h-48 overflow-y-auto select-all">
                  Dear Hiring Team at {applyModalJob.company},<br /><br />
                  I am writing to express my strong enthusiasm for the {applyModalJob.title} opening on {applyModalJob.platform}. With {analysis.experienceYears}+ years of hands-on expertise in {analysis.allExtractedSkills.slice(0, 5).join(', ')}, my profile matches your technical and architectural requirements for {applyModalJob.tags.join(', ')}.<br /><br />
                  I look forward to discussing how my experience can contribute to {applyModalJob.company}'s engineering goals.<br /><br />
                  Best regards,<br />
                  {analysis.candidateName}
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                <span>Destination: <strong>{applyModalJob.platform} Direct Page</strong></span>
                <span className="text-emerald-400">✓ 1-Click Redirect</span>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-white/[0.08]">
                <button
                  onClick={() => setApplyModalJob(null)}
                  className="rounded-xl bg-white/[0.04] border border-white/[0.08] px-4 py-2 text-xs text-slate-300 cursor-pointer"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const text = `Dear Hiring Team at ${applyModalJob.company},\n\nI am writing to express my strong enthusiasm for the ${applyModalJob.title} opening on ${applyModalJob.platform}. With ${analysis.experienceYears}+ years of hands-on expertise in ${analysis.allExtractedSkills.slice(0, 5).join(', ')}, my profile matches your technical and architectural requirements for ${applyModalJob.tags.join(', ')}.\n\nI look forward to discussing how my experience can contribute to ${applyModalJob.company}'s engineering goals.\n\nBest regards,\n${analysis.candidateName}`;
                    navigator.clipboard?.writeText(text);
                    setCopiedPitchId(applyModalJob.id);
                    setTimeout(() => setCopiedPitchId(null), 3000);
                    handleDirectApply(applyModalJob);
                  }}
                  className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] px-6 py-2.5 text-xs font-semibold text-white shadow-lg shadow-[#00f2fe]/25 hover:scale-[1.02] cursor-pointer"
                >
                  <Copy className="w-4 h-4" />
                  <span>Copy Pitch & Open {applyModalJob.platform} Page</span>
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
