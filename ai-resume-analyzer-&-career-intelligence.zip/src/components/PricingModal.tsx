import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, CheckCircle2, Zap, Shield, Crown, ArrowRight } from 'lucide-react';
import { UserProfile } from '../types';

interface PricingModalProps {
  user: UserProfile;
  onUpgrade: (plan: 'Free' | 'Pro' | 'Enterprise') => void;
  onScanNow: () => void;
}

export const PricingSection: React.FC<PricingModalProps> = ({ user, onUpgrade, onScanNow }) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('yearly');

  const plans = [
    {
      id: 'Free' as const,
      name: 'Starter Candidate',
      price: '$0',
      period: 'forever',
      badge: 'Free Tier',
      desc: 'Essential ATS scanning and keyword extraction for active job seekers.',
      features: [
        '5 Deep AI Resume Scans per month',
        'Standard ATS Readiness Score & Breakdown',
        'Top 10 High-Match Tech Job Recommendations',
        'Basic Bullet Point Rewrite Suggestions',
        'Client-side instant parsing'
      ],
      cta: user.plan === 'Free' ? 'Current Plan' : 'Select Free',
      isCurrent: user.plan === 'Free',
      popular: false
    },
    {
      id: 'Pro' as const,
      name: 'Career Pro & AI Suite',
      price: billingCycle === 'yearly' ? '$16' : '$22',
      period: 'per month',
      badge: 'Most Popular',
      desc: 'Unlimited neural resume audits, XYZ bullet optimizer, and 1-click tailored cover letters.',
      features: [
        'Unlimited AI Resume & CV Audits',
        'Executive XYZ Formula Bullet Rewriter',
        'Direct ATS System Simulators (Workday, Greenhouse)',
        'Personalized 1-Click Job Application Cover Letters',
        'Real-time Salary Parity & Equity Insights',
        'Early Access to Tier-1 Staff/Lead Roles'
      ],
      cta: user.plan === 'Pro' ? 'Current Active Plan' : 'Upgrade to Pro',
      isCurrent: user.plan === 'Pro',
      popular: true
    },
    {
      id: 'Enterprise' as const,
      name: 'Executive & Recruiter',
      price: billingCycle === 'yearly' ? '$49' : '$65',
      period: 'per month',
      badge: 'Teams & Recruiters',
      desc: 'For career coaches, executive search consultants, and technical recruiters.',
      features: [
        'Batch Multi-Resume ATS Scoring (up to 500)',
        'Custom Role JD vs. Candidate Matrix Comparator',
        'White-label PDF Audit Dossier Exports',
        'Dedicated API Access for Greenhouse / Lever',
        'Priority 24/7 Concierge Career Support'
      ],
      cta: user.plan === 'Enterprise' ? 'Current Active Plan' : 'Select Enterprise',
      isCurrent: user.plan === 'Enterprise',
      popular: false
    }
  ];

  return (
    <div className="relative z-10 mx-auto max-w-6xl px-4 pt-6 pb-24 sm:px-6 lg:px-8 space-y-12">
      <div className="text-center max-w-2xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 rounded-full glass-panel px-4 py-1.5 border border-[#00f2fe]/30 text-xs font-mono text-[#00f2fe] shadow-lg">
          <Crown className="w-3.5 h-3.5 text-[#00f2fe]" />
          <span>Flexible Career Plans</span>
        </div>
        <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-white">
          Invest in Your Next <span className="text-gradient-cyan">Tier-1 Role</span>
        </h1>
        <p className="text-sm text-slate-300">
          Land interviews at Anthropic, Stripe, OpenAI, and Apple with optimized ATS readiness.
        </p>

        {/* Monthly vs Yearly toggle */}
        <div className="flex items-center justify-center gap-3 pt-2">
          <span className={`text-xs font-semibold ${billingCycle === 'monthly' ? 'text-white' : 'text-slate-400'}`}>
            Monthly
          </span>
          <button
            onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
            className="relative h-6 w-12 rounded-full bg-white/[0.08] p-0.5 border border-white/[0.12] transition-colors cursor-pointer"
          >
            <div
              className={`h-5 w-5 rounded-full bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] transition-transform ${
                billingCycle === 'yearly' ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
          <span className={`text-xs font-semibold flex items-center gap-1.5 ${billingCycle === 'yearly' ? 'text-white' : 'text-slate-400'}`}>
            Yearly <span className="rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.2 text-[10px] font-mono">Save 30%</span>
          </span>
        </div>
      </div>

      {/* Pricing Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
        {plans.map((plan) => (
          <div
            key={plan.id}
            id={`pricing-card-${plan.id}`}
            className={`rounded-3xl p-7 flex flex-col justify-between relative transition-all ${
              plan.popular
                ? 'glass-panel-glow border-[#00f2fe]/40 shadow-2xl scale-[1.02]'
                : 'glass-card border-white/[0.08]'
            }`}
          >
            {plan.popular && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] px-3.5 py-1 text-[11px] font-mono font-bold text-white shadow-lg">
                ★ {plan.badge}
              </span>
            )}

            <div>
              <div className="flex items-center justify-between">
                <h3 className="font-display font-bold text-lg text-white">{plan.name}</h3>
                {!plan.popular && (
                  <span className="rounded-md bg-white/[0.05] border border-white/[0.08] px-2 py-0.5 text-[10px] font-mono text-slate-400">
                    {plan.badge}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-2 min-h-[34px]">{plan.desc}</p>

              <div className="mt-5 flex items-baseline gap-1">
                <span className="font-display font-extrabold text-4xl text-white">{plan.price}</span>
                <span className="text-xs font-mono text-slate-400">/{plan.period}</span>
              </div>

              <div className="mt-6 pt-6 border-t border-white/[0.08] space-y-3">
                <p className="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold">
                  What's included:
                </p>
                {plan.features.map((feat, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-[#00f2fe] shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 pt-4">
              <button
                id={`plan-select-btn-${plan.id}`}
                onClick={() => onUpgrade(plan.id)}
                disabled={plan.isCurrent}
                className={`w-full py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  plan.isCurrent
                    ? 'bg-white/[0.02] text-slate-500 border border-white/[0.05] cursor-default'
                    : plan.popular
                    ? 'bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] text-white shadow-lg shadow-[#00f2fe]/25 hover:shadow-[#00f2fe]/40 hover:scale-[1.02]'
                    : 'bg-white/[0.06] hover:bg-white/[0.12] text-white border border-white/[0.1]'
                }`}
              >
                {plan.cta}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
