import React, { useState } from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  Cpu, 
  Layers, 
  Zap, 
  CheckCircle2, 
  ArrowRight,
  BrainCircuit,
  Lock,
  FileCheck
} from 'lucide-react';

export const AboutSection: React.FC<{ onScanNow: () => void }> = ({ onScanNow }) => {
  const [activeFaq, setActiveFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: 'How does ResumeGlow score my resume against ATS parsers?',
      a: 'We benchmark your document using standard ATS heuristic parsers, assessing font hierarchy, contact parsing, section recognition, verb strength, and keyword density matching against 2,500+ technology roles.'
    },
    {
      q: 'Is my resume data stored or shared with external recruiters?',
      a: 'No. All initial parsing and analysis can run locally in your browser. We never sell your contact information or resume data to third parties.'
    },
    {
      q: 'How are the AI Match percentages calculated for jobs?',
      a: 'Our neural matching engine evaluates skill overlaps, years of seniority alignment, keyword frequency, and domain experience to compute a true multi-dimensional compatibility score.'
    },
    {
      q: 'Can I export the analysis report?',
      a: 'Yes! You can 1-click copy your full Executive Dossier or copy rewritten high-impact bullets directly into your master resume.'
    }
  ];

  return (
    <div className="relative z-10 mx-auto max-w-6xl px-4 pt-6 pb-24 sm:px-6 lg:px-8 space-y-16">
      {/* Platform Vision Hero */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 rounded-full glass-panel px-4 py-1.5 border border-[#00f2fe]/30 text-xs font-mono text-[#00f2fe] shadow-lg shadow-[#00f2fe]/10">
          <Sparkles className="w-3.5 h-3.5 text-[#00f2fe]" />
          <span>Architected for Modern Tech Careers</span>
        </div>
        <h1 className="font-display text-4xl sm:text-5xl font-extrabold text-white">
          The Career Intelligence Engine Built for <span className="text-gradient-cyan">Top Performers</span>
        </h1>
        <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
          ResumeGlow bridges the gap between top engineering talent and Tier-1 recruiters through algorithmic resume optimization, bullet point impact quantification, and precision AI job matching.
        </p>
      </div>

      {/* Feature Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card rounded-3xl p-7 space-y-4 border border-white/[0.08]">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#00f2fe]/15 text-[#00f2fe] border border-[#00f2fe]/30">
            <BrainCircuit className="w-6 h-6" />
          </div>
          <h3 className="font-display font-bold text-lg text-white">Neural Skill Graph</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Extracts complex multi-stack competencies, frameworks, cloud tools, and architecture paradigms across 2,500+ indexed tech skills.
          </p>
        </div>

        <div className="glass-card rounded-3xl p-7 space-y-4 border border-white/[0.08]">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#8e2de2]/20 text-[#c084fc] border border-[#8e2de2]/30">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="font-display font-bold text-lg text-white">Enterprise ATS Readiness</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Audits your resume against standard parsing engines (Workday, Greenhouse, Lever, Taleo) to eliminate formatting bottlenecks.
          </p>
        </div>

        <div className="glass-card rounded-3xl p-7 space-y-4 border border-white/[0.08]">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <Zap className="w-6 h-6" />
          </div>
          <h3 className="font-display font-bold text-lg text-white">Dynamic AI Job Matching</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Continuously recalculates compatibility across open roles at Anthropic, Stripe, OpenAI, Vercel, and high-growth AI startups.
          </p>
        </div>
      </div>

      {/* FAQ Accordion */}
      <div className="glass-panel rounded-3xl p-8 border border-white/[0.08] space-y-6">
        <div className="text-center max-w-xl mx-auto">
          <h3 className="font-display font-bold text-2xl text-white">Frequently Asked Questions</h3>
          <p className="text-xs text-slate-400 mt-1">Everything you need to know about our scoring algorithms</p>
        </div>

        <div className="space-y-3 max-w-3xl mx-auto">
          {faqs.map((faq, idx) => (
            <div
              key={idx}
              className="rounded-2xl bg-white/[0.03] border border-white/[0.08] overflow-hidden transition-all"
            >
              <button
                id={`faq-btn-${idx}`}
                onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                className="w-full flex items-center justify-between p-4 text-left text-xs sm:text-sm font-semibold text-slate-200 hover:text-[#00f2fe] transition-colors cursor-pointer"
              >
                <span>{faq.q}</span>
                <span className="text-[#00f2fe] font-mono text-base ml-2">{activeFaq === idx ? '−' : '+'}</span>
              </button>
              {activeFaq === idx && (
                <div className="px-4 pb-4 text-xs text-slate-300 leading-relaxed border-t border-white/[0.06] pt-3">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="text-center pt-4">
          <button
            id="faq-scan-cta"
            onClick={onScanNow}
            className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#00f2fe] to-[#8e2de2] px-6 py-2.5 text-xs font-semibold text-white shadow-lg shadow-[#00f2fe]/25 cursor-pointer"
          >
            <Zap className="w-4 h-4" />
            <span>Audit Your Resume Now</span>
          </button>
        </div>
      </div>
    </div>
  );
};
