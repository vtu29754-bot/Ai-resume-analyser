/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Navbar } from './components/Navbar';
import { ResumeUploader } from './components/ResumeUploader';
import { JobRecommendations } from './components/JobRecommendations';
import { Footer } from './components/Footer';
import { ActiveTab, ResumeAnalysisResult, UserProfile, JobRecommendation } from './types';
import { SAMPLE_RESUMES } from './data/sampleResumes';
import { recalculateJobMatches } from './data/mockJobs';
import { Image as ImageIcon, Sparkles } from 'lucide-react';

// Import generated atmospheric background images
import techBgMesh from './assets/images/tech_background_mesh_1788244186511.jpg';
import auroraBg from './assets/images/abstract_aurora_bg_1788244202329.jpg';

export type BgTheme = 'tech-mesh' | 'aurora' | 'grid' | 'cosmic';

export default function App() {
  // Initialize with sample analysis for instant exploratory experience
  const [analysis, setAnalysis] = useState<ResumeAnalysisResult>(() => SAMPLE_RESUMES[0].analysis);
  const [activeTab, setActiveTab] = useState<ActiveTab>('analyzer');
  const [isScanning, setIsScanning] = useState(false);
  const [bgTheme, setBgTheme] = useState<BgTheme>('tech-mesh');
  
  const [savedJobIds, setSavedJobIds] = useState<string[]>(['job-1', 'job-3']);
  const [user, setUser] = useState<UserProfile>({
    name: 'Alex Rivera',
    email: 'alex.rivera.dev@gmail.com',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    title: 'Senior Full Stack & Cloud Architect',
    isLoggedIn: false,
    plan: 'Pro',
    scansRemaining: 99,
    savedJobIds: ['job-1', 'job-3']
  });

  // Calculate dynamic job matches whenever analysis changes
  const [jobs, setJobs] = useState<JobRecommendation[]>(() => recalculateJobMatches(SAMPLE_RESUMES[0].analysis));

  useEffect(() => {
    if (analysis) {
      const updated = recalculateJobMatches(analysis);
      setJobs(updated);
    }
  }, [analysis]);

  const handleAnalysisComplete = (newAnalysis: ResumeAnalysisResult) => {
    setAnalysis(newAnalysis);
    setActiveTab('jobs');
  };

  const handleToggleBookmark = (jobId: string) => {
    setSavedJobIds(prev => {
      const next = prev.includes(jobId) ? prev.filter(id => id !== jobId) : [...prev, jobId];
      setUser(u => ({ ...u, savedJobIds: next }));
      return next;
    });
  };

  const pageVariants = {
    initial: { opacity: 0, y: 8 },
    animate: { opacity: 1, y: 0, transition: { duration: 0.25, ease: 'easeOut' } },
    exit: { opacity: 0, y: -8, transition: { duration: 0.15, ease: 'easeIn' } }
  };

  return (
    <div className="relative min-h-screen bg-[#060913] text-slate-100 flex flex-col font-sans selection:bg-[#05f1cd]/30 selection:text-[#05f1cd]">
      {/* ATMOSPHERIC BACKGROUND LAYERS & IMAGES */}
      <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        {/* Generated Image Background Layer 1: Tech Mesh */}
        <div 
          className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
            bgTheme === 'tech-mesh' ? 'opacity-30' : 'opacity-0'
          }`}
        >
          <img
            src={techBgMesh}
            alt="Cybernetic tech mesh backdrop"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center filter saturate-150 contrast-110"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#060913]/60 via-[#060913]/80 to-[#060913]" />
        </div>

        {/* Generated Image Background Layer 2: Aurora Horizon */}
        <div 
          className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
            bgTheme === 'aurora' ? 'opacity-35' : 'opacity-0'
          }`}
        >
          <img
            src={auroraBg}
            alt="Aurora tech backdrop"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center filter saturate-150"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#060913]/55 via-[#060913]/75 to-[#060913]" />
        </div>

        {/* Ambient mesh gradient */}
        <div className="mesh-gradient opacity-80" />

        {/* Subtle geometric wireframe grid */}
        <div
          className={`absolute inset-0 transition-opacity duration-500 ${
            bgTheme === 'grid' ? 'opacity-[0.25]' : 'opacity-[0.14]'
          }`}
          style={{
            backgroundImage: `linear-gradient(to right, rgba(5, 241, 205, 0.08) 1px, transparent 1px), linear-gradient(to bottom, rgba(139, 92, 246, 0.08) 1px, transparent 1px)`,
            backgroundSize: '48px 48px',
            maskImage: 'radial-gradient(ellipse 80% 60% at 50% 15%, black, transparent 85%)'
          }}
        />

        {/* Ambient Glowing Orbs with unique colors */}
        <div className="animate-pulse-glow absolute -top-48 -left-36 h-[34rem] w-[34rem] rounded-full bg-[#05f1cd]/14 blur-[140px]" />
        <div className="animate-pulse-glow absolute top-1/3 -right-48 h-[32rem] w-[32rem] rounded-full bg-[#8b5cf6]/16 blur-[150px] [animation-delay:-3s]" />
        <div className="animate-pulse-glow absolute bottom-10 left-1/4 h-[28rem] w-[28rem] rounded-full bg-[#ff6482]/10 blur-[150px] [animation-delay:-6s]" />
      </div>

      {/* Floating Background Image Mood Switcher */}
      <div className="fixed bottom-5 right-5 z-40">
        <div className="glass-panel px-3 py-1.5 rounded-2xl flex items-center gap-2 border border-white/[0.1] shadow-2xl backdrop-blur-xl">
          <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1.5 pl-1">
            <ImageIcon className="w-3.5 h-3.5 text-[#05f1cd]" />
            <span className="hidden sm:inline">Theme Mood:</span>
          </span>
          <div className="flex items-center gap-1">
            {(
              [
                { id: 'tech-mesh', label: 'Cyber' },
                { id: 'aurora', label: 'Aurora' },
                { id: 'grid', label: 'Grid' },
                { id: 'cosmic', label: 'Cosmic' }
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                onClick={() => setBgTheme(t.id)}
                className={`px-2.5 py-1 rounded-xl text-[11px] font-mono font-medium transition-all cursor-pointer ${
                  bgTheme === t.id
                    ? 'bg-gradient-to-r from-[#05f1cd]/30 to-[#8b5cf6]/30 text-[#05f1cd] border border-[#05f1cd]/50 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Glass Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenUpload={() => setActiveTab('analyzer')}
        savedJobsCount={savedJobIds.length}
      />

      {/* Main View Container with Smooth Page Transitions */}
      <main className="relative z-10 flex-1">
        <AnimatePresence mode="wait">
          {activeTab === 'analyzer' && (
            <motion.div
              key="analyzer"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <ResumeUploader
                onAnalysisComplete={handleAnalysisComplete}
                isScanning={isScanning}
                setIsScanning={setIsScanning}
              />
            </motion.div>
          )}

          {activeTab === 'jobs' && (
            <motion.div
              key="jobs"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <JobRecommendations
                jobs={jobs}
                analysis={analysis}
                savedJobIds={savedJobIds}
                onToggleBookmark={handleToggleBookmark}
                onOpenUpload={() => setActiveTab('analyzer')}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Modern SaaS Footer */}
      <Footer onNavigate={(tab) => setActiveTab(tab)} />
    </div>
  );
}
